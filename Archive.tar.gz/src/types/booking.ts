export interface Room {
  id: string;
  type: 'single' | 'double' | 'suite';
  price: number;
  isAvailable: boolean;
  features: string[];
  image: string;
  maxOccupancy: number;
}

export interface BookingDetails {
  id?: string;
  guestName: string;
  email: string;
  phone: string;
  idNumber: string;
  checkIn: Date;
  checkOut: Date;
  roomId: string;
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  paymentStatus: 'pending' | 'paid' | 'failed';
  createdAt?: Date;
}

export interface PaymentDetails {
  amount: number;
  method: 'mpesa' | 'card' | 'cash';
  transactionId?: string;
  status: 'pending' | 'completed' | 'failed';
}