import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/NewAuthContext';

interface RouteGuardProps {
  children: React.ReactNode;
  requireAuth?: boolean;
  requireAdmin?: boolean;
  allowPreview?: boolean; // New prop to allow preview users
}

/**
 * Route Guard Component
 * 
 * Protects routes based on authentication status and user roles.
 * Redirects unauthenticated users to signin page.
 * Redirects non-admin users away from admin-only routes.
 * Allows preview users to access certain features with limitations.
 */
const RouteGuard = ({ children, requireAuth = true, requireAdmin = false, allowPreview = false }: RouteGuardProps) => {
  const { isAuthenticated, isAdmin, isLoading, isPreview } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Routes that preview users can access
  const previewAllowedRoutes = [
    '/home',
    '/rooms',
    '/ai-assistant',
    '/help',
    '/user-manual',
    '/profile'
  ];

  // Routes that require full authentication (no preview access)
  const fullAuthRequiredRoutes = [
    '/booking',
    '/payment',
    '/settings',
    '/admin',
    '/admin-chat',
    '/client-chat',
    '/qa-forum'
  ];

  useEffect(() => {
    // Don't redirect while loading
    if (isLoading) return;

    // If authentication is required but user is not authenticated
    if (requireAuth && !isAuthenticated) {
      navigate('/signin', { replace: true });
      return;
    }

    // If admin access is required but user is not admin
    if (requireAdmin && !isAdmin) {
      navigate('/home', { replace: true });
      return;
    }

    // Handle preview user restrictions
    if (isPreview && requireAuth) {
      const currentPath = location.pathname;
      
      // If this route is explicitly allowed for preview users
      if (allowPreview || previewAllowedRoutes.includes(currentPath)) {
        return; // Allow access
      }
      
      // If this route requires full authentication
      if (fullAuthRequiredRoutes.some(route => currentPath.startsWith(route))) {
        navigate('/signin', { replace: true });
        return;
      }
      
      // For other routes, allow preview access
    }
  }, [isAuthenticated, isAdmin, isLoading, isPreview, requireAuth, requireAdmin, allowPreview, location.pathname, navigate]);

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Don't render children if user doesn't meet requirements
  if (requireAuth && !isAuthenticated) {
    return null;
  }

  if (requireAdmin && !isAdmin) {
    return null;
  }

  // Allow preview users if explicitly allowed or on allowed routes
  if (isPreview && requireAuth) {
    const currentPath = location.pathname;
    if (!allowPreview && !previewAllowedRoutes.includes(currentPath)) {
      return null;
    }
  }

  return <>{children}</>;
};

export default RouteGuard;
