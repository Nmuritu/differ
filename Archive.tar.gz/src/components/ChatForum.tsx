/**
 * Chat Forum Component
 * 
 * A responsive real-time chat interface that facilitates communication between
 * clients and administrators in the Thika Mains Hostels application. The component
 * provides different views for clients and admins with appropriate functionality
 * for each user type.
 * 
 * Features:
 * - Real-time messaging between clients and admins
 * - Responsive design for mobile and desktop
 * - Conversation management for admins
 * - Message history and persistence
 * - Auto-scroll to latest messages
 * - Typing indicators and message status
 */

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, MessageSquare, Clock, User, Bot } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import ChatService, { ChatMessage, ChatThread } from '@/services/ChatService';

interface ChatForumProps {
  isAdmin?: boolean;
  selectedConversationId?: string;
  onConversationSelect?: (conversationId: string) => void;
}

const ChatForum = ({ isAdmin = false, selectedConversationId, onConversationSelect }: ChatForumProps) => {
  const { user } = useAuth();
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<ChatThread | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversations, setConversations] = useState<ChatThread[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatService = ChatService.getInstance();

  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load conversations and messages
  useEffect(() => {
    loadConversations();
    
    // Listen for real-time updates
    const handleChatUpdate = (event: CustomEvent) => {
      const { threadId, message } = event.detail;
      if (threadId === conversation?.id) {
        loadMessages(threadId);
      }
      loadConversations(); // Refresh conversation list
    };

    window.addEventListener('chatMessageUpdate', handleChatUpdate as EventListener);
    
    return () => {
      window.removeEventListener('chatMessageUpdate', handleChatUpdate as EventListener);
    };
  }, [conversation?.id]);

  // Load messages when conversation changes
  useEffect(() => {
    if (selectedConversationId) {
      loadMessages(selectedConversationId);
    }
  }, [selectedConversationId]);

  const loadConversations = () => {
    if (isAdmin) {
      setConversations(chatService.getAdminThreads());
    } else if (user && user.id) {
      setConversations(chatService.getClientThreads(user.id));
    }
  };

  const loadMessages = (conversationId: string) => {
    const conv = conversations.find(c => c.id === conversationId);
    if (conv) {
      setConversation(conv);
      setMessages(chatService.getThreadMessages(conversationId));
      
      // Mark as read
      if (user && user.id) {
        chatService.markMessagesAsRead(conversationId, user.id);
      }
    }
  };

  const sendMessage = async () => {
    if (!message.trim() || !user || !user.id || !user.username) return;

    setIsLoading(true);
    try {
      let currentConversation = conversation;
      
      // Create conversation if it doesn't exist
      if (!currentConversation) {
        currentConversation = chatService.createThread(user.id, user.username, 'Support Request', 'medium');
        setConversation(currentConversation);
        loadConversations();
      }

      // Send message
      const newMessage = chatService.sendMessage(
        currentConversation.id,
        user.id,
        user.username,
        'client',
        message.trim()
      );

      setMessages(prev => [...prev, newMessage]);
      setMessage('');
      loadConversations();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (isAdmin) {
    return (
      <div className="h-full flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Admin Chat Forum
          </CardTitle>
        </CardHeader>
        
        <div className="flex-1 flex flex-col lg:flex-row">
          {/* Conversations List */}
          <div className="w-full lg:w-1/3 border-r-0 lg:border-r p-4 border-b lg:border-b-0">
            <h3 className="font-semibold mb-3">Conversations</h3>
            <ScrollArea className="h-48 lg:h-96">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  className={`p-3 mb-2 rounded-lg cursor-pointer transition-colors ${
                    selectedConversationId === conv.id
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted hover:bg-muted/80'
                  }`}
                  onClick={() => onConversationSelect?.(conv.id)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">{conv.clientName}</p>
                      <p className="text-sm opacity-75 truncate">
                        {conv.lastMessage?.message || 'No messages yet'}
                      </p>
                    </div>
                    {conv.unreadCount > 0 && (
                      <Badge variant="destructive" className="ml-2">
                        {conv.unreadCount}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs opacity-60 mt-1">
                    {conv.lastMessage?.timestamp && formatTime(new Date(conv.lastMessage.timestamp).toISOString())}
                  </p>
                </div>
              ))}
            </ScrollArea>
          </div>

          {/* Messages Area */}
          <div className="flex-1 flex flex-col min-h-0">
            {selectedConversationId ? (
              <>
                <div className="p-4 border-b">
                  <h3 className="font-semibold">
                    {conversation?.clientName} 
                    {conversation?.adminId && (
                      <span className="text-sm text-muted-foreground ml-2">
                        (Assigned to {conversation.adminName})
                      </span>
                    )}
                  </h3>
                </div>
                
                <ScrollArea className="flex-1 p-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`mb-4 flex ${
                        msg.senderType === 'admin' ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          msg.senderType === 'admin'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {msg.senderType === 'admin' ? (
                            <Bot className="h-4 w-4" />
                          ) : (
                            <User className="h-4 w-4" />
                          )}
                          <span className="text-sm font-medium">{msg.senderName}</span>
                        </div>
                        <p className="text-sm">{msg.message}</p>
                        <p className="text-xs opacity-60 mt-1">
                          {formatTime(new Date(msg.timestamp).toISOString())}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </ScrollArea>

                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Type your message..."
                      disabled={isLoading}
                      className="flex-1"
                    />
                    <Button onClick={sendMessage} disabled={isLoading || !message.trim()} size="sm">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select a conversation to start chatting</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Client view
  return (
    <div className="h-full flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Contact Support
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col">
        {!user || !user.id || !user.username ? (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Please sign in to use the chat feature</p>
            </div>
          </div>
        ) : (
          <>
            {conversation ? (
          <>
            <div className="flex-1 mb-4">
              <ScrollArea className="h-96">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`mb-4 flex ${
                      msg.senderType === 'client' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        msg.senderType === 'client'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {msg.senderType === 'client' ? (
                          <User className="h-4 w-4" />
                        ) : (
                          <Bot className="h-4 w-4" />
                        )}
                        <span className="text-sm font-medium">{msg.senderName}</span>
                      </div>
                      <p className="text-sm">{msg.message}</p>
                      <p className="text-xs opacity-60 mt-1">
                        {formatTime(new Date(msg.timestamp).toISOString())}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </ScrollArea>
            </div>

            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button onClick={sendMessage} disabled={isLoading || !message.trim()} size="sm">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Start a conversation with our support team</p>
              <Button 
                className="mt-4" 
                onClick={() => {
                  if (user && user.id && user.username) {
                    const conv = chatService.createThread(user.id, user.username, 'Support Request', 'medium');
                    setConversation(conv);
                    loadConversations();
                  }
                }}
              >
                Start Chat
              </Button>
            </div>
          </div>
        )}
          </>
        )}
      </CardContent>
    </div>
  );
};

export default ChatForum;
