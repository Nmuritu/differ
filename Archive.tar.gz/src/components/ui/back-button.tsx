import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Home } from 'lucide-react';
import { useBackNavigation } from '@/hooks/useBackNavigation';
import { cn } from '@/lib/utils';

interface BackButtonProps {
  variant?: 'back' | 'home' | 'both';
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'default' | 'lg';
}

/**
 * BackButton Component
 * 
 * Provides consistent back navigation across all pages.
 * Can show back button, home button, or both.
 */
export const BackButton: React.FC<BackButtonProps> = ({
  variant = 'both',
  className,
  showText = true,
  size = 'default'
}) => {
  const { goBack, goHome } = useBackNavigation();

  if (variant === 'back') {
    return (
      <Button
        variant="outline"
        size={size}
        onClick={goBack}
        className={cn("flex items-center gap-2", className)}
      >
        <ArrowLeft className="h-4 w-4" />
        {showText && "Back"}
      </Button>
    );
  }

  if (variant === 'home') {
    return (
      <Button
        variant="outline"
        size={size}
        onClick={goHome}
        className={cn("flex items-center gap-2", className)}
      >
        <Home className="h-4 w-4" />
        {showText && "Home"}
      </Button>
    );
  }

  // Both buttons
  return (
    <div className={cn("flex gap-2", className)}>
      <Button
        variant="outline"
        size={size}
        onClick={goBack}
        className="flex items-center gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        {showText && "Back"}
      </Button>
      <Button
        variant="outline"
        size={size}
        onClick={goHome}
        className="flex items-center gap-2"
      >
        <Home className="h-4 w-4" />
        {showText && "Home"}
      </Button>
    </div>
  );
};

export default BackButton;
