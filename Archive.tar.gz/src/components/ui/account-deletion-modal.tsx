import { useState } from 'react';
import { X, AlertTriangle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/NewAuthContext';

interface AccountDeletionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const securityQuestions = [
  "What is your current email address?",
  "What is your phone number?",
  "What is your username?"
];

export function AccountDeletionModal({ isOpen, onClose }: AccountDeletionModalProps) {
  const { user, requestAccountDeletion, cancelAccountDeletion } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>(['', '', '']);
  const [isDeletionRequested, setIsDeletionRequested] = useState(false);
  const [deletionDate, setDeletionDate] = useState<string>('');

  const handleAnswerChange = (answer: string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answer;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < securityQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // All questions answered, verify answers
      const isEmailCorrect = answers[0].toLowerCase() === user?.email?.toLowerCase();
      const isPhoneCorrect = answers[1] === user?.phone;
      const isUsernameCorrect = answers[2].toLowerCase() === user?.username?.toLowerCase();

      if (isEmailCorrect && isPhoneCorrect && isUsernameCorrect) {
        // All answers correct, proceed with deletion request
        requestAccountDeletion();
        setIsDeletionRequested(true);
        setDeletionDate(new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString());
      } else {
        alert('One or more answers are incorrect. Please try again.');
        setCurrentQuestion(0);
        setAnswers(['', '', '']);
      }
    }
  };

  const handleCancelDeletion = () => {
    cancelAccountDeletion();
    setIsDeletionRequested(false);
    setCurrentQuestion(0);
    setAnswers(['', '', '']);
    onClose();
  };

  const handleClose = () => {
    if (!isDeletionRequested) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-lg font-semibold text-destructive">
            {isDeletionRequested ? 'Account Deletion Requested' : 'Delete Account'}
          </CardTitle>
          {!isDeletionRequested && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {!isDeletionRequested ? (
            <>
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Warning:</strong> This action cannot be undone. All your data will be permanently deleted.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  To confirm account deletion, please answer the following security questions:
                </p>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    Question {currentQuestion + 1} of {securityQuestions.length}:
                  </label>
                  <p className="text-sm">{securityQuestions[currentQuestion]}</p>
                  <input
                    type="text"
                    value={answers[currentQuestion]}
                    onChange={(e) => handleAnswerChange(e.target.value)}
                    className="w-full p-2 border rounded-md"
                    placeholder="Your answer..."
                  />
                </div>

                <div className="flex gap-3">
                  <Button variant="outline" onClick={handleClose} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={handleNext}
                    className="flex-1"
                    disabled={!answers[currentQuestion].trim()}
                  >
                    {currentQuestion < securityQuestions.length - 1 ? 'Next' : 'Delete Account'}
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <>
              <Alert>
                <Clock className="h-4 w-4" />
                <AlertDescription>
                  <strong>Account deletion scheduled for {deletionDate}</strong>
                  <br />
                  You have 3 days to cancel this request. After this period, your account will be permanently deleted.
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  If you change your mind, you can cancel the deletion request anytime before the scheduled date.
                </p>

                <Button 
                  variant="outline" 
                  onClick={handleCancelDeletion}
                  className="w-full"
                >
                  Cancel Deletion Request
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
