import { Room } from '@/types/booking';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Users, Wifi, Bed, CheckCircle, XCircle } from 'lucide-react';

interface RoomCardProps {
  room: Room;
  onSelect?: (roomId: string) => void;
  isSelected?: boolean;
}

const RoomCard = ({ room, onSelect, isSelected = false }: RoomCardProps) => {
  const getRoomTypeLabel = (type: string) => {
    switch (type) {
      case 'single':
        return 'Single Room';
      case 'double':
        return 'Double Room';
      case 'suite':
        return 'Suite';
      default:
        return type;
    }
  };

  const getStatusIcon = (isAvailable: boolean) => {
    return isAvailable ? (
      <CheckCircle className="h-4 w-4 text-success" />
    ) : (
      <XCircle className="h-4 w-4 text-destructive" />
    );
  };

  /**
   * Handle card click for intuitive room selection
   * - First click: Selects the room
   * - Second click: Deselects the room (if already selected)
   * Only works for available rooms
   */
  const handleCardClick = () => {
    if (room.isAvailable && onSelect) {
      onSelect(room.id);
    }
  };

  return (
    <Card 
      className={`transition-all duration-300 hover:shadow-card-hover cursor-pointer ${
        isSelected ? 'ring-2 ring-primary' : ''
      } ${!room.isAvailable ? 'opacity-60' : ''}`}
      onClick={handleCardClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">{getRoomTypeLabel(room.type)}</h3>
          <div className="flex items-center gap-2">
            {getStatusIcon(room.isAvailable)}
            <Badge variant={room.isAvailable ? 'default' : 'destructive'}>
              {room.isAvailable ? 'Available' : 'Booked'}
            </Badge>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>Up to {room.maxOccupancy}</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="aspect-video bg-muted rounded-lg overflow-hidden">
          <img 
            src={room.image} 
            alt={`${getRoomTypeLabel(room.type)} interior`}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Features</h4>
          <div className="flex flex-wrap gap-2">
            {room.features.map((feature, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {feature}
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>

      <CardFooter className="flex items-center justify-between pt-4">
        <div>
          <span className="text-2xl font-bold text-primary">
            KSh {room.price.toLocaleString()}
          </span>
          <span className="text-sm text-muted-foreground">/month</span>
        </div>
        
        {room.isAvailable && onSelect && (
          <Button
            onClick={(e) => {
              e.stopPropagation(); // Prevent card click when clicking button
              onSelect(room.id);
            }}
            variant={isSelected ? "success" : "default"}
            size="sm"
          >
            {isSelected ? '✓ Selected' : 'Select Room'}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default RoomCard;