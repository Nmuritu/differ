import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

interface OTPInputProps {
  length?: number;
  onComplete: (otp: string) => void;
  onResend?: () => void;
  loading?: boolean;
  error?: string;
  success?: string;
  resendCooldown?: number;
  className?: string;
}

/**
 * OTP Input Component
 * 
 * Provides a user-friendly interface for entering OTP codes with:
 * - Individual digit inputs with auto-focus
 * - Paste support for full OTP
 * - Resend functionality with cooldown
 * - Error and success states
 * - Keyboard navigation
 */
export const OTPInput: React.FC<OTPInputProps> = ({
  length = 6,
  onComplete,
  onResend,
  loading = false,
  error,
  success,
  resendCooldown = 60,
  className = ''
}) => {
  const [otp, setOtp] = useState<string[]>(new Array(length).fill(''));
  const [resendTimer, setResendTimer] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Handle resend cooldown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resendTimer]);

  // Focus first input on mount
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleChange = (index: number, value: string) => {
    // Only allow digits
    const digit = value.replace(/\D/g, '').slice(-1);
    
    const newOtp = [...otp];
    newOtp[index] = digit;
    setOtp(newOtp);

    // Auto-focus next input
    if (digit && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }

    // Check if OTP is complete
    if (newOtp.every(d => d !== '') && newOtp.join('').length === length) {
      onComplete(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace') {
      if (otp[index] === '' && index > 0) {
        // Move to previous input if current is empty
        inputRefs.current[index - 1]?.focus();
      } else {
        // Clear current input
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '');
    
    if (pastedData.length === length) {
      const newOtp = pastedData.split('');
      setOtp(newOtp);
      onComplete(pastedData);
      
      // Focus last input
      inputRefs.current[length - 1]?.focus();
    }
  };

  const handleResend = () => {
    if (onResend && resendTimer === 0) {
      onResend();
      setResendTimer(resendCooldown);
      // Clear current OTP
      setOtp(new Array(length).fill(''));
      // Focus first input
      inputRefs.current[0]?.focus();
    }
  };

  const clearOTP = () => {
    setOtp(new Array(length).fill(''));
    inputRefs.current[0]?.focus();
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* OTP Input Fields */}
      <div className="flex justify-center space-x-2">
        {otp.map((digit, index) => (
          <Input
            key={index}
            ref={el => inputRefs.current[index] = el}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={digit}
            onChange={e => handleChange(index, e.target.value)}
            onKeyDown={e => handleKeyDown(index, e)}
            onPaste={handlePaste}
            disabled={loading}
            className={`w-12 h-12 text-center text-lg font-semibold ${
              error ? 'border-destructive' : success ? 'border-green-500' : ''
            }`}
            autoComplete="off"
          />
        ))}
      </div>

      {/* Status Messages */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800 dark:text-green-200">
            {success}
          </AlertDescription>
        </Alert>
      )}

      {/* Resend Button */}
      {onResend && (
        <div className="flex justify-center">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleResend}
            disabled={resendTimer > 0 || loading}
            className="text-sm"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            {resendTimer > 0 
              ? `Resend OTP in ${resendTimer}s` 
              : 'Resend OTP'
            }
          </Button>
        </div>
      )}

      {/* Helper Text */}
      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          Enter the 6-digit code sent to your {onResend ? 'phone/email' : 'device'}
        </p>
        {otp.some(d => d !== '') && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={clearOTP}
            className="text-xs mt-1"
          >
            Clear
          </Button>
        )}
      </div>
    </div>
  );
};

export default OTPInput;
