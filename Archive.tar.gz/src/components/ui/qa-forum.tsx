import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Search, 
  Filter, 
  Plus, 
  ThumbsUp, 
  Reply, 
  Clock,
  User,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Users,
  Shield,
  Bell,
  Send
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';

/**
 * Q&A Forum Component
 * 
 * Provides a community-driven question and answer system where users can:
 * - Ask questions and get answers from the community
 * - Search for existing questions and answers
 * - Vote on helpful answers
 * - Filter questions by category and status
 * - Get direct admin responses for complex issues
 * 
 * Features:
 * - Real-time question posting
 * - Community voting system
 * - Admin moderation and responses
 * - Search and filtering capabilities
 * - User reputation system
 */
interface Question {
  id: string;
  title: string;
  content: string;
  author: string;
  category: string;
  status: 'open' | 'answered' | 'closed';
  votes: number;
  answers: Answer[];
  createdAt: Date;
  tags: string[];
}

interface Answer {
  id: string;
  content: string;
  author: string;
  isAdmin: boolean;
  votes: number;
  isAccepted: boolean;
  createdAt: Date;
}

interface TenantDiscussion {
  id: string;
  title: string;
  content: string;
  author: string;
  authorPlan: string;
  category: 'general' | 'maintenance' | 'events' | 'complaints' | 'suggestions';
  likes: number;
  comments: DiscussionComment[];
  createdAt: Date;
  isPinned: boolean;
  isLocked: boolean;
}

interface DiscussionComment {
  id: string;
  content: string;
  author: string;
  isAdmin: boolean;
  likes: number;
  createdAt: Date;
  replies: DiscussionComment[];
}

interface AdminAnnouncement {
  id: string;
  title: string;
  content: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isRead: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

interface QAForumProps {
  className?: string;
}

export const QAForum: React.FC<QAForumProps> = ({ className }) => {
  const { user, isAuthenticated } = useAuth();
  
  // Q&A Forum state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showNewQuestion, setShowNewQuestion] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    title: '',
    content: '',
    category: '',
    tags: ''
  });

  // Tenant Discussion state
  const [activeTab, setActiveTab] = useState('qa');
  const [discussionSearchQuery, setDiscussionSearchQuery] = useState('');
  const [selectedDiscussionCategory, setSelectedDiscussionCategory] = useState('all');
  const [showNewDiscussion, setShowNewDiscussion] = useState(false);
  const [newDiscussion, setNewDiscussion] = useState({
    title: '',
    content: '',
    category: 'general' as const
  });
  const [selectedDiscussion, setSelectedDiscussion] = useState<string | null>(null);
  const [newComment, setNewComment] = useState('');

  /**
   * Mock questions data - in a real app, this would come from an API
   */
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: '1',
      title: 'How do I change my room plan after booking?',
      content: 'I booked a single room but now I want to upgrade to a double room. Is this possible and how do I do it?',
      author: 'john_doe',
      category: 'booking',
      status: 'answered',
      votes: 12,
      tags: ['room-plan', 'upgrade', 'booking'],
      createdAt: new Date('2024-01-15'),
      answers: [
        {
          id: '1',
          content: 'Yes, you can upgrade your room plan! Go to your Profile page, find your current booking, and click "Change Plan". You\'ll need to pay the difference in cost.',
          author: 'admin_support',
          isAdmin: true,
          votes: 8,
          isAccepted: true,
          createdAt: new Date('2024-01-15')
        }
      ]
    },
    {
      id: '2',
      title: 'Payment failed but money was deducted from my account',
      content: 'I tried to pay for my room but the payment failed. However, I can see the money was deducted from my M-Pesa account. What should I do?',
      author: 'mary_smith',
      category: 'payment',
      status: 'answered',
      votes: 5,
      tags: ['payment', 'mpesa', 'refund'],
      createdAt: new Date('2024-01-14'),
      answers: [
        {
          id: '2',
          content: 'This is a common issue with M-Pesa. The money will be automatically refunded within 24-48 hours. If it doesn\'t appear, contact our support team with your transaction ID.',
          author: 'admin_support',
          isAdmin: true,
          votes: 6,
          isAccepted: true,
          createdAt: new Date('2024-01-14')
        }
      ]
    },
    {
      id: '3',
      title: 'Can I get a receipt for my payment?',
      content: 'I need a receipt for my monthly payment for accounting purposes. How can I get one?',
      author: 'peter_wilson',
      category: 'payment',
      status: 'answered',
      votes: 3,
      tags: ['receipt', 'payment', 'accounting'],
      createdAt: new Date('2024-01-13'),
      answers: [
        {
          id: '3',
          content: 'Yes! Go to your Profile page, scroll down to "Payment History", and click "Receipt" next to any payment. It will download as a text file.',
          author: 'community_helper',
          isAdmin: false,
          votes: 4,
          isAccepted: true,
          createdAt: new Date('2024-01-13')
        }
      ]
    },
    {
      id: '4',
      title: 'App keeps crashing when I try to upload my profile picture',
      content: 'Every time I try to upload a profile picture, the app crashes. I\'m using an iPhone. Any solutions?',
      author: 'sarah_jones',
      category: 'technical',
      status: 'open',
      votes: 2,
      tags: ['profile-picture', 'crash', 'ios', 'upload'],
      createdAt: new Date('2024-01-12'),
      answers: []
    },
    {
      id: '5',
      title: 'What are the different room types available?',
      content: 'I\'m new to the platform and want to understand what room options are available. Can someone explain the differences?',
      author: 'new_user_123',
      category: 'general',
      status: 'answered',
      votes: 7,
      tags: ['room-types', 'accommodation', 'new-user'],
      createdAt: new Date('2024-01-11'),
      answers: [
        {
          id: '4',
          content: 'We have three room types: 1) Single Room (KSh 4,500/month) - Private room with shared bathroom, 2) Double Room (KSh 6,000/month) - Spacious room with private bathroom, 3) Suite (KSh 8,500/month) - Luxury suite with private balcony.',
          author: 'admin_support',
          isAdmin: true,
          votes: 9,
          isAccepted: true,
          createdAt: new Date('2024-01-11')
        }
      ]
    }
  ]);

  /**
   * Mock tenant discussions data
   */
  const [discussions, setDiscussions] = useState<TenantDiscussion[]>([
    {
      id: 'd1',
      title: 'Water pressure issues in Block A',
      content: 'Has anyone else noticed low water pressure in Block A? It\'s been happening for the past few days, especially in the morning.',
      author: 'sarah_jones',
      authorPlan: 'Single Room',
      category: 'maintenance',
      likes: 8,
      isPinned: false,
      isLocked: false,
      createdAt: new Date('2024-01-16'),
      comments: [
        {
          id: 'c1',
          content: 'Yes, I\'ve noticed this too! It\'s really frustrating when trying to shower in the morning.',
          author: 'mike_wilson',
          isAdmin: false,
          likes: 3,
          createdAt: new Date('2024-01-16'),
          replies: []
        },
        {
          id: 'c2',
          content: 'We\'re aware of the water pressure issue in Block A. Our maintenance team is working on it and it should be resolved by tomorrow. We apologize for the inconvenience.',
          author: 'admin_support',
          isAdmin: true,
          likes: 5,
          createdAt: new Date('2024-01-16'),
          replies: []
        }
      ]
    },
    {
      id: 'd2',
      title: 'Movie night this Friday!',
      content: 'Hey everyone! I\'m organizing a movie night this Friday at 7 PM in the common area. We\'ll be watching a comedy. Bring your own snacks and drinks!',
      author: 'alex_chen',
      authorPlan: 'Double Room',
      category: 'events',
      likes: 12,
      isPinned: true,
      isLocked: false,
      createdAt: new Date('2024-01-15'),
      comments: [
        {
          id: 'c3',
          content: 'Count me in! What movie are we watching?',
          author: 'lisa_park',
          isAdmin: false,
          likes: 2,
          createdAt: new Date('2024-01-15'),
          replies: []
        }
      ]
    },
    {
      id: 'd3',
      title: 'Suggestion: Add more study spaces',
      content: 'I think we need more quiet study spaces around the hostel. The library is always full and the common area can be noisy. Maybe we could convert one of the unused rooms?',
      author: 'david_kim',
      authorPlan: 'Suite',
      category: 'suggestions',
      likes: 15,
      isPinned: false,
      isLocked: false,
      createdAt: new Date('2024-01-14'),
      comments: [
        {
          id: 'c4',
          content: 'Great suggestion! I\'d definitely use a quiet study space.',
          author: 'emma_rodriguez',
          isAdmin: false,
          likes: 4,
          createdAt: new Date('2024-01-14'),
          replies: []
        },
        {
          id: 'c5',
          content: 'We appreciate this feedback! We\'re currently looking into creating additional study spaces. We\'ll update everyone once we have more details.',
          author: 'admin_support',
          isAdmin: true,
          likes: 8,
          createdAt: new Date('2024-01-14'),
          replies: []
        }
      ]
    }
  ]);

  /**
   * Mock admin announcements
   */
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([
    {
      id: 'a1',
      title: 'Scheduled Maintenance - Water System',
      content: 'We will be performing maintenance on the water system tomorrow from 2-4 PM. Water may be temporarily unavailable during this time.',
      priority: 'high',
      isRead: false,
      createdAt: new Date('2024-01-16'),
      expiresAt: new Date('2024-01-18')
    },
    {
      id: 'a2',
      title: 'New Security Measures',
      content: 'Starting next week, we\'re implementing new security measures including enhanced CCTV monitoring and visitor registration requirements.',
      priority: 'medium',
      isRead: true,
      createdAt: new Date('2024-01-15')
    }
  ]);

  /**
   * Categories for filtering questions
   */
  const categories = [
    { id: 'all', label: 'All Categories', icon: '' },
    { id: 'booking', label: 'Booking', icon: '' },
    { id: 'payment', label: 'Payment', icon: '💳' },
    { id: 'account', label: 'Account', icon: '' },
    { id: 'technical', label: 'Technical', icon: '' },
    { id: 'general', label: 'General', icon: '❓' }
  ];

  /**
   * Status options for filtering
   */
  const statusOptions = [
    { id: 'all', label: 'All Questions', icon: '' },
    { id: 'open', label: 'Open', icon: '🔓' },
    { id: 'answered', label: 'Answered', icon: '' },
    { id: 'closed', label: 'Closed', icon: '' }
  ];

  /**
   * Filter questions based on search query, category, and status
   */
  const filteredQuestions = questions.filter(question => {
    const matchesSearch = question.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         question.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         question.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || question.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || question.status === selectedStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  /**
   * Handle voting on questions
   * @param questionId - ID of the question to vote on
   */
  const handleVoteQuestion = (questionId: string) => {
    setQuestions(prev => prev.map(q => 
      q.id === questionId ? { ...q, votes: q.votes + 1 } : q
    ));
  };

  /**
   * Handle voting on answers
   * @param questionId - ID of the question containing the answer
   * @param answerId - ID of the answer to vote on
   */
  const handleVoteAnswer = (questionId: string, answerId: string) => {
    setQuestions(prev => prev.map(q => 
      q.id === questionId 
        ? {
            ...q,
            answers: q.answers.map(a => 
              a.id === answerId ? { ...a, votes: a.votes + 1 } : a
            )
          }
        : q
    ));
  };

  /**
   * Handle submitting a new question
   */
  const handleSubmitQuestion = () => {
    if (!newQuestion.title.trim() || !newQuestion.content.trim() || !newQuestion.category) {
      return;
    }

    const question: Question = {
      id: Date.now().toString(),
      title: newQuestion.title,
      content: newQuestion.content,
      author: user?.username || 'anonymous',
      category: newQuestion.category,
      status: 'open',
      votes: 0,
      answers: [],
      createdAt: new Date(),
      tags: newQuestion.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
    };

    setQuestions(prev => [question, ...prev]);
    setNewQuestion({ title: '', content: '', category: '', tags: '' });
    setShowNewQuestion(false);
  };

  /**
   * Get status badge color
   */
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-yellow-100 text-yellow-800';
      case 'answered': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MessageSquare className="h-6 w-6" />
            Community Forum
          </h2>
          <p className="text-muted-foreground">
            Connect with other tenants and get support from the community
          </p>
        </div>
      </div>

      {/* Tabs for different forum sections */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="qa" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            Q&A Forum
          </TabsTrigger>
          <TabsTrigger value="discussions" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Tenant Discussions
          </TabsTrigger>
          <TabsTrigger value="announcements" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Admin Announcements
          </TabsTrigger>
        </TabsList>

        {/* Q&A Forum Tab */}
        <TabsContent value="qa" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold">Q&A Forum</h3>
              <p className="text-muted-foreground">
                Ask questions and get answers from the community
              </p>
            </div>
            {isAuthenticated && (
              <Button onClick={() => setShowNewQuestion(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Ask Question
              </Button>
            )}
          </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search questions..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span className="text-sm font-medium">Filter by:</span>
              </div>
              
              <div className="flex gap-2">
                {categories.map(category => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="mr-1">{category.icon}</span>
                    {category.label}
                  </Button>
                ))}
              </div>

              <div className="flex gap-2">
                {statusOptions.map(status => (
                  <Button
                    key={status.id}
                    variant={selectedStatus === status.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedStatus(status.id)}
                  >
                    <span className="mr-1">{status.icon}</span>
                    {status.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* New Question Form */}
      {showNewQuestion && (
        <Card>
          <CardHeader>
            <CardTitle>Ask a New Question</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Question Title</label>
              <Input
                placeholder="What's your question?"
                value={newQuestion.title}
                onChange={(e) => setNewQuestion(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <textarea
                className="w-full p-3 border rounded-lg resize-none"
                rows={4}
                placeholder="Provide more details about your question..."
                value={newQuestion.content}
                onChange={(e) => setNewQuestion(prev => ({ ...prev, content: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Category</label>
                <select
                  className="w-full p-2 border rounded-lg"
                  value={newQuestion.category}
                  onChange={(e) => setNewQuestion(prev => ({ ...prev, category: e.target.value }))}
                >
                  <option value="">Select category</option>
                  {categories.slice(1).map(category => (
                    <option key={category.id} value={category.id}>
                      {category.icon} {category.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Tags (comma-separated)</label>
                <Input
                  placeholder="e.g., payment, mpesa, refund"
                  value={newQuestion.tags}
                  onChange={(e) => setNewQuestion(prev => ({ ...prev, tags: e.target.value }))}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSubmitQuestion}>
                Submit Question
              </Button>
              <Button variant="outline" onClick={() => setShowNewQuestion(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Questions List */}
      <div className="space-y-4">
        {filteredQuestions.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <HelpCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No questions found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filters, or ask a new question.
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredQuestions.map(question => (
            <Card key={question.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Question Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2">{question.title}</h3>
                      <p className="text-muted-foreground mb-3">{question.content}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {question.author}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {question.createdAt.toLocaleDateString()}
                        </div>
                        <Badge className={getStatusColor(question.status)}>
                          {question.status}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleVoteQuestion(question.id)}
                      >
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        {question.votes}
                      </Button>
                    </div>
                  </div>

                  {/* Tags */}
                  {question.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {question.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Answers */}
                  {question.answers.length > 0 && (
                    <div className="space-y-3 pt-4 border-t">
                      <h4 className="font-medium flex items-center gap-2">
                        <Reply className="h-4 w-4" />
                        Answers ({question.answers.length})
                      </h4>
                      
                      {question.answers.map(answer => (
                        <div key={answer.id} className="bg-muted/50 p-4 rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">
                                {answer.author}
                                {answer.isAdmin && (
                                  <Badge variant="default" className="ml-2 text-xs">
                                    Admin
                                  </Badge>
                                )}
                              </span>
                              {answer.isAccepted && (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleVoteAnswer(question.id, answer.id)}
                              >
                                <ThumbsUp className="h-3 w-3 mr-1" />
                                {answer.votes}
                              </Button>
                            </div>
                          </div>
                          <p className="text-sm">{answer.content}</p>
                          <div className="text-xs text-muted-foreground mt-2">
                            {answer.createdAt.toLocaleDateString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* No answers message */}
                  {question.answers.length === 0 && question.status === 'open' && (
                    <div className="text-center py-4 text-muted-foreground">
                      <p className="text-sm">No answers yet. Be the first to help!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
          </div>
        </TabsContent>

        {/* Tenant Discussions Tab */}
        <TabsContent value="discussions" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold">Tenant Discussions</h3>
              <p className="text-muted-foreground">
                Connect with other tenants, share experiences, and discuss hostel life
              </p>
            </div>
            {isAuthenticated && (
              <Button onClick={() => setShowNewDiscussion(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Start Discussion
              </Button>
            )}
          </div>

          {/* Discussion Search and Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search discussions..."
                        value={discussionSearchQuery}
                        onChange={(e) => setDiscussionSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {[
                    { id: 'all', label: 'All', icon: '' },
                    { id: 'general', label: 'General', icon: '💬' },
                    { id: 'maintenance', label: 'Maintenance', icon: '' },
                    { id: 'events', label: 'Events', icon: '' },
                    { id: 'complaints', label: 'Complaints', icon: '' },
                    { id: 'suggestions', label: 'Suggestions', icon: '' }
                  ].map(category => (
                    <Button
                      key={category.id}
                      variant={selectedDiscussionCategory === category.id ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedDiscussionCategory(category.id)}
                    >
                      <span className="mr-1">{category.icon}</span>
                      {category.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Discussions List */}
          <div className="space-y-4">
            {discussions
              .filter(discussion => 
                (selectedDiscussionCategory === 'all' || discussion.category === selectedDiscussionCategory) &&
                (discussion.title.toLowerCase().includes(discussionSearchQuery.toLowerCase()) ||
                 discussion.content.toLowerCase().includes(discussionSearchQuery.toLowerCase()))
              )
              .map((discussion) => (
                <Card key={discussion.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            {discussion.isPinned && (
                              <Badge variant="secondary" className="text-xs">Pinned</Badge>
                            )}
                            {discussion.isLocked && (
                              <Badge variant="destructive" className="text-xs">Locked</Badge>
                            )}
                            <Badge variant="outline" className="text-xs">
                              {discussion.category}
                            </Badge>
                          </div>
                          <h3 className="text-lg font-semibold">{discussion.title}</h3>
                          <p className="text-muted-foreground">{discussion.content}</p>
                        </div>
                        <div className="text-right text-sm text-muted-foreground">
                          <div>{discussion.likes} likes</div>
                          <div>{discussion.comments.length} comments</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {discussion.author}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {discussion.createdAt.toLocaleDateString()}
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {discussion.authorPlan}
                          </Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <ThumbsUp className="h-4 w-4 mr-1" />
                            Like
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setSelectedDiscussion(
                              selectedDiscussion === discussion.id ? null : discussion.id
                            )}
                          >
                            <Reply className="h-4 w-4 mr-1" />
                            {selectedDiscussion === discussion.id ? 'Hide' : 'Comment'}
                          </Button>
                        </div>
                      </div>

                      {/* Comments Section */}
                      {selectedDiscussion === discussion.id && (
                        <div className="border-t pt-4 space-y-4">
                          <div className="space-y-3">
                            {discussion.comments.map((comment) => (
                              <div key={comment.id} className="flex gap-3">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                                  {comment.isAdmin ? (
                                    <Shield className="h-4 w-4 text-primary" />
                                  ) : (
                                    <User className="h-4 w-4 text-muted-foreground" />
                                  )}
                                </div>
                                <div className="flex-1 space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium text-sm">{comment.author}</span>
                                    {comment.isAdmin && (
                                      <Badge variant="secondary" className="text-xs">Admin</Badge>
                                    )}
                                    <span className="text-xs text-muted-foreground">
                                      {comment.createdAt.toLocaleDateString()}
                                    </span>
                                  </div>
                                  <p className="text-sm">{comment.content}</p>
                                  <div className="flex items-center gap-2">
                                    <Button variant="ghost" size="sm" className="h-6 px-2">
                                      <ThumbsUp className="h-3 w-3 mr-1" />
                                      {comment.likes}
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Add Comment */}
                          {isAuthenticated && !discussion.isLocked && (
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add a comment..."
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                className="flex-1"
                              />
                              <Button size="sm">
                                <Send className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        {/* Admin Announcements Tab */}
        <TabsContent value="announcements" className="space-y-6">
          <div>
            <h3 className="text-xl font-semibold">Admin Announcements</h3>
            <p className="text-muted-foreground">
              Important updates and announcements from the admin team
            </p>
          </div>

          <div className="space-y-4">
            {announcements.map((announcement) => (
              <Card key={announcement.id} className={`${!announcement.isRead ? 'border-primary bg-primary/5' : ''}`}>
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant={
                              announcement.priority === 'urgent' ? 'destructive' :
                              announcement.priority === 'high' ? 'default' :
                              announcement.priority === 'medium' ? 'secondary' : 'outline'
                            }
                            className="text-xs"
                          >
                            {announcement.priority.toUpperCase()}
                          </Badge>
                          {!announcement.isRead && (
                            <Badge variant="default" className="text-xs">NEW</Badge>
                          )}
                        </div>
                        <h3 className="text-lg font-semibold">{announcement.title}</h3>
                        <p className="text-muted-foreground">{announcement.content}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Shield className="h-4 w-4" />
                        Admin Team
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {announcement.createdAt.toLocaleDateString()}
                      </div>
                      {announcement.expiresAt && (
                        <div className="flex items-center gap-1">
                          <AlertCircle className="h-4 w-4" />
                          Expires: {announcement.expiresAt.toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QAForum;
