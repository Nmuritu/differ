import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Bot, 
  MessageSquare, 
  ArrowRight, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Send
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { useNavigate } from 'react-router-dom';

/**
 * Smart Help Router Component
 * 
 * Intelligently routes user questions to either AI Assistant or Admin based on:
 * - Urgency level detection
 * - Question complexity
 * - User preference
 * - Issue type classification
 * 
 * Features:
 * - Natural language processing for urgency detection
 * - Intelligent routing suggestions
 * - User choice override
 * - Quick access to both support channels
 */
interface SmartHelpRouterProps {
  className?: string;
}

export const SmartHelpRouter: React.FC<SmartHelpRouterProps> = ({ className }) => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  // State management
  const [userQuestion, setUserQuestion] = useState('');
  const [analysisResult, setAnalysisResult] = useState<{
    urgency: 'low' | 'medium' | 'high';
    recommendedRoute: 'ai' | 'admin';
    confidence: number;
    reasoning: string;
  } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  /**
   * Urgency detection keywords and patterns
   */
  const urgencyPatterns = {
    high: [
      'urgent', 'emergency', 'immediately', 'asap', 'critical', 'broken', 
      'not working', 'error', 'failed', 'stuck', 'can\'t access', 'locked out',
      'hacked', 'security', 'fraud', 'stolen', 'payment failed', 'can\'t pay',
      'account hacked', 'suspended', 'banned', 'deleted', 'lost access'
    ],
    medium: [
      'problem', 'issue', 'trouble', 'difficulty', 'confused', 'unclear',
      'help needed', 'support', 'question', 'inquiry', 'concern', 'worry'
    ],
    low: [
      'how to', 'what is', 'explain', 'tell me', 'show me', 'guide',
      'tutorial', 'learn', 'understand', 'curious', 'wondering'
    ]
  };

  /**
   * Admin-required keywords (complex issues that need human intervention)
   */
  const adminRequiredKeywords = [
    'refund', 'cancellation', 'dispute', 'complaint', 'escalate', 'manager',
    'supervisor', 'billing error', 'wrong charge', 'double charge', 'overcharge',
    'account deletion', 'data export', 'privacy', 'gdpr', 'legal', 'terms',
    'policy', 'violation', 'abuse', 'report', 'moderation'
  ];

  /**
   * Analyze user question for urgency and routing recommendation
   * @param question - User's question or problem description
   * @returns Analysis result with urgency, recommended route, and reasoning
   */
  const analyzeQuestion = (question: string): {
    urgency: 'low' | 'medium' | 'high';
    recommendedRoute: 'ai' | 'admin';
    confidence: number;
    reasoning: string;
  } => {
    const lowercaseQuestion = question.toLowerCase();
    
    // Check for high urgency indicators
    const highUrgencyMatches = urgencyPatterns.high.filter(keyword => 
      lowercaseQuestion.includes(keyword)
    ).length;
    
    // Check for medium urgency indicators
    const mediumUrgencyMatches = urgencyPatterns.medium.filter(keyword => 
      lowercaseQuestion.includes(keyword)
    ).length;
    
    // Check for low urgency indicators
    const lowUrgencyMatches = urgencyPatterns.low.filter(keyword => 
      lowercaseQuestion.includes(keyword)
    ).length;
    
    // Check for admin-required keywords
    const adminRequiredMatches = adminRequiredKeywords.filter(keyword => 
      lowercaseQuestion.includes(keyword)
    ).length;
    
    // Determine urgency level
    let urgency: 'low' | 'medium' | 'high' = 'low';
    let confidence = 0.5;
    let reasoning = '';
    
    if (highUrgencyMatches > 0) {
      urgency = 'high';
      confidence = 0.9;
      reasoning = `Detected ${highUrgencyMatches} high-urgency indicators: ${urgencyPatterns.high.filter(k => lowercaseQuestion.includes(k)).join(', ')}`;
    } else if (mediumUrgencyMatches > 0) {
      urgency = 'medium';
      confidence = 0.7;
      reasoning = `Detected ${mediumUrgencyMatches} medium-urgency indicators: ${urgencyPatterns.medium.filter(k => lowercaseQuestion.includes(k)).join(', ')}`;
    } else if (lowUrgencyMatches > 0) {
      urgency = 'low';
      confidence = 0.8;
      reasoning = `Detected ${lowUrgencyMatches} low-urgency indicators: ${urgencyPatterns.low.filter(k => lowercaseQuestion.includes(k)).join(', ')}`;
    } else {
      urgency = 'medium';
      confidence = 0.3;
      reasoning = 'No specific urgency indicators detected, defaulting to medium priority';
    }
    
    // Determine recommended route
    let recommendedRoute: 'ai' | 'admin' = 'ai';
    
    if (adminRequiredMatches > 0) {
      recommendedRoute = 'admin';
      reasoning += ` | Admin required: ${adminRequiredKeywords.filter(k => lowercaseQuestion.includes(k)).join(', ')}`;
    } else if (urgency === 'high') {
      recommendedRoute = 'admin';
      reasoning += ' | High urgency requires admin attention';
    } else if (urgency === 'low') {
      recommendedRoute = 'ai';
      reasoning += ' | Low urgency suitable for AI assistance';
    } else {
      // Medium urgency - let user choose
      recommendedRoute = 'ai';
      reasoning += ' | Medium urgency - AI can help, but admin available if needed';
    }
    
    return {
      urgency,
      recommendedRoute,
      confidence,
      reasoning
    };
  };

  /**
   * Handle question analysis
   */
  const handleAnalyzeQuestion = async () => {
    if (!userQuestion.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate analysis delay
    setTimeout(() => {
      const result = analyzeQuestion(userQuestion);
      setAnalysisResult(result);
      setIsAnalyzing(false);
    }, 1500);
  };

  /**
   * Handle route selection
   * @param route - Selected route ('ai' or 'admin')
   */
  const handleRouteSelection = (route: 'ai' | 'admin') => {
    if (route === 'ai') {
      navigate('/ask-ai', { state: { prefillQuestion: userQuestion } });
    } else {
      navigate('/ask-admin', { state: { prefillQuestion: userQuestion } });
    }
  };

  /**
   * Get urgency badge color
   */
  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  /**
   * Get urgency icon
   */
  const getUrgencyIcon = (urgency: string) => {
    switch (urgency) {
      case 'high': return <AlertTriangle className="h-4 w-4" />;
      case 'medium': return <Clock className="h-4 w-4" />;
      case 'low': return <CheckCircle className="h-4 w-4" />;
      default: return <HelpCircle className="h-4 w-4" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5" />
            Smart Help Router
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground mb-4">
            This feature is only available to signed-in users.
          </p>
          <Button asChild>
            <a href="/signin">Sign In to Access</a>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Smart Help Router</h2>
        <p className="text-muted-foreground">
          Describe your issue and we'll route you to the best support option
        </p>
      </div>

      {/* Question Input */}
      <Card>
        <CardHeader>
          <CardTitle>What can we help you with?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Describe your question or problem..."
              value={userQuestion}
              onChange={(e) => setUserQuestion(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAnalyzeQuestion()}
            />
          </div>
          
          <Button 
            onClick={handleAnalyzeQuestion}
            disabled={!userQuestion.trim() || isAnalyzing}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Clock className="h-4 w-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Analyze & Route
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              Analysis Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-center gap-2 mb-2">
                  {getUrgencyIcon(analysisResult.urgency)}
                  <span className="font-medium">Urgency Level</span>
                </div>
                <Badge className={getUrgencyColor(analysisResult.urgency)}>
                  {analysisResult.urgency.toUpperCase()}
                </Badge>
              </div>
              
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-center gap-2 mb-2">
                  {analysisResult.recommendedRoute === 'ai' ? 
                    <Bot className="h-4 w-4" /> : 
                    <MessageSquare className="h-4 w-4" />
                  }
                  <span className="font-medium">Recommended Route</span>
                </div>
                <Badge variant="outline">
                  {analysisResult.recommendedRoute === 'ai' ? 'AI Assistant' : 'Admin Support'}
                </Badge>
              </div>
              
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <CheckCircle className="h-4 w-4" />
                  <span className="font-medium">Confidence</span>
                </div>
                <Badge variant="secondary">
                  {Math.round(analysisResult.confidence * 100)}%
                </Badge>
              </div>
            </div>
            
            <div className="p-4 bg-muted/30 rounded-lg">
              <h4 className="font-medium mb-2">Analysis Reasoning:</h4>
              <p className="text-sm text-muted-foreground">{analysisResult.reasoning}</p>
            </div>
            
            {/* Route Selection Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                onClick={() => handleRouteSelection('ai')}
                variant={analysisResult.recommendedRoute === 'ai' ? 'default' : 'outline'}
                className="h-auto p-4"
              >
                <div className="flex flex-col items-center gap-2">
                  <Bot className="h-6 w-6" />
                  <div>
                    <div className="font-medium">AI Assistant</div>
                    <div className="text-xs text-muted-foreground">
                      Instant answers for common questions
                    </div>
                  </div>
                </div>
              </Button>
              
              <Button
                onClick={() => handleRouteSelection('admin')}
                variant={analysisResult.recommendedRoute === 'admin' ? 'default' : 'outline'}
                className="h-auto p-4"
              >
                <div className="flex flex-col items-center gap-2">
                  <MessageSquare className="h-6 w-6" />
                  <div>
                    <div className="font-medium">Admin Support</div>
                    <div className="text-xs text-muted-foreground">
                      Direct human support via SMS
                    </div>
                  </div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Access */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/ask-ai')}>
          <CardContent className="p-6 text-center">
            <Bot className="h-8 w-8 text-primary mx-auto mb-3" />
            <h3 className="font-semibold mb-2">AI Assistant</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Get instant help with common questions
            </p>
            <Button variant="outline" size="sm">
              <ArrowRight className="h-4 w-4 mr-2" />
              Try AI Assistant
            </Button>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/ask-admin')}>
          <CardContent className="p-6 text-center">
            <MessageSquare className="h-8 w-8 text-primary mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Admin Support</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Direct support from our admin team
            </p>
            <Button variant="outline" size="sm">
              <ArrowRight className="h-4 w-4 mr-2" />
              Contact Admin
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SmartHelpRouter;