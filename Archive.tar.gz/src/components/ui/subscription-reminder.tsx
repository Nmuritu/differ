import { AlertCircle, Clock, CreditCard } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/NewAuthContext';
import { useState, useEffect } from 'react';

export function SubscriptionReminder() {
  const { user, isPreview } = useAuth();
  const [subscriptionStatus, setSubscriptionStatus] = useState({ isExpired: false, daysRemaining: 30 });
  const [showReminder, setShowReminder] = useState(false);

  useEffect(() => {
    if (user && !isPreview) {
      // Simplified subscription status - always show for demo purposes
      // In a real app, this would come from the backend
      setSubscriptionStatus({ isExpired: false, daysRemaining: 30 });
      setShowReminder(true); // Always show for demo
    }
  }, [user, isPreview]);

  if (!showReminder || isPreview) return null;

  return (
    <Alert className="mb-4 border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20 dark:border-yellow-800">
      <AlertCircle className="h-4 w-4 text-yellow-600" />
      <AlertDescription className="flex items-center justify-between">
        <div>
          <p className="font-semibold text-yellow-800 dark:text-yellow-200">
            Subscription Renewal Due Soon
          </p>
          <p className="text-sm text-yellow-700 dark:text-yellow-300">
            Your subscription expires in {subscriptionStatus.daysRemaining} days. 
            Please renew to continue enjoying our services.
          </p>
        </div>
        <Button size="sm" className="ml-4">
          <CreditCard className="h-4 w-4 mr-2" />
          Renew Now
        </Button>
      </AlertDescription>
    </Alert>
  );
}
