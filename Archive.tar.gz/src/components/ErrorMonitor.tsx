import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, X, RefreshCw } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';

/**
 * Error Monitor Component
 * 
 * Real-time system error monitoring and management
 * Shows system errors, allows admins to resolve them
 */
const ErrorMonitor: React.FC = () => {
  const { user, getSystemErrors, resolveSystemError, logSystemError } = useAuth();
  const [errors, setErrors] = useState<Array<{ id: string; type: string; message: string; timestamp: Date }>>([]);
  const [showResolved, setShowResolved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  /**
   * Load system errors
   */
  const loadErrors = () => {
    if (user?.isAdmin) {
      const systemErrors = getSystemErrors ? getSystemErrors() : [];
      setErrors(systemErrors);
    }
  };

  /**
   * Refresh errors periodically
   */
  useEffect(() => {
    loadErrors();
    const interval = setInterval(loadErrors, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, [user, showResolved]);

  /**
   * Handle error resolution
   */
  const handleResolveError = async (errorId: string) => {
    setIsLoading(true);
    try {
      const result = await resolveSystemError(errorId);
      if (result) {
        loadErrors(); // Refresh the list
      } else {
        console.error('Failed to resolve error');
      }
    } catch (error) {
      console.error('Error resolving system error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Test error logging (for development)
   */
  const handleTestError = async () => {
    if (logSystemError) {
      await logSystemError('database', 'Test error for monitoring system');
    }
    loadErrors();
  };

  if (!user?.isAdmin) {
    return null; // Only show to admins
  }

  const unresolvedErrors = errors.filter(error => !error.resolved);
  const resolvedErrors = errors.filter(error => error.resolved);

  return (
    <div className="space-y-4">
      {/* Error Summary */}
      {unresolvedErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {unresolvedErrors.length} unresolved system error{unresolvedErrors.length !== 1 ? 's' : ''} detected
          </AlertDescription>
        </Alert>
      )}

      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={loadErrors}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowResolved(!showResolved)}
          >
            {showResolved ? 'Hide Resolved' : 'Show Resolved'}
          </Button>
          {process.env.NODE_ENV === 'development' && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleTestError}
            >
              Test Error
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="destructive">
            {unresolvedErrors.length} Unresolved
          </Badge>
          <Badge variant="secondary">
            {resolvedErrors.length} Resolved
          </Badge>
        </div>
      </div>

      {/* Error List */}
      <div className="space-y-3">
        {errors.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-muted-foreground">
                <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-600" />
                <p>No system errors found</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          errors.map((error) => (
            <Card key={error.id} className={error.resolved ? 'opacity-60' : ''}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-sm font-medium">
                      {error.type.toUpperCase()} Error
                    </CardTitle>
                    <Badge variant={error.resolved ? 'secondary' : 'destructive'}>
                      {error.resolved ? 'Resolved' : 'Active'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    {!error.resolved && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleResolveError(error.id)}
                        disabled={isLoading}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Resolve
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">{error.message}</p>
                  
                  {error.details && (
                    <div className="text-xs text-muted-foreground bg-muted p-2 rounded">
                      <pre>{JSON.stringify(error.details, null, 2)}</pre>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>
                      Occurred: {new Date(error.timestamp).toLocaleString()}
                    </span>
                    {error.resolved && error.resolvedAt && (
                      <span>
                        Resolved: {new Date(error.resolvedAt).toLocaleString()} by {error.resolvedBy}
                      </span>
                    )}
                  </div>
                  
                  {error.userId && (
                    <div className="text-xs text-muted-foreground">
                      User ID: {error.userId}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default ErrorMonitor;
