import React from 'react';
import { useFacilities } from '@/hooks/useFacilities';

interface FacilityListProps {
  className?: string;
  showIcons?: boolean;
  showDescriptions?: boolean;
  category?: 'essential' | 'premium' | 'security' | 'convenience';
}

/**
 * FacilityList Component
 * 
 * Displays a list of active facilities with real-time updates
 */
const FacilityList: React.FC<FacilityListProps> = ({ 
  className = '', 
  showIcons = true, 
  showDescriptions = false,
  category 
}) => {
  const { activeFacilities, facilitiesByCategory } = useFacilities();
  
  const facilities = category ? facilitiesByCategory(category) : activeFacilities;
  const activeFacilitiesToShow = facilities.filter(f => f.isActive);

  if (activeFacilitiesToShow.length === 0) {
    return null;
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {activeFacilitiesToShow.map((facility) => (
        <div key={facility.id} className="flex items-center gap-2 text-sm">
          {showIcons && (
            <span className="text-lg flex-shrink-0">{facility.icon}</span>
          )}
          <div className="flex-1">
            <span className="font-medium">{facility.name}</span>
            {showDescriptions && (
              <span className="text-muted-foreground ml-2">- {facility.description}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default FacilityList;
