import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { useAuth } from '@/contexts/NewAuthContext';
import { cn } from '@/lib/utils';
import { PreviewModal } from '@/components/ui/preview-modal';
import { navigateToRegister } from '@/utils/navigation';
import { useState } from 'react';
import { Menu, X, ArrowLeft, User } from 'lucide-react';

/**
 * Header Component
 * 
 * Main navigation header for the Thika Mains Hostels application.
 * Features responsive design with mobile dropdown menu and enhanced button interactions.
 * 
 * Key Features:
 * - Responsive navigation with mobile hamburger menu
 * - Enhanced button states with hover, active, and scale effects
 * - Authentication-based conditional rendering
 * - Preview mode restrictions for non-authenticated users
 * - Smooth transitions and animations
 * - Accessible mobile menu with proper ARIA labels
 * 
 * Button States:
 * - Default: Standard appearance with muted colors
 * - Hover: Background color change, text color change, scale up (105%)
 * - Active: Scale down (95%) with enhanced background
 * - Current page: Highlighted with primary colors and scale
 * 
 * Mobile Menu:
 * - Three-line hamburger icon that transforms to X when open
 * - Dropdown menu with all navigation items and user actions
 * - Smooth slide-down animation
 * - Auto-close on navigation
 */
const Header = () => {
  // Router and authentication state
  const location = useLocation();
  const { user, isAuthenticated, isPreview, isImpersonating, exitImpersonation } = useAuth();
  
  // Modal and UI state management
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [previewAction, setPreviewAction] = useState({ title: '', message: '' });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  /**
   * Navigation items configuration
   * Dynamically includes booking options based on preview mode
   * Admin and soni-q can access all features
   */
  const navItems = [
    { href: '/home', label: 'Home' },
    { href: '/rooms', label: 'Rooms' },
        // All authenticated users can access booking (except preview users without full access)
        ...(isPreview && !user?.hasFullAccess ? [] : [
          { href: '/booking', label: 'Book Now' },
        ]),
  ];

  /**
   * Handle preview user actions that require full account
   * Shows modal with upgrade prompt
   * Admin and soni-q can bypass these restrictions
   * @param action - The action the user attempted to perform
   */
  const handlePreviewAction = (action: string) => {
    // Allow admin and soni-q to bypass preview restrictions
    if (user?.isAdmin || user?.isPermanent) {
      return; // No restrictions for admin or soni-q
    }
    
    setPreviewAction({
      title: 'Create Account Required',
      message: `To ${action}, you need to create a full account. Preview mode has limited access.`
    });
    setShowPreviewModal(true);
  };

  /**
   * Handle account creation redirect
   * Closes modal and navigates to registration page
   */
  const handleCreateAccount = () => {
    setShowPreviewModal(false);
    navigateToRegister();
  };

  /**
   * Toggle mobile menu visibility
   * Switches between hamburger and X icon
   */
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container flex h-14 sm:h-16 items-center justify-between px-2 sm:px-4">
        {/* Logo */}
        <Link to="/home" className="flex items-center space-x-1 sm:space-x-2">
          <div className="text-lg sm:text-xl lg:text-2xl font-bold bg-hero-gradient bg-clip-text text-transparent">
            <span className="hidden sm:inline">Thika Mains Hostels</span>
            <span className="sm:hidden">TMH</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-3 lg:space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                "text-sm font-medium transition-all duration-200 px-3 py-2 rounded-md",
                "hover:bg-primary/10 hover:text-primary hover:scale-105",
                "active:scale-95 active:bg-primary/20",
                location.pathname === item.href
                  ? "text-primary bg-primary/10 scale-105"
                  : "text-muted-foreground"
              )}
            >
              {item.label}
            </Link>
          ))}
          {isPreview && (
            <>
              <button
                onClick={() => handlePreviewAction('book a room')}
                className="text-sm font-medium transition-all duration-200 px-3 py-2 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
              >
                Book Now
              </button>
              <button
                onClick={() => handlePreviewAction('update booking')}
                className="text-sm font-medium transition-all duration-200 px-3 py-2 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
              >
                Update Booking
              </button>
            </>
          )}
        </div>

        {/* Desktop User Actions */}
        <div className="hidden md:flex items-center space-x-2 lg:space-x-4">
          <ThemeToggle />
          {isAuthenticated ? (
            <>
              <span className="text-sm text-muted-foreground hidden sm:block">
                Welcome, {user?.username}
                {isPreview && <span className="text-xs text-yellow-600 ml-1">(Preview)</span>}
                {isImpersonating && (
                  <span className="text-xs text-blue-600 ml-1">
                    (Admin impersonating {user?.username})
                  </span>
                )}
              </span>
              <Button asChild variant="outline" size="sm" className="transition-all duration-200 hover:bg-primary hover:text-primary-foreground hover:scale-105 active:scale-95">
                <Link to="/help">Help</Link>
              </Button>
              <Button asChild variant="outline" size="sm" className="transition-all duration-200 hover:bg-primary hover:text-primary-foreground hover:scale-105 active:scale-95">
                <Link to="/profile" className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                    {user?.profileImage ? (
                      <img
                        src={user.profileImage}
                        alt="Profile"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="h-3 w-3" />
                    )}
                  </div>
                  Profile
                </Link>
              </Button>
                  <Button asChild variant="outline" size="sm" className="transition-all duration-200 hover:bg-primary hover:text-primary-foreground hover:scale-105 active:scale-95">
                    <Link to="/settings">Settings</Link>
                  </Button>
                  {user?.isAdmin && !isImpersonating && (
                    <Button asChild variant="outline" size="sm" className="transition-all duration-200 hover:bg-primary hover:text-primary-foreground hover:scale-105 active:scale-95">
                      <Link to="/admin">Admin</Link>
                    </Button>
                  )}
                  {isImpersonating && (
                    <Button 
                      onClick={exitImpersonation}
                      variant="outline" 
                      size="sm" 
                      className="transition-all duration-200 hover:bg-blue-500 hover:text-white hover:scale-105 active:scale-95 border-blue-300 text-blue-700"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Exit Impersonation
                    </Button>
                  )}
            </>
          ) : (
            <>
              <Button asChild variant="outline" size="sm" className="transition-all duration-200 hover:bg-primary hover:text-primary-foreground hover:scale-105 active:scale-95">
                <Link to="/signin">Sign In</Link>
              </Button>
              <Button asChild variant="hero" size="sm" className="transition-all duration-200 hover:scale-105 active:scale-95">
                <Link to="/register">Sign Up</Link>
          </Button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center space-x-2">
          <ThemeToggle />
          <button
            onClick={toggleMobileMenu}
            className="p-2 rounded-md transition-all duration-200 hover:bg-primary/10 hover:scale-110 active:scale-95"
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6 text-foreground" />
            ) : (
              <Menu className="h-6 w-6 text-foreground" />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile Dropdown Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container py-4 space-y-4">
            {/* Navigation Items */}
            <div className="space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "block text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md",
                    "hover:bg-primary/10 hover:text-primary hover:scale-105",
                    "active:scale-95 active:bg-primary/20",
                    location.pathname === item.href
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground"
                  )}
                >
                  {item.label}
                </Link>
              ))}
              {isPreview && (
                <>
                  <button
                    onClick={() => {
                      handlePreviewAction('book a room');
                      setIsMobileMenuOpen(false);
                    }}
                    className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    Book Now
                  </button>
                  <button
                    onClick={() => {
                      handlePreviewAction('update booking');
                      setIsMobileMenuOpen(false);
                    }}
                    className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    Update Booking
                  </button>
                </>
              )}
            </div>

            {/* User Actions */}
            <div className="pt-4 border-t space-y-2">
              {isAuthenticated ? (
                <>
                  <div className="px-4 py-2 text-sm text-muted-foreground">
                    Welcome, {user?.username}
                    {isPreview && <span className="text-xs text-yellow-600 ml-1">(Preview)</span>}
                    {isImpersonating && (
                      <span className="text-xs text-blue-600 ml-1">
                        (Admin impersonating {user?.username})
                      </span>
                    )}
                  </div>
                  <Link
                    to="/help"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    Help
                  </Link>
                  <Link
                    to="/profile"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center gap-3 w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    <div className="w-5 h-5 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                      {user?.profileImage ? (
                        <img
                          src={user.profileImage}
                          alt="Profile"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="h-3 w-3" />
                      )}
                    </div>
                    Profile
                  </Link>
                      <Link
                        to="/settings"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                      >
                        Settings
                      </Link>
                      {user?.isAdmin && !isImpersonating && (
                        <Link
                          to="/admin"
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                        >
                          Admin
                        </Link>
                      )}
                      {isImpersonating && (
                        <button
                          onClick={() => {
                            exitImpersonation();
                            setIsMobileMenuOpen(false);
                          }}
                          className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-blue-100 hover:text-blue-700 hover:scale-105 active:scale-95 text-blue-600"
                        >
                          <ArrowLeft className="h-4 w-4 mr-2 inline" />
                          Exit Impersonation
                        </button>
                      )}
                </>
              ) : (
                <>
                  <Link
                    to="/signin"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    Sign In
                  </Link>
                  <Link
                    to="/register"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full text-left text-sm font-medium transition-all duration-200 px-4 py-3 rounded-md hover:bg-primary/10 hover:text-primary hover:scale-105 active:scale-95 text-muted-foreground"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      
      <PreviewModal
        isOpen={showPreviewModal}
        onClose={() => setShowPreviewModal(false)}
        onCreateAccount={handleCreateAccount}
        title={previewAction.title}
        message={previewAction.message}
      />
    </header>
  );
};

export default Header;