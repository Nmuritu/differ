import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Camera, Upload, User, CheckCircle, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { useToast } from '@/hooks/use-toast';

/**
 * Profile Photo Upload Component
 * 
 * Allows users to upload and update their profile photo
 * Handles file validation, compression, and persistent storage
 */
const ProfilePhotoUpload: React.FC = () => {
  const { user, updateProfilePhoto } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  /**
   * Handle file selection
   */
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file (JPG, PNG, GIF, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  /**
   * Handle photo upload
   */
  const handleUpload = async () => {
    if (!selectedFile || !user) return;

    setIsUploading(true);
    try {
      const result = await updateProfilePhoto(selectedFile);
      
      if (result) {
        toast({
          title: "Profile Photo Updated",
          description: "Your profile photo has been successfully updated.",
        });
        setSelectedFile(null);
        setPreviewUrl(null);
        // Reset file input
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } else {
        toast({
          title: "Upload Failed",
          description: "Failed to update profile photo",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast({
        title: "Upload Error",
        description: "An unexpected error occurred while uploading your photo",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  /**
   * Cancel upload
   */
  const handleCancel = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  /**
   * Trigger file input
   */
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  if (!user) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Profile Photo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Photo */}
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full overflow-hidden bg-muted flex items-center justify-center">
            {user.profileImage ? (
              <img
                src={user.profileImage}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            ) : (
              <User className="h-8 w-8 text-muted-foreground" />
            )}
          </div>
          <div>
            <p className="font-medium">Current Photo</p>
            <p className="text-sm text-muted-foreground">
              {user.profileImage ? 'Photo uploaded' : 'No photo uploaded'}
            </p>
          </div>
        </div>

        {/* Preview */}
        {previewUrl && (
          <div className="space-y-2">
            <p className="font-medium">Preview</p>
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-muted">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-medium">{selectedFile?.name}</p>
                <p className="text-xs text-muted-foreground">
                  {selectedFile && `${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* Upload Guidelines */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <ul className="text-sm space-y-1">
              <li>• Maximum file size: 5MB</li>
              <li>• Supported formats: JPG, PNG, GIF, WebP</li>
              <li>• Recommended size: 400x400 pixels or larger</li>
              <li>• Square images work best for profile photos</li>
            </ul>
          </AlertDescription>
        </Alert>

        {/* Action Buttons */}
        <div className="flex gap-2">
          {!selectedFile ? (
            <Button onClick={triggerFileInput} className="w-full">
              <Upload className="h-4 w-4 mr-2" />
              Choose Photo
            </Button>
          ) : (
            <>
              <Button
                onClick={handleUpload}
                disabled={isUploading}
                className="flex-1"
              >
                {isUploading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Uploading...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Upload Photo
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={isUploading}
              >
                Cancel
              </Button>
            </>
          )}
        </div>

        {/* Storage Info */}
        <div className="text-xs text-muted-foreground bg-muted p-3 rounded">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle className="h-3 w-3 text-green-600" />
            <span className="font-medium">Persistent Storage</span>
          </div>
          <p>
            Your profile photo is securely stored in the database and will persist across 
            sessions. It will only be removed when you delete your account or checkout.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfilePhotoUpload;
