import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, CheckCircle, XCircle, QrCode, Copy, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { useToast } from '@/hooks/use-toast';

/**
 * Two-Factor Authentication Component
 * 
 * Handles 2FA setup, enabling, disabling, and verification
 * Provides QR code generation and backup codes management
 */
const TwoFactorAuth: React.FC = () => {
  const { user, enable2FA, disable2FA } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [backupCodes, setBackupCodes] = useState<string[]>([]);

  /**
   * Enable 2FA for the current user
   */
  const handleEnable2FA = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const result = await enable2FA();
      
      if (result.success && result.secret && result.qrCode) {
        setSecret(result.secret);
        setQrCode(result.qrCode);
        toast({
          title: "2FA Setup Started",
          description: "Please scan the QR code with your authenticator app and enter the verification code.",
        });
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to enable 2FA",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error enabling 2FA:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred while enabling 2FA",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Disable 2FA for the current user
   */
  const handleDisable2FA = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const result = await disable2FA();
      
      if (result.success) {
        setSecret(null);
        setQrCode(null);
        setBackupCodes([]);
        toast({
          title: "2FA Disabled",
          description: "Two-factor authentication has been successfully disabled.",
        });
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to disable 2FA",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error disabling 2FA:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred while disabling 2FA",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Verify 2FA setup with a code from authenticator app
   */
  const handleVerify2FA = async () => {
    if (!verificationCode.trim()) {
      toast({
        title: "Verification Required",
        description: "Please enter the verification code from your authenticator app.",
        variant: "destructive",
      });
      return;
    }

    setIsVerifying(true);
    try {
      // In a real implementation, you would verify the TOTP code here
      // For now, we'll simulate verification
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate successful verification
      setBackupCodes([
        'A1B2C3D4', 'E5F6G7H8', 'I9J0K1L2', 'M3N4O5P6',
        'Q7R8S9T0', 'U1V2W3X4', 'Y5Z6A7B8', 'C9D0E1F2',
        'G3H4I5J6', 'K7L8M9N0'
      ]);
      
      toast({
        title: "2FA Enabled Successfully",
        description: "Two-factor authentication is now active. Please save your backup codes.",
      });
    } catch (error) {
      console.error('Error verifying 2FA:', error);
      toast({
        title: "Verification Failed",
        description: "The verification code is invalid. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsVerifying(false);
    }
  };

  /**
   * Copy secret to clipboard
   */
  const copySecret = async () => {
    if (secret) {
      try {
        await navigator.clipboard.writeText(secret);
        toast({
          title: "Secret Copied",
          description: "The secret key has been copied to your clipboard.",
        });
      } catch (error) {
        console.error('Error copying secret:', error);
      }
    }
  };

  /**
   * Copy backup codes to clipboard
   */
  const copyBackupCodes = async () => {
    if (backupCodes.length > 0) {
      try {
        await navigator.clipboard.writeText(backupCodes.join('\n'));
        toast({
          title: "Backup Codes Copied",
          description: "The backup codes have been copied to your clipboard.",
        });
      } catch (error) {
        console.error('Error copying backup codes:', error);
      }
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Two-Factor Authentication
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Status */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-3">
            {user?.twoFactorEnabled ? (
              <>
                <CheckCircle className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-800 dark:text-green-200">
                    2FA Enabled
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Your account is protected with two-factor authentication
                  </p>
                </div>
              </>
            ) : (
              <>
                <XCircle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="font-medium text-red-800 dark:text-red-200">
                    2FA Disabled
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Your account is not protected with two-factor authentication
                  </p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* 2FA Setup */}
        {!user?.twoFactorEnabled && !secret && (
          <div className="space-y-4">
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                Two-factor authentication adds an extra layer of security to your account. 
                You'll need an authenticator app like Google Authenticator or Authy.
              </AlertDescription>
            </Alert>
            
            <Button 
              onClick={handleEnable2FA} 
              disabled={isLoading}
              className="w-full"
            >
              {isLoading ? 'Setting up...' : 'Enable 2FA'}
            </Button>
          </div>
        )}

        {/* QR Code and Secret */}
        {secret && !user?.twoFactorEnabled && (
          <div className="space-y-4">
            <Alert>
              <QrCode className="h-4 w-4" />
              <AlertDescription>
                Scan this QR code with your authenticator app, then enter the verification code below.
              </AlertDescription>
            </Alert>

            {/* QR Code Placeholder */}
            <div className="flex justify-center p-4 bg-muted rounded-lg">
              <div className="w-48 h-48 bg-white rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                <div className="text-center">
                  <QrCode className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-500">QR Code</p>
                  <p className="text-xs text-gray-400">Scan with authenticator app</p>
                </div>
              </div>
            </div>

            {/* Secret Key */}
            <div className="space-y-2">
              <Label>Secret Key</Label>
              <div className="flex gap-2">
                <Input
                  type={showSecret ? 'text' : 'password'}
                  value={secret}
                  readOnly
                  className="font-mono"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowSecret(!showSecret)}
                >
                  {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copySecret}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Verification Code */}
            <div className="space-y-2">
              <Label>Verification Code</Label>
              <div className="flex gap-2">
                <Input
                  type="text"
                  placeholder="Enter 6-digit code from your app"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  maxLength={6}
                />
                <Button
                  onClick={handleVerify2FA}
                  disabled={isVerifying || verificationCode.length !== 6}
                >
                  {isVerifying ? 'Verifying...' : 'Verify'}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Backup Codes */}
        {backupCodes.length > 0 && (
          <div className="space-y-4">
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                Save these backup codes in a safe place. You can use them to access your account if you lose your authenticator device.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-2 gap-2 p-4 bg-muted rounded-lg">
              {backupCodes.map((code, index) => (
                <div key={index} className="font-mono text-sm text-center p-2 bg-white rounded border">
                  {code}
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              onClick={copyBackupCodes}
              className="w-full"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy Backup Codes
            </Button>
          </div>
        )}

        {/* Disable 2FA */}
        {user?.twoFactorEnabled && (
          <div className="space-y-4">
            <Alert>
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                Disabling 2FA will make your account less secure. Only do this if you're sure.
              </AlertDescription>
            </Alert>

            <Button
              variant="destructive"
              onClick={handleDisable2FA}
              disabled={isLoading}
              className="w-full"
            >
              {isLoading ? 'Disabling...' : 'Disable 2FA'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TwoFactorAuth;
