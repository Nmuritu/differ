import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/contexts/NewAuthContext";
import { RoomProvider } from "@/contexts/RoomContext";
import Header from "@/components/layout/Header";
import ErrorBoundary from "@/components/ErrorBoundary";
import RouteGuard from "@/components/RouteGuard";
import { lazy, Suspense } from "react";

// Lazy load pages for better code splitting
const HomePage = lazy(() => import("@/pages/HomePage"));
const RoomsPage = lazy(() => import("@/pages/RoomsPage"));
const BookingPage = lazy(() => import("@/pages/BookingPage"));
const PaymentPage = lazy(() => import("@/pages/PaymentPage"));
const SettingsPage = lazy(() => import("@/pages/SettingsPage"));
const RegistrationPage = lazy(() => import("@/pages/RegistrationPage"));
const SignInPage = lazy(() => import("@/pages/SignInPage"));
const EnhancedChangePasswordPage = lazy(() => import("@/pages/EnhancedChangePasswordPage"));
const ForgotPasswordPage = lazy(() => import("@/pages/ForgotPasswordPage"));
const UserProfilePage = lazy(() => import("@/pages/UserProfilePage"));
const UserManualPage = lazy(() => import("@/pages/UserManualPage"));
const AIAssistantPage = lazy(() => import("@/pages/AIAssistantPage"));
const AskAdminPage = lazy(() => import("@/pages/AskAdminPage"));
const QAForumPage = lazy(() => import("@/pages/QAForumPage"));
const HelpPage = lazy(() => import("@/pages/HelpPage"));
const AdminPage = lazy(() => import("@/pages/AdminPage"));
const AdminForumPage = lazy(() => import("@/pages/AdminForumPage"));
const AdminPromotionPage = lazy(() => import("@/pages/AdminPromotionPage"));
const ChatForumPage = lazy(() => import("@/pages/ChatForumPage"));
const AdminChatForum = lazy(() => import("@/pages/AdminChatForum"));
const ClientChatForum = lazy(() => import("@/pages/ClientChatForum"));
const EditProfilePage = lazy(() => import("@/pages/EditProfilePage"));
const NotFound = lazy(() => import("./pages/NotFound"));

// Loading component for Suspense fallback
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
      <p className="text-muted-foreground">Loading page...</p>
    </div>
  </div>
);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Reduce bundle size by disabling some features in production
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (was cacheTime)
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => (
  <ErrorBoundary>
  <QueryClientProvider client={queryClient}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <AuthProvider>
              <RoomProvider>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <div className="min-h-screen bg-background">
          <Header />
          <main>
                <Suspense fallback={<PageLoader />}>
            <Routes>
                    <Route path="/" element={<SignInPage />} />
                    <Route path="/signin" element={<SignInPage />} />
                    <Route path="/register" element={<RegistrationPage />} />
                    <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                    
                    {/* Protected Routes - Preview users allowed */}
                    <Route path="/home" element={
                      <RouteGuard requireAuth allowPreview>
                        <HomePage />
                      </RouteGuard>
                    } />
                    <Route path="/rooms" element={
                      <RouteGuard requireAuth allowPreview>
                        <RoomsPage />
                      </RouteGuard>
                    } />
                    <Route path="/profile" element={
                      <RouteGuard requireAuth allowPreview>
                        <UserProfilePage />
                      </RouteGuard>
                    } />
                    <Route path="/help" element={
                      <RouteGuard requireAuth allowPreview>
                        <HelpPage />
                      </RouteGuard>
                    } />
                    <Route path="/user-manual" element={
                      <RouteGuard requireAuth allowPreview>
                        <UserManualPage />
                      </RouteGuard>
                    } />
                    
                    {/* Protected Routes - Full authentication required */}
                    <Route path="/booking" element={
                      <RouteGuard requireAuth>
                        <BookingPage />
                      </RouteGuard>
                    } />
                    <Route path="/payment" element={
                      <RouteGuard requireAuth>
                        <PaymentPage />
                      </RouteGuard>
                    } />
                    <Route path="/settings" element={
                      <RouteGuard requireAuth>
                        <SettingsPage />
                      </RouteGuard>
                    } />
                    <Route path="/change-password" element={
                      <RouteGuard requireAuth>
                        <EnhancedChangePasswordPage />
                      </RouteGuard>
                    } />
                    <Route path="/ask-ai" element={
                      <RouteGuard requireAuth allowPreview>
                        <AIAssistantPage />
                      </RouteGuard>
                    } />
                    <Route path="/ask-admin" element={
                      <RouteGuard requireAuth>
                        <AskAdminPage />
                      </RouteGuard>
                    } />
                    <Route path="/qa-forum" element={
                      <RouteGuard requireAuth>
                        <QAForumPage />
                      </RouteGuard>
                    } />
                    <Route path="/chat-forum" element={
                      <RouteGuard requireAuth>
                        <ChatForumPage />
                      </RouteGuard>
                    } />
                    <Route path="/client-chat" element={
                      <RouteGuard requireAuth>
                        <ClientChatForum />
                      </RouteGuard>
                    } />
                    <Route path="/edit-profile" element={
                      <RouteGuard requireAuth>
                        <EditProfilePage />
                      </RouteGuard>
                    } />
                    
                    {/* Admin Only Routes */}
                    <Route path="/admin" element={
                      <RouteGuard requireAuth requireAdmin>
                        <AdminPage />
                      </RouteGuard>
                    } />
                    <Route path="/admin-forum" element={
                      <RouteGuard requireAuth requireAdmin>
                        <AdminForumPage />
                      </RouteGuard>
                    } />
                    <Route path="/admin-chat" element={
                      <RouteGuard requireAuth requireAdmin>
                        <AdminChatForum />
                      </RouteGuard>
                    } />
                    <Route path="/admin-promotion" element={
                      <RouteGuard requireAuth requireAdmin>
                        <AdminPromotionPage />
                      </RouteGuard>
                    } />
                    
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
                </Suspense>
          </main>
        </div>
      </BrowserRouter>
    </TooltipProvider>
              </RoomProvider>
            </AuthProvider>
          </ThemeProvider>
  </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
