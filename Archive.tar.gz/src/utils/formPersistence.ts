/**
 * Form Persistence Utilities
 * 
 * Utilities for saving and restoring form data across page refreshes
 */

export const FORM_STORAGE_KEYS = {
  REGISTRATION: 'registrationFormData',
  SIGNIN: 'signinFormData',
  FORGOT_PASSWORD: 'forgotPasswordIdentifier',
  CHANGE_PASSWORD: 'changePasswordFormData'
} as const;

/**
 * Save form data to localStorage
 */
export const saveFormData = (key: string, data: Record<string, unknown>): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving form data:', error);
  }
};

/**
 * Load form data from localStorage
 */
export const loadFormData = <T>(key: string, defaultValue: T): T => {
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (error) {
    console.error('Error loading form data:', error);
  }
  return defaultValue;
};

/**
 * Clear specific form data
 */
export const clearFormData = (key: string): void => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error('Error clearing form data:', error);
  }
};

/**
 * Clear all form data
 */
export const clearAllFormData = (): void => {
  Object.values(FORM_STORAGE_KEYS).forEach(key => {
    clearFormData(key);
  });
};

/**
 * Check if form has any saved data
 */
export const hasFormData = (key: string): boolean => {
  try {
    const saved = localStorage.getItem(key);
    return saved !== null && saved.trim() !== '';
  } catch (error) {
    return false;
  }
};
