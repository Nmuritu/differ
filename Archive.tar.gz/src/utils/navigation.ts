/**
 * Navigation Utility
 * 
 * Provides safe navigation methods that work with React Router
 * and avoid 404 errors in SPA applications.
 */

/**
 * Navigate to a route using React Router history API
 * This avoids hard redirects that can cause 404 errors
 */
export const navigateTo = (path: string, replace: boolean = true): void => {
  if (typeof window === 'undefined') return;
  
  try {
    if (replace) {
      window.history.replaceState(null, '', path);
    } else {
      window.history.pushState(null, '', path);
    }
    
    // Trigger a popstate event to notify React Router
    window.dispatchEvent(new PopStateEvent('popstate'));
  } catch (error) {
    console.error('Navigation error:', error);
    // Fallback to hard redirect if history API fails
    window.location.href = path;
  }
};

/**
 * Navigate to signin page
 */
export const navigateToSignin = (): void => {
  navigateTo('/signin');
};

/**
 * Navigate to register page
 */
export const navigateToRegister = (): void => {
  navigateTo('/register');
};

/**
 * Navigate to home page
 */
export const navigateToHome = (): void => {
  navigateTo('/home');
};

/**
 * Navigate to admin forum
 */
export const navigateToAdminForum = (): void => {
  navigateTo('/admin-forum');
};

/**
 * Reload the page (use sparingly)
 */
export const reloadPage = (): void => {
  if (typeof window !== 'undefined') {
    window.location.reload();
  }
};
