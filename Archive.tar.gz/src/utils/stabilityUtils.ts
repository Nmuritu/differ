/**
 * Stability Utilities
 * 
 * Collection of utility functions to help stabilize the application
 * and handle common error scenarios gracefully.
 */

/**
 * Safe JSON parse with fallback
 * Prevents crashes from corrupted localStorage data
 */
export const safeJsonParse = <T>(jsonString: string | null, fallback: T): T => {
  if (!jsonString) return fallback;
  
  try {
    return JSON.parse(jsonString) as T;
  } catch (error) {
    console.warn('Failed to parse JSON, using fallback:', error);
    return fallback;
  }
};

/**
 * Safe localStorage operations
 * Handles cases where localStorage might be unavailable or full
 */
export const safeLocalStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      console.warn(`Failed to get localStorage item "${key}":`, error);
      return null;
    }
  },

  setItem: (key: string, value: string): boolean => {
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (error) {
      console.warn(`Failed to set localStorage item "${key}":`, error);
      return false;
    }
  },

  removeItem: (key: string): boolean => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.warn(`Failed to remove localStorage item "${key}":`, error);
      return false;
    }
  },

  clear: (): boolean => {
    try {
      localStorage.clear();
      return true;
    } catch (error) {
      console.warn('Failed to clear localStorage:', error);
      return false;
    }
  }
};

/**
 * Database connection health check
 * Verifies that IndexedDB is working properly
 */
export const checkDatabaseHealth = async (): Promise<boolean> => {
  try {
    // Check if IndexedDB is available
    if (!('indexedDB' in window)) {
      console.error('IndexedDB is not available');
      return false;
    }

    // Try to open the database
    return new Promise<boolean>((resolve) => {
      const request = indexedDB.open('ThikaMainsHostelsDB', 1);
      
      request.onsuccess = () => {
        request.result.close();
        resolve(true);
      };
      
      request.onerror = () => {
        console.error('Database health check failed:', request.error);
        resolve(false);
      };
      
      // Timeout after 5 seconds
      setTimeout(() => {
        console.warn('Database health check timed out');
        resolve(false);
      }, 5000);
    });
  } catch (error) {
    console.error('Database health check error:', error);
    return false;
  }
};

/**
 * Clean up corrupted session data
 * Removes potentially corrupted data from localStorage
 */
export const cleanupCorruptedData = (): void => {
  try {
    
    const keysToCheck = [
      'currentUser',
      'signinFormData',
      'registrationFormData',
      'previewUser'
    ];
    
    keysToCheck.forEach(key => {
      const data = safeLocalStorage.getItem(key);
      if (data) {
        // Try to parse the data
        const parsed = safeJsonParse(data, null);
        if (parsed === null) {
          // Data is corrupted, remove it
          safeLocalStorage.removeItem(key);
        }
      }
    });
    
  } catch (error) {
    console.error('Error during data cleanup:', error);
  }
};

/**
 * System stability check
 * Performs comprehensive checks to ensure the app is stable
 */
export const performStabilityCheck = async (): Promise<{
  isStable: boolean;
  issues: string[];
  recommendations: string[];
}> => {
  const issues: string[] = [];
  const recommendations: string[] = [];
  
  try {
    
    // Check 1: IndexedDB availability
    if (!('indexedDB' in window)) {
      issues.push('IndexedDB is not available');
      recommendations.push('Use a modern browser that supports IndexedDB');
    }
    
    // Check 2: LocalStorage availability
    try {
      localStorage.setItem('stability-test', 'test');
      localStorage.removeItem('stability-test');
    } catch (error) {
      issues.push('LocalStorage is not available or full');
      recommendations.push('Clear browser storage or enable localStorage');
    }
    
    // Check 3: Database health
    const dbHealthy = await checkDatabaseHealth();
    if (!dbHealthy) {
      issues.push('Database connection is unhealthy');
      recommendations.push('Clear browser data and refresh the page');
    }
    
    // Check 4: Session data integrity
    const currentUserData = safeLocalStorage.getItem('currentUser');
    if (currentUserData) {
      const userData = safeJsonParse(currentUserData, {} as Record<string, unknown>);
      if (!userData || !userData.id || !userData.username) {
        issues.push('Session data is corrupted');
        recommendations.push('Clear session data and sign in again');
      }
    }
    
    // Check 5: Required browser features
    const requiredFeatures = [
      'Promise',
      'fetch',
      'JSON',
      'localStorage',
      'indexedDB'
    ];
    
    requiredFeatures.forEach(feature => {
      if (!(feature in window)) {
        issues.push(`Required feature "${feature}" is not available`);
        recommendations.push('Update to a modern browser');
      }
    });
    
    const isStable = issues.length === 0;
    
    if (issues.length > 0) {
      console.warn('Issues found:', issues);
      console.info('Recommendations:', recommendations);
    }
    
    return { isStable, issues, recommendations };
    
  } catch (error) {
    console.error('Error during stability check:', error);
    return {
      isStable: false,
      issues: ['Stability check failed to complete'],
      recommendations: ['Refresh the page and try again']
    };
  }
};

/**
 * Emergency recovery function
 * Attempts to recover from critical errors
 */
export const emergencyRecovery = async (): Promise<boolean> => {
  try {
    
    // Step 1: Clean up corrupted data
    cleanupCorruptedData();
    
    // Step 2: Clear all session data
    safeLocalStorage.clear();
    
    // Step 3: Force reload the page
    setTimeout(() => {
      window.location.reload();
    }, 1000);
    
    return true;
    
  } catch (error) {
    console.error('Emergency recovery failed:', error);
    return false;
  }
};

/**
 * Auto-recovery on page load
 * Automatically checks and fixes common issues when the app loads
 */
export const autoRecovery = async (): Promise<void> => {
  try {
    
    // Clean up any corrupted data
    cleanupCorruptedData();
    
    // Check database health
    const dbHealthy = await checkDatabaseHealth();
    if (!dbHealthy) {
      console.warn('Database health check failed, but continuing...');
    }
    
    
  } catch (error) {
    console.error('Auto-recovery failed:', error);
  }
};

export default {
  safeJsonParse,
  safeLocalStorage,
  checkDatabaseHealth,
  cleanupCorruptedData,
  performStabilityCheck,
  emergencyRecovery,
  autoRecovery
};
