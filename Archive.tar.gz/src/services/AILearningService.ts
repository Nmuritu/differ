/**
 * AI Learning Service
 * 
 * Provides intelligent AI responses that learn from user interactions
 * and chat forum conversations to provide more human-like assistance.
 */

export interface LearningData {
  id: string;
  question: string;
  answer: string;
  context: string;
  userType: 'client' | 'admin' | 'preview';
  timestamp: Date;
  category: string;
  keywords: string[];
  effectiveness: number; // 0-1 score based on user feedback
}

export interface ChatContext {
  threadId: string;
  messages: Array<{
    sender: string;
    message: string;
    timestamp: Date;
  }>;
  participants: string[];
  subject: string;
}

class AILearningService {
  private static instance: AILearningService;
  private learningData: LearningData[] = [];
  private chatContexts: Map<string, ChatContext> = new Map();
  private responsePatterns: Map<string, string[]> = new Map();

  private constructor() {
    this.loadLearningData();
  }

  public static getInstance(): AILearningService {
    if (!AILearningService.instance) {
      AILearningService.instance = new AILearningService();
    }
    return AILearningService.instance;
  }

  /**
   * Load learning data from localStorage
   */
  private loadLearningData() {
    try {
      const data = localStorage.getItem('ai_learning_data');
      if (data) {
        this.learningData = JSON.parse(data).map((item: Record<string, unknown>) => ({
          ...item,
          timestamp: new Date(item.timestamp as string)
        }));
      }
    } catch (error) {
      console.error('Error loading AI learning data:', error);
    }
  }

  /**
   * Save learning data to localStorage
   */
  private saveLearningData() {
    try {
      localStorage.setItem('ai_learning_data', JSON.stringify(this.learningData));
    } catch (error) {
      console.error('Error saving AI learning data:', error);
    }
  }

  /**
   * Learn from a user interaction
   */
  public learnFromInteraction(
    question: string,
    answer: string,
    context: string,
    userType: 'client' | 'admin' | 'preview',
    category: string = 'general'
  ) {
    const learningItem: LearningData = {
      id: this.generateId(),
      question: question.toLowerCase().trim(),
      answer,
      context,
      userType,
      timestamp: new Date(),
      category,
      keywords: this.extractKeywords(question),
      effectiveness: 0.5 // Default effectiveness
    };

    this.learningData.push(learningItem);
    this.saveLearningData();
    this.updateResponsePatterns();
  }

  /**
   * Learn from chat forum conversations
   */
  public learnFromChatForum(threadId: string, messages: Array<{ senderName: string; message: string; timestamp: string; subject?: string }>) {
    const context: ChatContext = {
      threadId,
      messages: messages.map(msg => ({
        sender: msg.senderName,
        message: msg.message,
        timestamp: new Date(msg.timestamp)
      })),
      participants: [...new Set(messages.map(msg => msg.senderName))],
      subject: messages[0]?.subject || 'General Discussion'
    };

    this.chatContexts.set(threadId, context);
    this.extractLearningFromChat(context);
  }

  /**
   * Generate intelligent response based on learning
   */
  public generateIntelligentResponse(
    userQuery: string,
    userType: 'client' | 'admin' | 'preview',
    context?: string
  ): { content: string; suggestions: string[]; confidence: number } {
    const query = userQuery.toLowerCase().trim();
    const keywords = this.extractKeywords(query);
    
    // Find similar questions from learning data
    const similarQuestions = this.findSimilarQuestions(query, keywords, userType);
    
    if (similarQuestions.length > 0) {
      const bestMatch = similarQuestions[0];
      const confidence = this.calculateConfidence(query, bestMatch.question);
      
      if (confidence > 0.7) {
        return {
          content: this.enhanceResponse(bestMatch.answer, context),
          suggestions: this.generateSuggestions(bestMatch.category, userType),
          confidence
        };
      }
    }

    // Generate contextual response based on patterns
    const contextualResponse = this.generateContextualResponse(query, userType, context);
    return contextualResponse;
  }

  /**
   * Extract keywords from text
   */
  private extractKeywords(text: string): string[] {
    const stopWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them']);
    
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(word => word.length > 2 && !stopWords.has(word))
      .slice(0, 10); // Limit to 10 keywords
  }

  /**
   * Find similar questions from learning data
   */
  private findSimilarQuestions(
    query: string,
    keywords: string[],
    userType: 'client' | 'admin' | 'preview'
  ): LearningData[] {
    return this.learningData
      .filter(item => item.userType === userType || userType === 'preview')
      .map(item => ({
        ...item,
        similarity: this.calculateSimilarity(query, item.question, keywords, item.keywords)
      }))
      .filter(item => item.similarity > 0.3)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, 5);
  }

  /**
   * Calculate similarity between two texts
   */
  private calculateSimilarity(
    query: string,
    question: string,
    queryKeywords: string[],
    questionKeywords: string[]
  ): number {
    // Keyword overlap
    const keywordOverlap = queryKeywords.filter(kw => 
      questionKeywords.some(qkw => qkw.includes(kw) || kw.includes(qkw))
    ).length;
    
    const keywordScore = keywordOverlap / Math.max(queryKeywords.length, questionKeywords.length);
    
    // Text similarity (simple Levenshtein distance)
    const textSimilarity = this.levenshteinSimilarity(query, question);
    
    // Combined score
    return (keywordScore * 0.6) + (textSimilarity * 0.4);
  }

  /**
   * Calculate Levenshtein similarity
   */
  private levenshteinSimilarity(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
    
    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;
    
    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + indicator
        );
      }
    }
    
    const distance = matrix[str2.length][str1.length];
    const maxLength = Math.max(str1.length, str2.length);
    return maxLength === 0 ? 1 : (maxLength - distance) / maxLength;
  }

  /**
   * Calculate confidence score
   */
  private calculateConfidence(query: string, question: string): number {
    const similarity = this.levenshteinSimilarity(query, question);
    return Math.min(similarity * 1.2, 1); // Boost confidence slightly
  }

  /**
   * Enhance response with context
   */
  private enhanceResponse(answer: string, context?: string): string {
    if (!context) return answer;
    
    // Add contextual information
    const contextualAdditions = [
      `Based on similar situations I've encountered, ${answer.toLowerCase()}`,
      `In your specific case, ${answer.toLowerCase()}`,
      `Given the context, ${answer.toLowerCase()}`
    ];
    
    return contextualAdditions[Math.floor(Math.random() * contextualAdditions.length)];
  }

  /**
   * Generate contextual response
   */
  private generateContextualResponse(
    query: string,
    userType: 'client' | 'admin' | 'preview',
    context?: string
  ): { content: string; suggestions: string[]; confidence: number } {
    // Analyze query intent
    const intent = this.analyzeIntent(query);
    
    // Generate response based on intent and user type
    let response = this.generateResponseByIntent(intent, userType, context);
    
    // Add human-like elements
    response = this.addHumanElements(response, userType);
    
    return {
      content: response,
      suggestions: this.generateSuggestions(intent.category, userType),
      confidence: 0.6 // Medium confidence for generated responses
    };
  }

  /**
   * Analyze user intent
   */
  private analyzeIntent(query: string): { category: string; urgency: 'low' | 'medium' | 'high'; emotion: string } {
    const urgentKeywords = ['urgent', 'emergency', 'immediately', 'asap', 'critical', 'broken', 'not working', 'error', 'failed'];
    const emotionalKeywords = ['frustrated', 'angry', 'upset', 'confused', 'worried', 'stressed', 'happy', 'excited', 'grateful'];
    
    const urgency = urgentKeywords.some(keyword => query.includes(keyword)) ? 'high' : 'medium';
    const emotion = emotionalKeywords.find(keyword => query.includes(keyword)) || 'neutral';
    
    // Categorize based on keywords
    let category = 'general';
    if (query.includes('book') || query.includes('reservation')) category = 'booking';
    else if (query.includes('payment') || query.includes('billing')) category = 'payment';
    else if (query.includes('room') || query.includes('accommodation')) category = 'accommodation';
    else if (query.includes('admin') || query.includes('support')) category = 'support';
    else if (query.includes('account') || query.includes('profile')) category = 'account';
    
    return { category, urgency, emotion };
  }

  /**
   * Generate response by intent
   */
  private generateResponseByIntent(
    intent: { category: string; urgency: 'low' | 'medium' | 'high'; emotion: string },
    userType: 'client' | 'admin' | 'preview',
    context?: string
  ): string {
    const { category, urgency, emotion } = intent;
    
    // Base responses by category
    const categoryResponses = {
      booking: [
        "I'd be happy to help you with your booking! Let me guide you through the process.",
        "I can assist you with making a reservation. What type of room are you looking for?",
        "I'll help you with the booking process. Do you have any specific requirements?"
      ],
      payment: [
        "I can help you with payment-related questions. What specific issue are you experiencing?",
        "Let me assist you with your payment concerns. What payment method are you using?",
        "I'll help resolve your payment issue. Can you provide more details?"
      ],
      accommodation: [
        "I can provide information about our accommodations. What would you like to know?",
        "Let me help you with room-related questions. What specific information do you need?",
        "I'll assist you with accommodation details. What are you looking for?"
      ],
      support: [
        "I'm here to help with any support issues. What problem are you experiencing?",
        "Let me assist you with your support request. Can you describe the issue?",
        "I'll help resolve your concern. What specific help do you need?"
      ],
      account: [
        "I can help you with account-related questions. What do you need assistance with?",
        "Let me assist you with your account. What specific issue are you facing?",
        "I'll help you manage your account. What would you like to do?"
      ],
      general: [
        "I'm here to help! What can I assist you with today?",
        "I'd be happy to help you. What questions do you have?",
        "How can I make your experience better today?"
      ]
    };

    // Select appropriate response
    const responses = categoryResponses[category as keyof typeof categoryResponses] || categoryResponses.general;
    let response = responses[Math.floor(Math.random() * responses.length)];

    // Add urgency handling
    if (urgency === 'high') {
      response = `I understand this is urgent! ${response} Let me prioritize this for you.`;
    }

    // Add emotional support
    if (emotion !== 'neutral') {
      const emotionalSupport = {
        frustrated: "I understand your frustration, and I'm here to help resolve this quickly.",
        angry: "I can see you're upset, and I want to help make this right for you.",
        confused: "I understand this can be confusing. Let me break this down clearly for you.",
        worried: "I can sense your concern, and I want to help put your mind at ease.",
        stressed: "I understand you're feeling stressed. Let me help you resolve this step by step.",
        happy: "I'm glad you're happy! I'd love to help you with whatever you need.",
        excited: "I can feel your excitement! Let me help you with this.",
        grateful: "Thank you for your kind words! I'm here to continue helping you."
      };
      
      if (emotionalSupport[emotion as keyof typeof emotionalSupport]) {
        response = `${emotionalSupport[emotion as keyof typeof emotionalSupport]} ${response}`;
      }
    }

    return response;
  }

  /**
   * Add human-like elements to responses
   */
  private addHumanElements(response: string, userType: 'client' | 'admin' | 'preview'): string {
    // Add personalization
    const personalizations = [
      "I understand your situation,",
      "Based on what you've told me,",
      "I can see that",
      "From my experience,",
      "I want to make sure"
    ];
    
    // Add conversational elements
    const conversationalElements = [
      "Let me help you with that.",
      "I'm here to assist you.",
      "That's a great question!",
      "I completely understand.",
      "That makes perfect sense."
    ];
    
    // Randomly add human elements (30% chance)
    if (Math.random() < 0.3) {
      const personalization = personalizations[Math.floor(Math.random() * personalizations.length)];
      response = `${personalization} ${response.toLowerCase()}`;
    }
    
    if (Math.random() < 0.2) {
      const element = conversationalElements[Math.floor(Math.random() * conversationalElements.length)];
      response = `${response} ${element}`;
    }
    
    return response;
  }

  /**
   * Generate suggestions based on category and user type
   */
  private generateSuggestions(category: string, userType: 'client' | 'admin' | 'preview'): string[] {
    const suggestionsByCategory = {
      booking: [
        "How do I book a room?",
        "What room types are available?",
        "How do I modify my booking?",
        "What are the booking policies?"
      ],
      payment: [
        "What payment methods do you accept?",
        "How do I pay for my booking?",
        "I have a payment issue",
        "How do I get a receipt?"
      ],
      accommodation: [
        "What amenities are included?",
        "What are the room features?",
        "How do I request room changes?",
        "What are the house rules?"
      ],
      support: [
        "I need technical help",
        "How do I contact admin?",
        "I have a complaint",
        "How do I report an issue?"
      ],
      account: [
        "How do I update my profile?",
        "How do I change my password?",
        "How do I delete my account?",
        "How do I update my settings?"
      ],
      general: [
        "What services do you offer?",
        "How do I get help?",
        "What are your policies?",
        "How do I contact support?"
      ]
    };

    return suggestionsByCategory[category as keyof typeof suggestionsByCategory] || suggestionsByCategory.general;
  }

  /**
   * Extract learning from chat conversations
   */
  private extractLearningFromChat(context: ChatContext) {
    // Analyze conversation patterns
    const questions = context.messages
      .filter(msg => msg.message.includes('?') || msg.message.toLowerCase().includes('how') || msg.message.toLowerCase().includes('what'))
      .map(msg => msg.message);
    
    const answers = context.messages
      .filter(msg => !msg.message.includes('?') && msg.message.length > 20)
      .map(msg => msg.message);

    // Create learning pairs
    for (let i = 0; i < Math.min(questions.length, answers.length); i++) {
      this.learnFromInteraction(
        questions[i],
        answers[i],
        `Chat Forum: ${context.subject}`,
        'client',
        'forum'
      );
    }
  }

  /**
   * Update response patterns based on learning
   */
  private updateResponsePatterns() {
    // Group by category and extract common patterns
    const categoryGroups = this.learningData.reduce((groups, item) => {
      if (!groups[item.category]) groups[item.category] = [];
      groups[item.category].push(item);
      return groups;
    }, {} as Record<string, LearningData[]>);

    // Update patterns for each category
    Object.entries(categoryGroups).forEach(([category, items]) => {
      const commonKeywords = this.findCommonKeywords(items.map(item => item.keywords));
      this.responsePatterns.set(category, commonKeywords);
    });
  }

  /**
   * Find common keywords across items
   */
  private findCommonKeywords(keywordArrays: string[][]): string[] {
    const keywordCounts = new Map<string, number>();
    
    keywordArrays.forEach(keywords => {
      keywords.forEach(keyword => {
        keywordCounts.set(keyword, (keywordCounts.get(keyword) || 0) + 1);
      });
    });
    
    return Array.from(keywordCounts.entries())
      .filter(([_, count]) => count > 1)
      .sort((a, b) => b[1] - a[1])
      .map(([keyword, _]) => keyword)
      .slice(0, 10);
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  /**
   * Get learning statistics
   */
  public getLearningStats() {
    return {
      totalInteractions: this.learningData.length,
      categories: [...new Set(this.learningData.map(item => item.category))],
      averageEffectiveness: this.learningData.reduce((sum, item) => sum + item.effectiveness, 0) / this.learningData.length,
      recentActivity: this.learningData
        .filter(item => Date.now() - item.timestamp.getTime() < 24 * 60 * 60 * 1000)
        .length
    };
  }

  /**
   * Clear learning data
   */
  public clearLearningData() {
    this.learningData = [];
    this.chatContexts.clear();
    this.responsePatterns.clear();
    this.saveLearningData();
  }
}

export default AILearningService;
