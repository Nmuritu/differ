/**
 * Financial Service - Comprehensive Financial Management
 * 
 * This service handles all financial calculations including:
 * - Debt and credit calculations
 * - Plan change financial adjustments
 * - Multi-month booking calculations
 * - Checkout/deletion financial validation
 * - Payment processing and refunds
 */

import { Room } from '@/types/booking';

// Financial record interface
export interface FinancialRecord {
  id: string;
  userId: string;
  type: 'debt' | 'credit' | 'payment' | 'refund' | 'plan_change';
  amount: number;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'cancelled';
  reference?: string;
}

// Plan change calculation result
export interface PlanChangeCalculation {
  currentPlanCost: number;
  newPlanCost: number;
  proratedAmount: number;
  adjustmentType: 'debt' | 'credit' | 'none';
  adjustmentAmount: number;
  description: string;
}

// Multi-month booking calculation
export interface MultiMonthBooking {
  roomPrice: number;
  months: number;
  totalAmount: number;
  discount: number;
  finalAmount: number;
  monthlyBreakdown: Array<{
    month: number;
    amount: number;
    discount: number;
  }>;
}

/**
 * Financial Service Class
 * 
 * Provides comprehensive financial calculations and management
 */
class FinancialService {
  private static instance: FinancialService;

  private constructor() {}

  /**
   * Get the singleton instance of FinancialService
   */
  public static getInstance(): FinancialService {
    if (!FinancialService.instance) {
      FinancialService.instance = new FinancialService();
    }
    return FinancialService.instance;
  }

  /**
   * Calculate plan change financial adjustment
   * @param currentPlan - Current plan type
   * @param newPlan - New plan type
   * @param roomPrices - Room prices object
   * @param daysRemaining - Days remaining in current billing cycle
   * @returns Plan change calculation
   */
  public calculatePlanChange(
    currentPlan: string,
    newPlan: string,
    roomPrices: { single: number; double: number; suite: number },
    daysRemaining: number = 30
  ): PlanChangeCalculation {
    const currentPrice = roomPrices[currentPlan as keyof typeof roomPrices] || 0;
    const newPrice = roomPrices[newPlan as keyof typeof roomPrices] || 0;
    
    // Calculate prorated amounts
    const currentProrated = (currentPrice * daysRemaining) / 30;
    const newProrated = (newPrice * daysRemaining) / 30;
    
    const proratedAmount = newProrated - currentProrated;
    
    let adjustmentType: 'debt' | 'credit' | 'none' = 'none';
    let adjustmentAmount = 0;
    let description = '';
    
    if (proratedAmount > 0) {
      adjustmentType = 'debt';
      adjustmentAmount = proratedAmount;
      description = `Upgrade to ${newPlan}: Additional KSh ${adjustmentAmount.toFixed(2)} due`;
    } else if (proratedAmount < 0) {
      adjustmentType = 'credit';
      adjustmentAmount = Math.abs(proratedAmount);
      description = `Downgrade to ${newPlan}: KSh ${adjustmentAmount.toFixed(2)} credit for next month`;
    } else {
      description = `No financial adjustment needed for ${newPlan}`;
    }
    
    return {
      currentPlanCost: currentPrice,
      newPlanCost: newPrice,
      proratedAmount,
      adjustmentType,
      adjustmentAmount,
      description
    };
  }

  /**
   * Calculate multi-month booking
   * @param roomPrice - Monthly room price
   * @param months - Number of months to book
   * @returns Multi-month booking calculation
   */
  public calculateMultiMonthBooking(roomPrice: number, months: number): MultiMonthBooking {
    const baseAmount = roomPrice * months;
    
    // Apply discounts for longer bookings
    let discount = 0;
    if (months >= 12) {
      discount = 0.15; // 15% discount for 12+ months
    } else if (months >= 6) {
      discount = 0.10; // 10% discount for 6+ months
    } else if (months >= 3) {
      discount = 0.05; // 5% discount for 3+ months
    }
    
    const discountAmount = baseAmount * discount;
    const finalAmount = baseAmount - discountAmount;
    
    // Calculate monthly breakdown
    const monthlyBreakdown = Array.from({ length: months }, (_, index) => {
      const monthAmount = roomPrice;
      const monthDiscount = monthAmount * discount;
      return {
        month: index + 1,
        amount: monthAmount,
        discount: monthDiscount
      };
    });
    
    return {
      roomPrice,
      months,
      totalAmount: baseAmount,
      discount: discountAmount,
      finalAmount,
      monthlyBreakdown
    };
  }

  /**
   * Calculate user's total debt
   * @param userId - User ID
   * @returns Total debt amount
   */
  public async calculateUserDebt(userId: string): Promise<number> {
    try {
      const records = await this.getFinancialRecords(userId);
      return records
        .filter(record => record.type === 'debt' && record.status === 'pending')
        .reduce((total, record) => total + record.amount, 0);
    } catch (error) {
      console.error('Error calculating user debt:', error);
      return 0;
    }
  }

  /**
   * Calculate user's total credit
   * @param userId - User ID
   * @returns Total credit amount
   */
  public async calculateUserCredit(userId: string): Promise<number> {
    try {
      const records = await this.getFinancialRecords(userId);
      return records
        .filter(record => record.type === 'credit' && record.status === 'pending')
        .reduce((total, record) => total + record.amount, 0);
    } catch (error) {
      console.error('Error calculating user credit:', error);
      return 0;
    }
  }

  /**
   * Get financial records for a user
   * @param userId - User ID
   * @returns Array of financial records
   */
  public async getFinancialRecords(userId: string): Promise<FinancialRecord[]> {
    try {
      const records = JSON.parse(localStorage.getItem(`financial_records_${userId}`) || '[]');
      return records;
    } catch (error) {
      console.error('Error getting financial records:', error);
      return [];
    }
  }

  /**
   * Add a financial record
   * @param record - Financial record to add
   * @returns Success status
   */
  public async addFinancialRecord(record: Omit<FinancialRecord, 'id' | 'date'>): Promise<boolean> {
    try {
      const records = await this.getFinancialRecords(record.userId);
      const newRecord: FinancialRecord = {
        ...record,
        id: `fin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        date: new Date().toISOString()
      };
      
      records.push(newRecord);
      localStorage.setItem(`financial_records_${record.userId}`, JSON.stringify(records));
      return true;
    } catch (error) {
      console.error('Error adding financial record:', error);
      return false;
    }
  }

  /**
   * Process checkout/deletion financial validation
   * @param userId - User ID
   * @returns Checkout validation result
   */
  public async validateCheckout(userId: string): Promise<{
    canCheckout: boolean;
    debt: number;
    credit: number;
    netAmount: number;
    message: string;
    requiresPayment: boolean;
    refundAmount: number;
  }> {
    try {
      const debt = await this.calculateUserDebt(userId);
      const credit = await this.calculateUserCredit(userId);
      const netAmount = credit - debt;
      
      let canCheckout = true;
      let message = '';
      let requiresPayment = false;
      let refundAmount = 0;
      
      if (debt > 0) {
        canCheckout = false;
        requiresPayment = true;
        message = `Cannot checkout: You have KSh ${debt.toFixed(2)} in outstanding debt. Please clear your payments first.`;
      } else if (credit > 0) {
        refundAmount = credit;
        message = `Checkout approved: You have KSh ${credit.toFixed(2)} in credit that will be refunded to your payment method.`;
      } else {
        message = 'Checkout approved: No outstanding financial obligations.';
      }
      
      return {
        canCheckout,
        debt,
        credit,
        netAmount,
        message,
        requiresPayment,
        refundAmount
      };
    } catch (error) {
      console.error('Error validating checkout:', error);
      return {
        canCheckout: false,
        debt: 0,
        credit: 0,
        netAmount: 0,
        message: 'Error validating checkout. Please try again.',
        requiresPayment: false,
        refundAmount: 0
      };
    }
  }

  /**
   * Process refund
   * @param userId - User ID
   * @param amount - Refund amount
   * @param paymentMethod - Payment method for refund
   * @returns Success status
   */
  public async processRefund(
    userId: string, 
    amount: number, 
    paymentMethod: string
  ): Promise<boolean> {
    try {
      // Add refund record
      await this.addFinancialRecord({
        userId,
        type: 'refund',
        amount,
        description: `Refund processed via ${paymentMethod}`,
        status: 'completed',
        reference: `REF_${Date.now()}`
      });
      
      // Clear credit records
      const records = await this.getFinancialRecords(userId);
      const updatedRecords = records.map(record => 
        record.type === 'credit' ? { ...record, status: 'completed' as const } : record
      );
      
      localStorage.setItem(`financial_records_${userId}`, JSON.stringify(updatedRecords));
      
      return true;
    } catch (error) {
      console.error('Error processing refund:', error);
      return false;
    }
  }

  /**
   * Clear all financial records for a user (on account deletion)
   * @param userId - User ID
   * @returns Success status
   */
  public async clearUserFinancialRecords(userId: string): Promise<boolean> {
    try {
      localStorage.removeItem(`financial_records_${userId}`);
      return true;
    } catch (error) {
      console.error('Error clearing financial records:', error);
      return false;
    }
  }
}

export default FinancialService;
