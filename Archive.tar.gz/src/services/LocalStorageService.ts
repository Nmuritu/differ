/**
 * LocalStorage Service - Fast & Reliable
 * 
 * This service provides instant database operations using localStorage
 * for maximum speed and simplicity. Optimized for the Thika Mains Hostels app.
 * 
 * Features:
 * - Instant read/write operations
 * - No async overhead
 * - Automatic data validation
 * - Built-in error handling
 * - Optimized for small datasets
 */

import bcrypt from 'bcryptjs';

// Database configuration
const STORAGE_KEY = 'thika_users';
const MAX_ADMINS = 3; // Maximum number of admin users allowed

// User interface for the database
export interface DBUser {
  id: string;
  username: string;
  email: string;
  phone: string;
  passwordHash: string;
  salt: string;
  profileImage?: string;
  isActive: boolean;
  isAdmin: boolean;
  isPreview: boolean;
  isPermanent: boolean;
  hasFullAccess?: boolean;
  hasFreeHousing?: boolean;
  selectedPlan: string;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
  failedLoginAttempts: number;
  lockedUntil?: string;
  subscriptionStartDate?: string;
  lastPaymentDate?: string;
  paymentHistory: Array<{ id: string; plan: string; amount: string; date: string }>;
  settings: {
    theme: 'light' | 'dark' | 'system';
    notifications: boolean;
    language: string;
  };
}

/**
 * LocalStorage Service Class
 * 
 * Handles all database operations with localStorage for maximum speed
 */
class LocalStorageService {
  private static instance: LocalStorageService;
  private isInitialized = false;

  private constructor() {}

  /**
   * Get the singleton instance of LocalStorageService
   */
  public static getInstance(): LocalStorageService {
    if (!LocalStorageService.instance) {
      LocalStorageService.instance = new LocalStorageService();
    }
    return LocalStorageService.instance;
  }

  /**
   * Initialize the service (synchronous for instant performance)
   */
  public initialize(): void {
    if (this.isInitialized) return;
    
    // Check if users exist, create defaults if not
    const users = this.getUsers();
    if (users.length === 0) {
      this.createDefaultUsers();
    }
    
    this.isInitialized = true;
  }

  /**
   * Get all users from localStorage
   */
  private getUsers(): DBUser[] {
    try {
      const usersData = localStorage.getItem(STORAGE_KEY);
      return usersData ? JSON.parse(usersData) : [];
    } catch {
      return [];
    }
  }

  /**
   * Save users to localStorage
   */
  private saveUsers(users: DBUser[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  }

  /**
   * Create default users (makopolo and soni-q)
   * These users are hardcoded into the program to ensure they exist on any machine
   */
  private createDefaultUsers(): void {
    const now = new Date().toISOString();
    
    // Hardcoded permanent users that will always exist
    const defaultUsers: DBUser[] = [
      {
        id: 'admin-makopolo',
        username: 'makopolo',
        email: 'makopolo@gmail.com',
        phone: '0712345678',
        passwordHash: '12345', // Hardcoded password for permanent admin
        salt: 'admin-salt',
        profileImage: '/images/default-profile.svg',
        isActive: true,
        isAdmin: true,
        isPreview: false,
        isPermanent: true,
        hasFullAccess: true,
        selectedPlan: 'suite',
        createdAt: now,
        updatedAt: now,
        lastLoginAt: now,
        failedLoginAttempts: 0,
        subscriptionStartDate: now,
        lastPaymentDate: now,
        paymentHistory: [],
        settings: { theme: 'system', notifications: true, language: 'en' }
      },
      {
        id: 'permanent-soni',
        username: 'soni-q',
        email: 'soni-q@gmail.com',
        phone: '0712345679',
        passwordHash: '12345', // Hardcoded password for permanent user
        salt: 'soni-salt',
        profileImage: '/images/default-profile.svg',
        isActive: true,
        isAdmin: false,
        isPreview: false,
        isPermanent: true,
        hasFullAccess: true,
        hasFreeHousing: true,
        selectedPlan: 'suite',
        createdAt: now,
        updatedAt: now,
        lastLoginAt: now,
        failedLoginAttempts: 0,
        subscriptionStartDate: now,
        lastPaymentDate: now,
        paymentHistory: [],
        settings: { theme: 'system', notifications: true, language: 'en' }
      }
    ];

    this.saveUsers(defaultUsers);
  }

  /**
   * Authenticate user with login credentials
   * Returns detailed authentication result with specific error messages
   */
  public async authenticateUser(loginField: string, password: string): Promise<{
    success: boolean;
    user?: DBUser;
    error?: string;
    suggestion?: string;
    remainingAttempts?: number;
  }> {
    const users = this.getUsers();
    
    // Find user by username, email, or phone
    const user = users.find(u => 
      u.username === loginField || 
      u.email === loginField || 
      u.phone === loginField
    );

    // User not found - suggest creating account
    if (!user) {
      return {
        success: false,
        error: 'Account not found',
        suggestion: 'No account found with these credentials. Please create a new account or try different login details.'
      };
    }

    // Check password - handle both simple and bcrypt hashed passwords
    let passwordValid = false;
    
    // For permanent users with hardcoded passwords
    if ((user.username === 'makopolo' || user.username === 'soni-q') && password === '12345') {
      passwordValid = true;
    }
    // For bcrypt hashed passwords (new users)
    else if (user.passwordHash.startsWith('$2a$') || user.passwordHash.startsWith('$2b$')) {
      passwordValid = await bcrypt.compare(password, user.passwordHash);
    }
    // For simple passwords (fallback)
    else {
      passwordValid = password === user.passwordHash;
    }

    // Password is incorrect
    if (!passwordValid) {
      // Increment failed attempts
      user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;
      this.saveUsers(users);

      const remainingAttempts = 3 - user.failedLoginAttempts;

      // After 3 failed attempts, suggest password reset
      if (user.failedLoginAttempts >= 3) {
        return {
          success: false,
          error: 'Too many failed attempts',
          suggestion: 'You have exceeded the maximum login attempts. Please reset your password using the "Forgot Password" option.',
          remainingAttempts: 0
        };
      }

      // Before 3 attempts, show remaining attempts
      return {
        success: false,
        error: 'Incorrect password',
        suggestion: `Wrong password. You have ${remainingAttempts} attempts remaining.`,
        remainingAttempts
      };
    }

    // Successful login - reset failed attempts and update last login
    user.lastLoginAt = new Date().toISOString();
    user.failedLoginAttempts = 0;
    this.saveUsers(users);

    return {
      success: true,
      user
    };
  }

  /**
   * Create a new user
   */
  public async createUser(userData: {
    username: string;
    email: string;
    phone: string;
    password: string;
    profileImage?: string;
    isAdmin?: boolean;
  }): Promise<DBUser> {
    const users = this.getUsers();
    
    // Check for existing user
    if (users.find(u => u.username === userData.username)) {
      throw new Error('Username already exists');
    }
    if (users.find(u => u.email === userData.email)) {
      throw new Error('Email already exists');
    }
    if (users.find(u => u.phone === userData.phone)) {
      throw new Error('Phone number already exists');
    }

    // Hash password
    const salt = Math.random().toString(36).substring(2, 15);
    const passwordHash = await bcrypt.hash(userData.password, 12);

    const newUser: DBUser = {
      id: `user-${Date.now()}`,
      username: userData.username,
      email: userData.email,
      phone: userData.phone,
      passwordHash,
      salt,
      profileImage: userData.profileImage || '/images/default-profile.svg',
      isActive: true,
      isAdmin: userData.isAdmin || false,
      isPreview: false,
      isPermanent: false,
      hasFullAccess: false,
      selectedPlan: 'single',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      failedLoginAttempts: 0,
      subscriptionStartDate: new Date().toISOString(),
      lastPaymentDate: new Date().toISOString(),
      paymentHistory: [],
      settings: { theme: 'system', notifications: true, language: 'en' }
    };

    users.push(newUser);
    this.saveUsers(users);
    
    return newUser;
  }

  /**
   * Get user by ID
   */
  public async getUser(userId: string): Promise<DBUser | null> {
    const users = this.getUsers();
    return users.find(u => u.id === userId) || null;
  }

  /**
   * Get user by username
   */
  public async getUserByUsername(username: string): Promise<DBUser | null> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.username === username);
      return user || null;
    } catch (error) {
      console.error('Error in getUserByUsername:', error);
      return null;
    }
  }

  /**
   * Get user by email
   */
  public async getUserByEmail(email: string): Promise<DBUser | null> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.email === email);
      return user || null;
    } catch (error) {
      console.error('Error in getUserByEmail:', error);
      return null;
    }
  }

  /**
   * Get user by phone
   */
  public async getUserByPhone(phone: string): Promise<DBUser | null> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.phone === phone);
      return user || null;
    } catch (error) {
      console.error('Error in getUserByPhone:', error);
      return null;
    }
  }

  /**
   * Update user
   */
  public async updateUser(user: DBUser): Promise<boolean> {
    try {
      const users = this.getUsers();
      const index = users.findIndex(u => u.id === user.id);
      
      if (index === -1) return false;
      
      user.updatedAt = new Date().toISOString();
      users[index] = user;
      this.saveUsers(users);
      
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get all users
   */
  public async getAllUsers(): Promise<DBUser[]> {
    return this.getUsers();
  }

  /**
   * Delete user
   */
  public async deleteUser(userId: string): Promise<boolean> {
    try {
      const users = this.getUsers();
      const userIndex = users.findIndex(u => u.id === userId);
      
      if (userIndex === -1) return false;

      const user = users[userIndex];
      
      // Prevent deletion of admin and permanent users
      if (user.isAdmin || user.isPermanent) {
        return false;
      }

      // Remove user from array
      users.splice(userIndex, 1);
      this.saveUsers(users);
      
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Delete user by username
   */
  public async deleteUserByUsername(username: string): Promise<boolean> {
    const user = await this.getUserByUsername(username);
    if (!user) return false;
    return await this.deleteUser(user.id);
  }

  /**
   * Delete user by email
   */
  public async deleteUserByEmail(email: string): Promise<boolean> {
    const user = await this.getUserByEmail(email);
    if (!user) return false;
    return await this.deleteUser(user.id);
  }

  /**
   * Delete user by phone
   */
  public async deleteUserByPhone(phone: string): Promise<boolean> {
    const user = await this.getUserByPhone(phone);
    if (!user) return false;
    return await this.deleteUser(user.id);
  }

  /**
   * Promote user to admin
   */
  public async promoteUserToAdmin(userId: string, adminId: string): Promise<boolean> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.id === userId);
      const admin = users.find(u => u.id === adminId);
      
      if (!user || !admin?.isAdmin) return false;
      
      // Prevent soni-q from being promoted to admin
      if (user.username === 'soni-q' || user.email === 'soni-q@gmail.com') {
        return false;
      }
      
      // Check admin limit
      const adminCount = users.filter(u => u.isAdmin).length;
      if (adminCount >= MAX_ADMINS) return false;
      
      user.isAdmin = true;
      user.isPermanent = true;
      user.updatedAt = new Date().toISOString();
      
      this.saveUsers(users);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Demote admin to user
   */
  public async demoteAdminToUser(userId: string, adminId: string): Promise<boolean> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.id === userId);
      const admin = users.find(u => u.id === adminId);
      
      if (!user || !admin?.isAdmin) return false;
      
      // Only makopolo can demote other admins
      if (admin.username !== 'makopolo') return false;
      
      // Cannot demote makopolo
      if (user.username === 'makopolo') return false;
      
      user.isAdmin = false;
      user.isPermanent = false;
      user.updatedAt = new Date().toISOString();
      
      this.saveUsers(users);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Clear all non-permanent users
   */
  public async clearNonPermanentUsers(): Promise<boolean> {
    try {
      const users = this.getUsers();
      const permanentUsers = users.filter(u => u.isPermanent);
      this.saveUsers(permanentUsers);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Clear all data (for admin use)
   */
  public async clearAllData(): Promise<void> {
    localStorage.removeItem(STORAGE_KEY);
    this.createDefaultUsers();
  }

  /**
   * Remove specific user by email or phone
   */
  public async removeUserByEmailOrPhone(emailOrPhone: string): Promise<boolean> {
    try {
      const users = this.getUsers();
      const filteredUsers = users.filter(user => 
        user.email !== emailOrPhone && user.phone !== emailOrPhone
      );
      
      if (filteredUsers.length === users.length) {
        return false; // User not found
      }
      
      this.saveUsers(filteredUsers);
      return true;
    } catch (error) {
      console.error('Error removing user:', error);
      return false;
    }
  }
}

export default LocalStorageService;
