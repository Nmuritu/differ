/**
 * Image Service - Centralized Image Management
 * 
 * This service manages all images used throughout the application,
 * ensuring consistency and real-time updates when images are changed.
 */

// Default image paths
const DEFAULT_IMAGES = {
  single: '/images/single-room.jpg',
  double: '/images/double-room.jpg',
  suite: '/images/suite.jpg',
  profile: '/images/default-profile.svg'
};

// Current image state
let currentImages = { ...DEFAULT_IMAGES };


class ImageService {
  private static instance: ImageService;

  private constructor() {
    this.loadImagesFromStorage();
  }

  public static getInstance(): ImageService {
    if (!ImageService.instance) {
      ImageService.instance = new ImageService();
    }
    return ImageService.instance;
  }

  /**
   * Load images from localStorage
   */
  private loadImagesFromStorage(): void {
    try {
      const storedImages = localStorage.getItem('appImages');
      if (storedImages) {
        const parsedImages = JSON.parse(storedImages);
        currentImages = { ...DEFAULT_IMAGES, ...parsedImages };
      }
    } catch (error) {
      console.error('Error loading images from storage:', error);
      currentImages = { ...DEFAULT_IMAGES };
    }
  }

  /**
   * Save images to localStorage
   */
  private saveImagesToStorage(): void {
    try {
      localStorage.setItem('appImages', JSON.stringify(currentImages));
    } catch (error) {
      console.error('Error saving images to storage:', error);
    }
  }

  /**
   * Get current image for a room type
   */
  public getRoomImage(roomType: 'single' | 'double' | 'suite'): string {
    return currentImages[roomType] || DEFAULT_IMAGES[roomType];
  }

  /**
   * Get default profile image
   */
  public getProfileImage(): string {
    return currentImages.profile || DEFAULT_IMAGES.profile;
  }

  /**
   * Update room image
   */
  public updateRoomImage(roomType: 'single' | 'double' | 'suite', imageUrl: string): void {
    currentImages[roomType] = imageUrl;
    this.saveImagesToStorage();
  }


  /**
   * Initialize the service
   */
  public initialize(): void {
    this.loadImagesFromStorage();
  }
}

export default ImageService;
