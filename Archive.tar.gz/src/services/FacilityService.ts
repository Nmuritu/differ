/**
 * Facility Service
 * 
 * Manages room facilities and amenities with real-time updates across the application.
 * Allows admins to add, remove, and modify facilities that are displayed throughout the app.
 */

export interface Facility {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'essential' | 'premium' | 'security' | 'convenience';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FacilityUpdate {
  type: 'facility_added' | 'facility_updated' | 'facility_removed' | 'facility_toggled';
  facility: Facility;
  timestamp: string;
}

class FacilityService {
  private static instance: FacilityService;
  private facilities: Facility[] = [];
  private listeners: ((update: FacilityUpdate) => void)[] = [];

  private constructor() {
    this.loadFacilities();
    this.setupStorageListener();
  }

  public static getInstance(): FacilityService {
    if (!FacilityService.instance) {
      FacilityService.instance = new FacilityService();
    }
    return FacilityService.instance;
  }

  /**
   * Load facilities from localStorage
   */
  private loadFacilities(): void {
    try {
      const stored = localStorage.getItem('roomFacilities');
      if (stored) {
        this.facilities = JSON.parse(stored);
      } else {
        // Initialize with default facilities
        this.initializeDefaultFacilities();
      }
    } catch (error) {
      console.error('Error loading facilities:', error);
      this.initializeDefaultFacilities();
    }
  }

  /**
   * Initialize default facilities
   */
  private initializeDefaultFacilities(): void {
    this.facilities = [
      {
        id: 'wifi',
        name: 'Free Wi-Fi',
        description: 'High-speed internet connection',
        icon: '📶',
        category: 'essential',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'parking',
        name: 'Free Parking',
        description: 'Secure parking space for residents',
        icon: '🅿️',
        category: 'convenience',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'security',
        name: '24/7 Security',
        description: 'CCTV surveillance and security guards',
        icon: '🔒',
        category: 'security',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'utilities',
        name: 'Utilities Included',
        description: 'Water and electricity included in rent',
        icon: '⚡',
        category: 'essential',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'laundry',
        name: 'Laundry Facilities',
        description: 'Shared laundry room with washing machines',
        icon: '🧺',
        category: 'convenience',
        isActive: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'gym',
        name: 'Fitness Center',
        description: 'On-site gym with basic equipment',
        icon: '💪',
        category: 'premium',
        isActive: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'study',
        name: 'Study Room',
        description: 'Quiet study area with desks and chairs',
        icon: '📚',
        category: 'convenience',
        isActive: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'kitchen',
        name: 'Shared Kitchen',
        description: 'Common kitchen with cooking facilities',
        icon: '🍳',
        category: 'convenience',
        isActive: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    this.saveFacilities();
  }

  /**
   * Save facilities to localStorage
   */
  private saveFacilities(): void {
    try {
      localStorage.setItem('roomFacilities', JSON.stringify(this.facilities));
    } catch (error) {
      console.error('Error saving facilities:', error);
    }
  }

  /**
   * Setup storage listener for real-time updates
   */
  private setupStorageListener(): void {
    window.addEventListener('storage', (e) => {
      if (e.key === 'roomFacilities' && e.newValue) {
        try {
          const newFacilities = JSON.parse(e.newValue);
          this.facilities = newFacilities;
          this.notifyListeners({
            type: 'facility_updated',
            facility: newFacilities[0], // This is a simplified approach
            timestamp: new Date().toISOString()
          });
        } catch (error) {
          console.error('Error parsing facility update:', error);
        }
      }
    });
  }

  /**
   * Get all facilities
   */
  public getFacilities(): Facility[] {
    return [...this.facilities];
  }

  /**
   * Get active facilities
   */
  public getActiveFacilities(): Facility[] {
    return this.facilities.filter(facility => facility.isActive);
  }

  /**
   * Get facilities by category
   */
  public getFacilitiesByCategory(category: Facility['category']): Facility[] {
    return this.facilities.filter(facility => facility.category === category);
  }

  /**
   * Get facility by ID
   */
  public getFacility(id: string): Facility | undefined {
    return this.facilities.find(facility => facility.id === id);
  }

  /**
   * Add new facility
   */
  public addFacility(facility: Omit<Facility, 'id' | 'createdAt' | 'updatedAt'>): Facility {
    const newFacility: Facility = {
      ...facility,
      id: `facility_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.facilities.push(newFacility);
    this.saveFacilities();
    this.notifyListeners({
      type: 'facility_added',
      facility: newFacility,
      timestamp: new Date().toISOString()
    });

    return newFacility;
  }

  /**
   * Update facility
   */
  public updateFacility(id: string, updates: Partial<Omit<Facility, 'id' | 'createdAt'>>): Facility | null {
    const index = this.facilities.findIndex(facility => facility.id === id);
    if (index === -1) return null;

    const updatedFacility: Facility = {
      ...this.facilities[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.facilities[index] = updatedFacility;
    this.saveFacilities();
    this.notifyListeners({
      type: 'facility_updated',
      facility: updatedFacility,
      timestamp: new Date().toISOString()
    });

    return updatedFacility;
  }

  /**
   * Toggle facility active status
   */
  public toggleFacility(id: string): Facility | null {
    const facility = this.getFacility(id);
    if (!facility) return null;

    return this.updateFacility(id, { isActive: !facility.isActive });
  }

  /**
   * Remove facility
   */
  public removeFacility(id: string): boolean {
    const index = this.facilities.findIndex(facility => facility.id === id);
    if (index === -1) return false;

    const facility = this.facilities[index];
    this.facilities.splice(index, 1);
    this.saveFacilities();
    this.notifyListeners({
      type: 'facility_removed',
      facility,
      timestamp: new Date().toISOString()
    });

    return true;
  }

  /**
   * Subscribe to facility updates
   */
  public subscribe(listener: (update: FacilityUpdate) => void): () => void {
    this.listeners.push(listener);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  /**
   * Notify listeners of updates
   */
  private notifyListeners(update: FacilityUpdate): void {
    this.listeners.forEach(listener => {
      try {
        listener(update);
      } catch (error) {
        console.error('Error in facility update listener:', error);
      }
    });
  }

  /**
   * Get facility statistics
   */
  public getStats(): {
    total: number;
    active: number;
    inactive: number;
    byCategory: Record<string, number>;
  } {
    const active = this.facilities.filter(f => f.isActive).length;
    const inactive = this.facilities.length - active;
    
    const byCategory = this.facilities.reduce((acc, facility) => {
      acc[facility.category] = (acc[facility.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: this.facilities.length,
      active,
      inactive,
      byCategory
    };
  }

  /**
   * Reset to default facilities
   */
  public resetToDefaults(): void {
    this.initializeDefaultFacilities();
    this.notifyListeners({
      type: 'facility_updated',
      facility: this.facilities[0], // Simplified approach
      timestamp: new Date().toISOString()
    });
  }
}

export default FacilityService;
