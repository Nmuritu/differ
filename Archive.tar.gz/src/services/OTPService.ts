/**
 * OTP Service
 * 
 * Handles OTP generation, storage, and verification for password reset
 * and other security operations.
 */

export interface OTPRecord {
  id: string;
  userId?: string;
  email?: string;
  phone?: string;
  otp: string;
  purpose: 'password_reset' | 'phone_verification' | 'email_verification';
  expiresAt: string;
  attempts: number;
  maxAttempts: number;
  isUsed: boolean;
  createdAt: string;
}

export interface OTPVerificationResult {
  success: boolean;
  message: string;
  remainingAttempts?: number;
}

class OTPService {
  private static instance: OTPService;
  private readonly OTP_EXPIRY_MINUTES = 10; // OTP expires in 10 minutes
  private readonly MAX_ATTEMPTS = 3; // Maximum verification attempts

  private constructor() {}

  public static getInstance(): OTPService {
    if (!OTPService.instance) {
      OTPService.instance = new OTPService();
    }
    return OTPService.instance;
  }

  /**
   * Generate a 6-digit OTP
   */
  private generateOTP(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  /**
   * Generate and store OTP for password reset
   */
  public generatePasswordResetOTP(identifier: string, type: 'email' | 'phone'): { success: boolean; otpId: string; otp: string; message: string } {
    try {
      const otp = this.generateOTP();
      const otpId = `otp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const expiresAt = new Date(Date.now() + this.OTP_EXPIRY_MINUTES * 60 * 1000).toISOString();

      const otpRecord: OTPRecord = {
        id: otpId,
        [type]: identifier,
        otp,
        purpose: 'password_reset',
        expiresAt,
        attempts: 0,
        maxAttempts: this.MAX_ATTEMPTS,
        isUsed: false,
        createdAt: new Date().toISOString()
      };

      // Store OTP in localStorage (in production, use secure backend storage)
      const existingOTPs = JSON.parse(localStorage.getItem('otps') || '[]');
      
      // Remove any existing OTPs for the same identifier and purpose
      const filteredOTPs = existingOTPs.filter((record: OTPRecord) => 
        !(record[type] === identifier && record.purpose === 'password_reset')
      );
      
      filteredOTPs.push(otpRecord);
      localStorage.setItem('otps', JSON.stringify(filteredOTPs));

      // Simulate sending OTP (in production, integrate with SMS/Email service)
      this.simulateOTPDelivery(identifier, type, otp);

      return {
        success: true,
        otpId,
        otp, // In production, don't return the actual OTP
        message: `OTP sent to your ${type === 'email' ? 'email' : 'phone number'}`
      };
    } catch (error) {
      console.error('Error generating OTP:', error);
      return {
        success: false,
        otpId: '',
        otp: '',
        message: 'Failed to generate OTP. Please try again.'
      };
    }
  }

  /**
   * Verify OTP
   */
  public verifyOTP(otpId: string, enteredOTP: string): OTPVerificationResult {
    try {
      const otps = JSON.parse(localStorage.getItem('otps') || '[]');
      const otpIndex = otps.findIndex((record: OTPRecord) => record.id === otpId);

      if (otpIndex === -1) {
        return {
          success: false,
          message: 'Invalid OTP session. Please request a new OTP.'
        };
      }

      const otpRecord = otps[otpIndex];

      // Check if OTP is already used
      if (otpRecord.isUsed) {
        return {
          success: false,
          message: 'This OTP has already been used. Please request a new one.'
        };
      }

      // Check if OTP is expired
      if (new Date() > new Date(otpRecord.expiresAt)) {
        return {
          success: false,
          message: 'OTP has expired. Please request a new one.'
        };
      }

      // Check if max attempts exceeded
      if (otpRecord.attempts >= otpRecord.maxAttempts) {
        return {
          success: false,
          message: 'Maximum verification attempts exceeded. Please request a new OTP.'
        };
      }

      // Increment attempts
      otpRecord.attempts += 1;

      // Verify OTP
      if (otpRecord.otp === enteredOTP) {
        // Mark as used
        otpRecord.isUsed = true;
        otps[otpIndex] = otpRecord;
        localStorage.setItem('otps', JSON.stringify(otps));

        return {
          success: true,
          message: 'OTP verified successfully!'
        };
      } else {
        // Update attempts count
        otps[otpIndex] = otpRecord;
        localStorage.setItem('otps', JSON.stringify(otps));

        const remainingAttempts = otpRecord.maxAttempts - otpRecord.attempts;
        return {
          success: false,
          message: `Invalid OTP. ${remainingAttempts} attempts remaining.`,
          remainingAttempts
        };
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
      return {
        success: false,
        message: 'Error verifying OTP. Please try again.'
      };
    }
  }

  /**
   * Get OTP record by ID
   */
  public getOTPRecord(otpId: string): OTPRecord | null {
    try {
      const otps = JSON.parse(localStorage.getItem('otps') || '[]');
      return otps.find((record: OTPRecord) => record.id === otpId) || null;
    } catch (error) {
      console.error('Error getting OTP record:', error);
      return null;
    }
  }

  /**
   * Clean up expired OTPs
   */
  public cleanupExpiredOTPs(): void {
    try {
      const otps = JSON.parse(localStorage.getItem('otps') || '[]');
      const now = new Date();
      
      const validOTPs = otps.filter((record: OTPRecord) => 
        new Date(record.expiresAt) > now
      );
      
      localStorage.setItem('otps', JSON.stringify(validOTPs));
    } catch (error) {
      console.error('Error cleaning up OTPs:', error);
    }
  }

  /**
   * Simulate OTP delivery (for demo purposes)
   * In production, integrate with SMS gateway (Twilio, AWS SNS) and email service
   */
  private simulateOTPDelivery(identifier: string, type: 'email' | 'phone', otp: string): void {
    if (type === 'email') {
    } else {
    }

    // Show notification to user (for demo purposes)
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        alert(` Demo OTP Delivery\n\n${type === 'email' ? 'Email' : 'SMS'} sent to: ${identifier}\nOTP: ${otp}\n\n(In production, you would receive this via ${type === 'email' ? 'email' : 'SMS'})`);
      }, 1000);
    }
  }

  /**
   * Resend OTP (generates new OTP and invalidates old one)
   */
  public resendOTP(otpId: string): { success: boolean; newOtpId: string; message: string } {
    try {
      const otpRecord = this.getOTPRecord(otpId);
      if (!otpRecord) {
        return {
          success: false,
          newOtpId: '',
          message: 'Invalid OTP session'
        };
      }

      // Determine identifier and type
      const identifier = otpRecord.email || otpRecord.phone || '';
      const type = otpRecord.email ? 'email' : 'phone';

      // Generate new OTP
      const result = this.generatePasswordResetOTP(identifier, type);
      
      if (result.success) {
        // Invalidate old OTP
        const otps = JSON.parse(localStorage.getItem('otps') || '[]');
        const updatedOTPs = otps.map((record: OTPRecord) => 
          record.id === otpId ? { ...record, isUsed: true } : record
        );
        localStorage.setItem('otps', JSON.stringify(updatedOTPs));
      }

      return {
        success: result.success,
        newOtpId: result.otpId,
        message: result.message
      };
    } catch (error) {
      console.error('Error resending OTP:', error);
      return {
        success: false,
        newOtpId: '',
        message: 'Failed to resend OTP'
      };
    }
  }
}

export default OTPService;
