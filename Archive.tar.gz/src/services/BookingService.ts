/**
 * Booking Service - Comprehensive Booking Management
 * 
 * This service handles all booking-related operations including:
 * - Booking ID generation with proper format
 * - Booking creation and management
 * - Payment tracking
 * - Booking validation
 * - Integration with room management
 */

import { BookingDetails } from '@/types/booking';
import FinancialService from './FinancialService';

// Booking interface for database storage
export interface DBBooking extends BookingDetails {
  id: string;
  userId?: string;
  createdAt: Date;
  updatedAt: Date;
  paymentReference?: string;
  notes?: string;
}

/**
 * Booking Service Class
 * 
 * Provides comprehensive booking management functionality
 * with proper ID generation and data persistence.
 */
class BookingService {
  private static instance: BookingService;
  private financialService: FinancialService;

  private constructor() {
    // No database service needed - using localStorage directly
    this.financialService = FinancialService.getInstance();
  }

  /**
   * Get the singleton instance of BookingService
   */
  public static getInstance(): BookingService {
    if (!BookingService.instance) {
      BookingService.instance = new BookingService();
    }
    return BookingService.instance;
  }

  /**
   * Generate a unique booking ID with proper format
   * Format: TMH-YYYY-MM-DD-XXXXX
   * Example: TMH-2024-01-15-00001
   */
  public generateBookingId(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    
    // Generate a 5-digit sequential number based on timestamp
    const timestamp = now.getTime();
    const sequence = String(timestamp % 100000).padStart(5, '0');
    
    return `TMH-${year}-${month}-${day}-${sequence}`;
  }

  /**
   * Generate a payment reference number
   * Format: PAY-YYYYMMDD-XXXXX
   */
  public generatePaymentReference(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const sequence = String(Math.floor(Math.random() * 100000)).padStart(5, '0');
    
    return `PAY-${year}${month}${day}-${sequence}`;
  }

  /**
   * Create a new booking with proper ID generation
   */
  public async createBooking(bookingData: Omit<BookingDetails, 'id'>): Promise<DBBooking> {
    try {
      const now = new Date();
      
      const booking: DBBooking = {
        ...bookingData,
        id: this.generateBookingId(),
        createdAt: now,
        updatedAt: now,
        paymentReference: this.generatePaymentReference()
      };

      // Store in localStorage for now (will be replaced with IndexedDB)
      const existingBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      existingBookings.push(booking);
      localStorage.setItem('bookings', JSON.stringify(existingBookings));

      return booking;
    } catch (error) {
      console.error('Error creating booking:', error);
      throw new Error('Failed to create booking');
    }
  }

  /**
   * Get a booking by ID
   */
  public async getBookingById(bookingId: string): Promise<DBBooking | null> {
    try {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      const booking = bookings.find((b: DBBooking) => b.id === bookingId);
      return booking || null;
    } catch (error) {
      console.error('Error getting booking:', error);
      return null;
    }
  }

  /**
   * Update a booking
   */
  public async updateBooking(bookingId: string, updates: Partial<DBBooking>): Promise<boolean> {
    try {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      const bookingIndex = bookings.findIndex((b: DBBooking) => b.id === bookingId);
      
      if (bookingIndex === -1) {
        return false;
      }

      bookings[bookingIndex] = {
        ...bookings[bookingIndex],
        ...updates,
        updatedAt: new Date()
      };

      localStorage.setItem('bookings', JSON.stringify(bookings));
      return true;
    } catch (error) {
      console.error('Error updating booking:', error);
      return false;
    }
  }

  /**
   * Get all bookings for a user
   */
  public async getUserBookings(userId: string): Promise<DBBooking[]> {
    try {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      return bookings.filter((b: DBBooking) => b.userId === userId);
    } catch (error) {
      console.error('Error getting user bookings:', error);
      return [];
    }
  }

  /**
   * Get all bookings (admin only)
   */
  public async getAllBookings(): Promise<DBBooking[]> {
    try {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      return bookings;
    } catch (error) {
      console.error('Error getting all bookings:', error);
      return [];
    }
  }

  /**
   * Cancel a booking
   */
  public async cancelBooking(bookingId: string, reason?: string): Promise<boolean> {
    try {
      return await this.updateBooking(bookingId, {
        status: 'cancelled',
        notes: reason ? `Cancelled: ${reason}` : 'Cancelled by user'
      });
    } catch (error) {
      console.error('Error cancelling booking:', error);
      return false;
    }
  }

  /**
   * Confirm a booking (after payment)
   */
  public async confirmBooking(bookingId: string, paymentReference?: string): Promise<boolean> {
    try {
      return await this.updateBooking(bookingId, {
        status: 'confirmed',
        paymentStatus: 'paid',
        paymentReference: paymentReference || this.generatePaymentReference()
      });
    } catch (error) {
      console.error('Error confirming booking:', error);
      return false;
    }
  }

  /**
   * Calculate booking total based on room price and duration
   */
  public calculateBookingTotal(
    roomPrice: number, 
    checkIn: Date, 
    checkOut: Date
  ): number {
    const timeDiff = checkOut.getTime() - checkIn.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    
    // Minimum 1 day charge
    const days = Math.max(1, daysDiff);
    
    return roomPrice * days;
  }

  /**
   * Calculate multi-month booking with discounts
   * @param roomPrice - Monthly room price
   * @param months - Number of months to book
   * @returns Multi-month booking calculation
   */
  public calculateMultiMonthBooking(roomPrice: number, months: number) {
    return this.financialService.calculateMultiMonthBooking(roomPrice, months);
  }

  /**
   * Create multi-month booking
   * @param bookingData - Booking data with months
   * @param months - Number of months
   * @returns Created booking
   */
  public async createMultiMonthBooking(
    bookingData: Omit<BookingDetails, 'id' | 'totalAmount'> & { roomPrice: number },
    months: number
  ): Promise<DBBooking> {
    try {
      const calculation = this.calculateMultiMonthBooking(bookingData.roomPrice, months);
      
      const now = new Date();
      const booking: DBBooking = {
        ...bookingData,
        id: this.generateBookingId(),
        totalAmount: calculation.finalAmount,
        createdAt: now,
        updatedAt: now,
        paymentReference: this.generatePaymentReference(),
        notes: `Multi-month booking for ${months} months with ${(calculation.discount / calculation.totalAmount * 100).toFixed(1)}% discount`
      };

      // Store in localStorage
      const existingBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      existingBookings.push(booking);
      localStorage.setItem('bookings', JSON.stringify(existingBookings));

      return booking;
    } catch (error) {
      console.error('Error creating multi-month booking:', error);
      throw new Error('Failed to create multi-month booking');
    }
  }

  /**
   * Validate booking data
   */
  public validateBooking(bookingData: Partial<BookingDetails>): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // Required fields validation
    if (!bookingData.guestName?.trim()) {
      errors.push('Guest name is required');
    }

    if (!bookingData.email?.trim()) {
      errors.push('Email is required');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(bookingData.email)) {
      errors.push('Valid email is required');
    }

    if (!bookingData.phone?.trim()) {
      errors.push('Phone number is required');
    } else if (!/^\d{10,}$/.test(bookingData.phone.replace(/\D/g, ''))) {
      errors.push('Valid phone number is required');
    }

    if (!bookingData.idNumber?.trim()) {
      errors.push('ID number is required');
    }

    if (!bookingData.checkIn) {
      errors.push('Check-in date is required');
    }

    if (!bookingData.checkOut) {
      errors.push('Check-out date is required');
    }

    // Date validation
    if (bookingData.checkIn && bookingData.checkOut) {
      if (bookingData.checkIn >= bookingData.checkOut) {
        errors.push('Check-out date must be after check-in date');
      }

      if (bookingData.checkIn < new Date()) {
        errors.push('Check-in date cannot be in the past');
      }
    }

    if (!bookingData.roomId) {
      errors.push('Room selection is required');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Get booking statistics (admin only)
   */
  public async getBookingStats(): Promise<{
    totalBookings: number;
    pendingBookings: number;
    confirmedBookings: number;
    cancelledBookings: number;
    totalRevenue: number;
    averageBookingValue: number;
  }> {
    try {
      const bookings = await this.getAllBookings();
      
      const stats = {
        totalBookings: bookings.length,
        pendingBookings: bookings.filter(b => b.status === 'pending').length,
        confirmedBookings: bookings.filter(b => b.status === 'confirmed').length,
        cancelledBookings: bookings.filter(b => b.status === 'cancelled').length,
        totalRevenue: bookings
          .filter(b => b.paymentStatus === 'paid')
          .reduce((sum, b) => sum + b.totalAmount, 0),
        averageBookingValue: 0
      };

      stats.averageBookingValue = stats.totalBookings > 0 
        ? stats.totalRevenue / stats.totalBookings 
        : 0;

      return stats;
    } catch (error) {
      console.error('Error getting booking stats:', error);
      return {
        totalBookings: 0,
        pendingBookings: 0,
        confirmedBookings: 0,
        cancelledBookings: 0,
        totalRevenue: 0,
        averageBookingValue: 0
      };
    }
  }

  /**
   * Search bookings by various criteria
   */
  public async searchBookings(criteria: {
    guestName?: string;
    email?: string;
    phone?: string;
    bookingId?: string;
    status?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<DBBooking[]> {
    try {
      const bookings = await this.getAllBookings();
      
      return bookings.filter(booking => {
        if (criteria.bookingId && booking.id !== criteria.bookingId) {
          return false;
        }
        
        if (criteria.guestName && 
            !booking.guestName.toLowerCase().includes(criteria.guestName.toLowerCase())) {
          return false;
        }
        
        if (criteria.email && 
            !booking.email.toLowerCase().includes(criteria.email.toLowerCase())) {
          return false;
        }
        
        if (criteria.phone && 
            !booking.phone.includes(criteria.phone)) {
          return false;
        }
        
        if (criteria.status && booking.status !== criteria.status) {
          return false;
        }
        
        if (criteria.dateFrom && booking.checkIn < criteria.dateFrom) {
          return false;
        }
        
        if (criteria.dateTo && booking.checkIn > criteria.dateTo) {
          return false;
        }
        
        return true;
      });
    } catch (error) {
      console.error('Error searching bookings:', error);
      return [];
    }
  }
}

export default BookingService;
