/**
 * Chat Service - Real-time Communication System
 * 
 * Handles real-time chat communication between admins and clients
 * with message persistence and synchronization.
 */

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderType: 'admin' | 'client';
  message: string;
  timestamp: Date;
  isRead: boolean;
  threadId: string;
  attachments?: string[];
}

export interface ChatThread {
  id: string;
  clientId: string;
  clientName: string;
  adminId?: string;
  adminName?: string;
  status: 'open' | 'assigned' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  subject: string;
  createdAt: Date;
  updatedAt: Date;
  lastMessage?: ChatMessage;
  unreadCount: number;
}

class ChatService {
  private static instance: ChatService;
  private threads: ChatThread[] = [];
  private messages: ChatMessage[] = [];
  private listeners: Array<(threads: ChatThread[]) => void> = [];
  private messageListeners: Array<(messages: ChatMessage[], threadId: string) => void> = [];

  private constructor() {
    this.loadFromStorage();
  }

  public static getInstance(): ChatService {
    if (!ChatService.instance) {
      ChatService.instance = new ChatService();
    }
    return ChatService.instance;
  }

  /**
   * Load chat data from localStorage
   */
  private loadFromStorage() {
    try {
      const threadsData = localStorage.getItem('chat_threads');
      const messagesData = localStorage.getItem('chat_messages');
      
      if (threadsData) {
        this.threads = JSON.parse(threadsData).map((thread: Record<string, unknown>) => ({
          ...thread,
          createdAt: new Date(thread.createdAt as string),
          updatedAt: new Date(thread.updatedAt as string)
        }));
      }
      
      if (messagesData) {
        this.messages = JSON.parse(messagesData).map((message: Record<string, unknown>) => ({
          ...message,
          timestamp: new Date(message.timestamp as string)
        }));
      }
    } catch (error) {
      console.error('Error loading chat data:', error);
    }
  }

  /**
   * Save chat data to localStorage
   */
  private saveToStorage() {
    try {
      localStorage.setItem('chat_threads', JSON.stringify(this.threads));
      localStorage.setItem('chat_messages', JSON.stringify(this.messages));
    } catch (error) {
      console.error('Error saving chat data:', error);
    }
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  /**
   * Create a new chat thread
   */
  public createThread(
    clientId: string,
    clientName: string,
    subject: string,
    priority: 'low' | 'medium' | 'high' | 'urgent' = 'medium'
  ): ChatThread {
    const thread: ChatThread = {
      id: this.generateId(),
      clientId,
      clientName,
      status: 'open',
      priority,
      subject,
      createdAt: new Date(),
      updatedAt: new Date(),
      unreadCount: 0
    };

    this.threads.push(thread);
    this.saveToStorage();
    this.notifyListeners();
    
    return thread;
  }

  /**
   * Send a message in a thread
   */
  public sendMessage(
    threadId: string,
    senderId: string,
    senderName: string,
    senderType: 'admin' | 'client',
    message: string
  ): ChatMessage {
    const chatMessage: ChatMessage = {
      id: this.generateId(),
      senderId,
      senderName,
      senderType,
      message,
      timestamp: new Date(),
      isRead: false,
      threadId
    };

    this.messages.push(chatMessage);

    // Update thread
    const thread = this.threads.find(t => t.id === threadId);
    if (thread) {
      thread.updatedAt = new Date();
      thread.lastMessage = chatMessage;
      
      // Increment unread count for the other party
      if (senderType === 'client') {
        thread.unreadCount++;
      } else if (senderType === 'admin') {
        // Mark as read for admin, increment for client
        thread.unreadCount = this.messages
          .filter(m => m.threadId === threadId && m.senderType === 'client' && !m.isRead)
          .length;
      }
    }

    this.saveToStorage();
    this.notifyMessageListeners(threadId);
    this.notifyListeners();

    // Trigger real-time update for all connected clients
    this.triggerRealTimeUpdate(threadId, chatMessage);

    return chatMessage;
  }

  /**
   * Get all threads for admin view
   */
  public getAdminThreads(): ChatThread[] {
    return this.threads.sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  /**
   * Get threads for a specific client
   */
  public getClientThreads(clientId: string): ChatThread[] {
    return this.threads
      .filter(t => t.clientId === clientId)
      .sort((a, b) => 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      );
  }

  /**
   * Get messages for a specific thread
   */
  public getThreadMessages(threadId: string): ChatMessage[] {
    return this.messages
      .filter(m => m.threadId === threadId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  /**
   * Assign thread to admin
   */
  public assignThread(threadId: string, adminId: string, adminName: string): boolean {
    const thread = this.threads.find(t => t.id === threadId);
    if (thread) {
      thread.adminId = adminId;
      thread.adminName = adminName;
      thread.status = 'assigned';
      thread.updatedAt = new Date();
      this.saveToStorage();
      this.notifyListeners();
      return true;
    }
    return false;
  }

  /**
   * Update thread status
   */
  public updateThreadStatus(threadId: string, status: 'open' | 'assigned' | 'resolved' | 'closed'): boolean {
    const thread = this.threads.find(t => t.id === threadId);
    if (thread) {
      thread.status = status;
      thread.updatedAt = new Date();
      this.saveToStorage();
      this.notifyListeners();
      return true;
    }
    return false;
  }

  /**
   * Mark messages as read
   */
  public markMessagesAsRead(threadId: string, userId: string): void {
    this.messages
      .filter(m => m.threadId === threadId && m.senderId !== userId)
      .forEach(m => m.isRead = true);

    const thread = this.threads.find(t => t.id === threadId);
    if (thread) {
      thread.unreadCount = 0;
    }

    this.saveToStorage();
    this.notifyListeners();
  }

  /**
   * Get unread count for admin
   */
  public getAdminUnreadCount(): number {
    return this.threads.reduce((total, thread) => total + thread.unreadCount, 0);
  }

  /**
   * Get unread count for client
   */
  public getClientUnreadCount(clientId: string): number {
    return this.threads
      .filter(t => t.clientId === clientId)
      .reduce((total, thread) => total + thread.unreadCount, 0);
  }

  /**
   * Subscribe to thread updates
   */
  public subscribeToThreads(callback: (threads: ChatThread[]) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  /**
   * Subscribe to message updates for a specific thread
   */
  public subscribeToMessages(threadId: string, callback: (messages: ChatMessage[]) => void): () => void {
    const messageCallback = (messages: ChatMessage[], msgThreadId: string) => {
      if (msgThreadId === threadId) {
        callback(messages);
      }
    };
    
    this.messageListeners.push(messageCallback);
    return () => {
      this.messageListeners = this.messageListeners.filter(l => l !== messageCallback);
    };
  }

  /**
   * Notify thread listeners
   */
  private notifyListeners(): void {
    this.listeners.forEach(callback => callback([...this.threads]));
  }

  /**
   * Notify message listeners
   */
  private notifyMessageListeners(threadId: string): void {
    const threadMessages = this.getThreadMessages(threadId);
    this.messageListeners.forEach(callback => callback(threadMessages, threadId));
  }

  /**
   * Trigger real-time update for all connected clients
   */
  private triggerRealTimeUpdate(threadId: string, message: ChatMessage) {
    // Simulate real-time update by triggering a custom event
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('chatMessageUpdate', {
        detail: { threadId, message }
      }));
    }
  }

  /**
   * Clear all chat data (for user deletion/checkout)
   */
  public clearAllData(): void {
    this.threads = [];
    this.messages = [];
    this.saveToStorage();
    this.notifyListeners();
  }

  /**
   * Simulate real-time updates (in a real app, this would be WebSocket)
   */
  public startRealTimeUpdates(): void {
    // Simulate periodic updates
    setInterval(() => {
      this.notifyListeners();
    }, 2000);
  }
}

export default ChatService;