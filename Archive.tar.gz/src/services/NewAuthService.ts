/**
 * New Authentication Service - Robust & Reliable
 * 
 * This service provides a comprehensive authentication system for the Thika Mains Hostels
 * application. It handles user registration, login, password management, and session
 * control with robust error handling and security measures.
 * 
 * Key Features:
 * - Secure password hashing with bcrypt
 * - Comprehensive user validation and error handling
 * - Session management with automatic restoration
 * - Financial validation for checkout and account deletion
 * - Admin user management and promotion system
 * - Preview mode for unauthenticated users
 * - Complete data clearing on account deletion/checkout
 */

import LocalStorageService, { DBUser } from './LocalStorageService';
import FinancialService from './FinancialService';
import ChatService from './ChatService';
import { navigateToSignin } from '@/utils/navigation';
import bcrypt from 'bcryptjs';

// User interface for the application (simplified from database user)
export interface AppUser {
  id: string;
  username: string;
  email: string;
  phone: string;
  profileImage: string;
  isActive: boolean;
  isAdmin: boolean;
  isPreview: boolean;
  isPermanent: boolean;
  hasFullAccess?: boolean; // Grants full access to all app services
  hasFreeHousing?: boolean; // Special privilege for free housing (soni-q only)
  selectedPlan: string;
  createdAt: string;
  lastLoginAt?: string;
  settings: {
    theme: 'light' | 'dark' | 'system';
    notifications: boolean;
    language: string;
  };
  // Additional properties for compatibility
  paymentMethod?: string;
  lastPaymentDate?: string;
  paymentHistory?: Array<{ id: string; plan: string; amount: string; date: string }>;
  bookingMonths?: number;
  pendingCheckout?: boolean;
  pendingDeletion?: boolean;
}

// Authentication result interface
export interface AuthResult {
  success: boolean;
  user?: AppUser;
  error?: string;
  message?: string;
}

// Registration data interface
export interface RegistrationData {
  username: string;
  email: string;
  phone: string;
  password: string;
  profileImage?: string;
}

/**
 * New Authentication Service Class
 * 
 * Provides a clean, reliable interface for all authentication operations.
 * Uses IndexedDB for persistence and includes comprehensive error handling.
 */
class NewAuthService {
  private static instance: NewAuthService;
  private dbService: LocalStorageService;
  private financialService: FinancialService;
  private currentUser: AppUser | null = null;
  private isInitialized = false;

  private constructor() {
    this.dbService = LocalStorageService.getInstance();
    this.financialService = FinancialService.getInstance();
  }

  /**
   * Get the singleton instance of NewAuthService
   * Ensures consistent authentication state across the app
   */
  public static getInstance(): NewAuthService {
    if (!NewAuthService.instance) {
      NewAuthService.instance = new NewAuthService();
    }
    return NewAuthService.instance;
  }

  /**
   * Initialize the authentication service (synchronous for instant performance)
   * Must be called before using any other methods
   */
  public initialize(): void {
    if (this.isInitialized) {
      return;
    }

    this.dbService.initialize();
    this.restoreSession();
    this.isInitialized = true;
  }

  /**
   * Restore user session from localStorage
   * Validates the session and updates user data if needed
   */
  private async restoreSession(): Promise<void> {
    try {
      const savedSession = localStorage.getItem('currentUser');
      if (!savedSession) {
        return;
      }

      const sessionData = JSON.parse(savedSession);

      // Check if it's a preview user
      if (sessionData.isPreview) {
        this.currentUser = sessionData;
        return;
      }

      // Validate the session by checking if user still exists in database
      const dbUser = await this.dbService.getUserByUsername(sessionData.username);
      if (dbUser && dbUser.isActive) {
        this.currentUser = this.convertDBUserToAppUser(dbUser);
        console.log('Session restored successfully');
      } else {
        console.log('Session invalid, clearing...');
        localStorage.removeItem('currentUser');
        this.currentUser = null;
      }
    } catch (error) {
      console.error('Error restoring session:', error);
      localStorage.removeItem('currentUser');
      this.currentUser = null;
    }
  }

  /**
   * Convert database user to application user
   * Removes sensitive data and formats for app use
   */
  private convertDBUserToAppUser(dbUser: DBUser): AppUser {
    return {
      id: dbUser.id,
      username: dbUser.username,
      email: dbUser.email,
      phone: dbUser.phone,
      profileImage: dbUser.profileImage || '/images/default-profile.svg',
      isActive: dbUser.isActive,
      isAdmin: dbUser.isAdmin,
      isPreview: dbUser.isPreview,
      isPermanent: dbUser.isPermanent,
      hasFullAccess: dbUser.hasFullAccess,
      hasFreeHousing: dbUser.hasFreeHousing,
      selectedPlan: dbUser.selectedPlan,
      createdAt: dbUser.createdAt,
      lastLoginAt: dbUser.lastLoginAt,
      settings: dbUser.settings
    };
  }

  /**
   * Authenticate a user with login credentials
   * Supports username, email, or phone number as login field
   * Provides detailed error messages and suggestions
   */
  public async login(loginField: string, password: string): Promise<AuthResult> {
    try {
      if (!this.isInitialized) {
        this.initialize();
      }

      if (!loginField || !password) {
        return {
          success: false,
          error: 'Username and password are required'
        };
      }

      const authResult = await this.dbService.authenticateUser(loginField.trim(), password);
      
      // Authentication failed
      if (!authResult.success) {
        return {
          success: false,
          error: authResult.error || 'Authentication failed',
          message: authResult.suggestion
        };
      }

      const dbUser = authResult.user!;

      // Check if account is active
      if (!dbUser.isActive) {
        return {
          success: false,
          error: 'Account is deactivated. Please contact support.'
        };
      }

      // Successful login
      this.currentUser = this.convertDBUserToAppUser(dbUser);
      localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
      
      return {
        success: true,
        user: this.currentUser,
        message: 'Login successful'
      };

    } catch (error) {
      return {
        success: false,
        error: 'Login failed. Please try again.'
      };
    }
  }

  /**
   * Register a new user
   * Validates input and creates user in database
   */
  public async register(userData: RegistrationData): Promise<AuthResult> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      const validation = this.validateRegistrationData(userData);
      if (!validation.isValid) {
        return {
          success: false,
          error: validation.error
        };
      }

      const dbUser = await this.dbService.createUser({
        username: userData.username.trim(),
        email: userData.email.trim().toLowerCase(),
        phone: userData.phone.trim(),
        password: userData.password,
        profileImage: userData.profileImage
      });

      const appUser = this.convertDBUserToAppUser(dbUser);
      
      return {
        success: true,
        user: appUser,
        message: 'Registration successful'
      };

    } catch (error) {
      let errorMessage = 'Registration failed. Please try again.';
      if (error instanceof Error) {
        if (error.message.includes('Username already exists')) {
          errorMessage = 'Username is already taken. Please choose a different username.';
        } else if (error.message.includes('Email already exists')) {
          errorMessage = 'Email is already registered. Please use a different email or sign in.';
        } else if (error.message.includes('Phone number already exists')) {
          errorMessage = 'Phone number is already registered. Please use a different phone number.';
        } else {
          errorMessage = `Registration failed: ${error.message}`;
        }
      }
      
      return {
        success: false,
        error: errorMessage
      };
    }
  }

  /**
   * Validate registration data
   * Checks all required fields and formats
   */
  private validateRegistrationData(userData: RegistrationData): { isValid: boolean; error?: string } {
    // Check required fields
    if (!userData.username || !userData.email || !userData.phone || !userData.password) {
      return { isValid: false, error: 'All fields are required' };
    }

    // Validate username
    if (userData.username.length < 3) {
      return { isValid: false, error: 'Username must be at least 3 characters long' };
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(userData.username)) {
      return { isValid: false, error: 'Username can only contain letters, numbers, underscores, and hyphens' };
    }

    // Check for reserved usernames
    const reservedUsernames = ['makopolo', 'soni-q', 'admin', 'administrator', 'root', 'system'];
    if (reservedUsernames.includes(userData.username.toLowerCase())) {
      return { isValid: false, error: 'This username is reserved. Please choose a different username.' };
    }

    // Validate email
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(userData.email)) {
      return { isValid: false, error: 'Please enter a valid email address' };
    }

    // Check for reserved emails
    const reservedEmails = ['makopolo@gmail.com', 'soni-q@gmail.com'];
    if (reservedEmails.includes(userData.email.toLowerCase())) {
      return { isValid: false, error: 'This email is reserved. Please use a different email address.' };
    }

    // Validate phone
    const phoneRegex = /^[0-9+\-\s()]{10,}$/;
    if (!phoneRegex.test(userData.phone)) {
      return { isValid: false, error: 'Please enter a valid phone number (at least 10 digits)' };
    }

    // Check for reserved phone numbers
    const reservedPhones = ['0712345678', '0712345679'];
    if (reservedPhones.includes(userData.phone.replace(/\D/g, ''))) {
      return { isValid: false, error: 'This phone number is reserved. Please use a different phone number.' };
    }

    // Validate password strength
    if (userData.password.length < 6) {
      return { isValid: false, error: 'Password must be at least 6 characters long' };
    }
    if (!/[A-Z]/.test(userData.password)) {
      return { isValid: false, error: 'Password must contain at least one uppercase letter' };
    }
    if (!/[a-z]/.test(userData.password)) {
      return { isValid: false, error: 'Password must contain at least one lowercase letter' };
    }
    if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(userData.password)) {
      return { isValid: false, error: 'Password must contain at least one special character' };
    }

    return { isValid: true };
  }


  /**
   * Get the current authenticated user
   * Returns null if no user is logged in
   */
  public getCurrentUser(): AppUser | null {
    return this.currentUser;
  }

  /**
   * Check if a user is currently authenticated
   * Returns true if user is logged in and active
   */
  public isAuthenticated(): boolean {
    return this.currentUser !== null && this.currentUser.isActive;
  }

  /**
   * Check if the current user is an admin
   * Returns true if user is logged in and has admin privileges
   */
  public isAdmin(): boolean {
    return this.isAuthenticated() && this.currentUser!.isAdmin;
  }

  /**
   * Check if the current user is in preview mode
   * Preview users have limited functionality
   */
  public isPreview(): boolean {
    return this.currentUser !== null && this.currentUser.isPreview;
  }

  /**
   * Login as preview user (for testing/demo purposes)
   * Creates a temporary user session without database storage
   */
  public loginAsPreview(userData: Partial<AppUser>): void {
    console.log(' Creating preview session');
    
    this.currentUser = {
      id: 'preview-' + Date.now(),
      username: userData.username || 'Preview User',
      email: userData.email || 'preview@example.com',
      phone: userData.phone || '0000000000',
      profileImage: userData.profileImage || '/images/default-profile.svg',
      isActive: true,
      isAdmin: false,
      isPreview: true,
      isPermanent: false,
      selectedPlan: 'single',
      createdAt: new Date().toISOString(),
      settings: {
        theme: 'system',
        notifications: true,
        language: 'en'
      }
    };

    // Save preview session (but mark it as preview)
    localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
    
    console.log(' Preview session created');
  }

  /**
   * Get all users (admin only)
   * Returns list of all registered users
   */
  public async getAllUsers(): Promise<AppUser[]> {
    try {
      if (!this.isAdmin()) {
        throw new Error('Admin access required');
      }

      const dbUsers = await this.dbService.getAllUsers();
      return dbUsers.map(dbUser => this.convertDBUserToAppUser(dbUser));
    } catch (error) {
      console.error(' Error getting all users:', error);
      return [];
    }
  }

  /**
   * Reset/clear all data (admin only, for testing)
   * USE WITH EXTREME CAUTION - This deletes everything!
   */
  public async resetAllData(): Promise<void> {
    try {
      if (!this.isAdmin()) {
        throw new Error('Admin access required');
      }

      console.log(' Resetting all authentication data...');
      
      // Clear database
      await this.dbService.clearAllData();
      
      // Clear current session
      this.currentUser = null;
      localStorage.removeItem('currentUser');
      
      // Reinitialize with default users
      await this.dbService.initialize();
      
      console.log(' All data reset successfully');
    } catch (error) {
      console.error(' Error resetting data:', error);
      throw error;
    }
  }

  /**
   * Get authentication statistics (admin only)
   * Returns useful stats about the authentication system
   */
  public async getAuthStats(): Promise<{ totalUsers: number; activeUsers: number; adminUsers: number; previewUsers: number }> {
    try {
      if (!this.isAdmin()) {
        throw new Error('Admin access required');
      }

      const allUsers = await this.dbService.getAllUsers();
      
      return {
        totalUsers: allUsers.length,
        activeUsers: allUsers.filter(u => u.isActive).length,
        adminUsers: allUsers.filter(u => u.isAdmin).length,
        previewUsers: allUsers.filter(u => u.isPreview).length
      };
    } catch (error) {
      console.error(' Error getting auth stats:', error);
      return { totalUsers: 0, activeUsers: 0, adminUsers: 0, previewUsers: 0 };
    }
  }

  /**
   * Promote a user to admin (admin only)
   * @param userId - ID of user to promote
   * @returns Promise<boolean> - Success status
   */
  async promoteUserToAdmin(userId: string): Promise<boolean> {
    try {
      if (!this.currentUser?.isAdmin) {
        console.log('Only admins can promote users');
        return false;
      }

      // Get user details to check if it's soni-q
      const userToPromote = await this.dbService.getUser(userId);
      if (!userToPromote) {
        console.log('User not found for promotion');
        return false;
      }

      // Prevent soni-q from being promoted to admin
      if (userToPromote.username === 'soni-q' || userToPromote.email === 'soni-q@gmail.com') {
        console.log('soni-q cannot be promoted to admin - reserved for impersonation only');
        return false;
      }
      
      return await this.dbService.promoteUserToAdmin(userId, this.currentUser.id);
    } catch (error) {
      console.error('Error promoting user to admin:', error);
      return false;
    }
  }

  /**
   * Demote an admin to regular user (admin only)
   * @param userId - ID of admin to demote
   * @returns Promise<boolean> - Success status
   */
  async demoteAdminToUser(userId: string): Promise<boolean> {
    try {
      if (!this.currentUser?.isAdmin || this.currentUser.username !== 'makopolo') {
        console.log('Only makopolo can demote other admins');
        return false;
      }
      
      return await this.dbService.demoteAdminToUser(userId, this.currentUser.id);
    } catch (error) {
      console.error('Error demoting admin to user:', error);
      return false;
    }
  }

  /**
   * Clear all non-permanent users (admin only)
   * @returns Promise<boolean> - Success status
   */
  async clearNonPermanentUsers(): Promise<boolean> {
    try {
      if (!this.currentUser?.isAdmin) {
        console.log('Only admins can clear non-permanent users');
        return false;
      }
      
      return await this.dbService.clearNonPermanentUsers();
    } catch (error) {
      console.error('Error clearing non-permanent users:', error);
      return false;
    }
  }

  /**
   * Logout the current user
   * Special case: soni-q can logout even though they're permanent
   * Other permanent users (admins) cannot logout
   * After logout, user becomes preview user with restrictions
   */
  public async logout(): Promise<void> {
    try {
      if (!this.currentUser) {
        console.log('No user to logout');
        return;
      }

      // Special case: soni-q can logout even though they're permanent
      if (this.currentUser.isPermanent && this.currentUser.username !== 'soni-q') {
        console.log('Permanent users (except soni-q) cannot be logged out');
        return;
      }

      // Admins cannot logout (except soni-q)
      if (this.currentUser.isAdmin && this.currentUser.username !== 'soni-q') {
        console.log('Admin users cannot be logged out');
        return;
      }

      // Clear current user and session
      this.currentUser = null;
      localStorage.removeItem('currentUser');
      
      // Clear session storage
      sessionStorage.clear();
      
      // Clear all application data
      localStorage.removeItem('authToken');
      localStorage.removeItem('userSession');
      localStorage.removeItem('theme');
      localStorage.removeItem('preferences');
      
      // Redirect to signin page after logout
      navigateToSignin();
      
      console.log('Logout successful - redirecting to signin');
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  /**
   * Reset password for a user (forgot password functionality)
   * @param loginField - Username, email, or phone number
   * @param newPassword - New password
   * @returns Promise<AuthResult> - Success status
   */
  public async resetPassword(loginField: string, newPassword: string): Promise<AuthResult> {
    try {
      console.log(`Resetting password for: ${loginField}`);

      // Ensure service is initialized
      if (!this.isInitialized) {
        await this.initialize();
      }

      // Validate input
      if (!loginField || !newPassword) {
        return {
          success: false,
          error: 'Login field and new password are required'
        };
      }

      // Validate password strength
      const passwordValidation = this.validatePassword(newPassword);
      if (!passwordValidation.isValid) {
        return {
          success: false,
          error: passwordValidation.error
        };
      }

      // Find user by username, email, or phone
      let user = await this.dbService.getUserByUsername(loginField);
      if (!user) {
        user = await this.dbService.getUserByEmail(loginField);
      }
      if (!user) {
        user = await this.dbService.getUserByPhone(loginField);
      }

      if (!user) {
        return {
          success: false,
          error: 'User not found'
        };
      }

      // Update password
      user.passwordHash = await bcrypt.hash(newPassword, 12);
      user.updatedAt = new Date().toISOString();
      
      const success = await this.dbService.updateUser(user);
      
      if (success) {
        console.log(`Password reset successful for: ${user.username}`);
        
        return {
          success: true,
          message: 'Password reset successfully'
        };
      } else {
        return {
          success: false,
          error: 'Failed to update password'
        };
      }

    } catch (error) {
      console.error('Password reset error:', error);
      return {
        success: false,
        error: 'Password reset failed. Please try again.'
      };
    }
  }

  /**
   * Change password for current user
   * @param currentPassword - Current password
   * @param newPassword - New password
   * @returns Promise<AuthResult> - Success status
   */
  public async changePassword(currentPassword: string, newPassword: string): Promise<AuthResult> {
    try {
      if (!this.currentUser) {
        return {
          success: false,
          error: 'No user logged in'
        };
      }

      console.log(`Changing password for: ${this.currentUser.username}`);

      // Validate new password strength
      const passwordValidation = this.validatePassword(newPassword);
      if (!passwordValidation.isValid) {
        return {
          success: false,
          error: passwordValidation.error
        };
      }

      // Get current user from database
      const user = await this.dbService.getUser(this.currentUser.id);
      if (!user) {
        return {
          success: false,
          error: 'User not found'
        };
      }

      // Verify current password
      const passwordValid = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!passwordValid) {
        return {
          success: false,
          error: 'Current password is incorrect'
        };
      }

      // Update password
      user.passwordHash = await bcrypt.hash(newPassword, 12);
      user.updatedAt = new Date().toISOString();
      
      const success = await this.dbService.updateUser(user);
      
      if (success) {
        console.log(`Password changed successfully for: ${user.username}`);
        
        return {
          success: true,
          message: 'Password changed successfully'
        };
      } else {
        return {
          success: false,
          error: 'Failed to update password'
        };
      }

    } catch (error) {
      console.error('Change password error:', error);
      return {
        success: false,
        error: 'Password change failed. Please try again.'
      };
    }
  }

  /**
   * Validate password strength
   * @param password - Password to validate
   * @returns Validation result
   */
  private validatePassword(password: string): { isValid: boolean; error?: string } {
    if (password.length < 6) {
      return { isValid: false, error: 'Password must be at least 6 characters long' };
    }
    if (!/[A-Z]/.test(password)) {
      return { isValid: false, error: 'Password must contain at least one uppercase letter' };
    }
    if (!/[a-z]/.test(password)) {
      return { isValid: false, error: 'Password must contain at least one lowercase letter' };
    }
    if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
      return { isValid: false, error: 'Password must contain at least one special character' };
    }
    return { isValid: true };
  }

  /**
   * Delete a user account and all related data
   * @param userId - The ID of the user to delete
   * @returns Promise<boolean> - Success status
   */
  async deleteUserAccount(userId: string): Promise<boolean> {
    try {
      // Prevent deletion of admin and permanent users
      const user = await this.dbService.getUser(userId);
      if (!user) {
        console.log('User not found for deletion');
        return false;
      }

      if (user.isAdmin || user.isPermanent) {
        console.log('Cannot delete admin or permanent user');
        return false;
      }

      // Delete user and all related data
      const success = await this.dbService.deleteUser(userId);
      
      if (success) {
        console.log(`User account ${userId} deleted successfully`);
        // If the deleted user is the current user, logout
        if (this.currentUser?.id === userId) {
          await this.logout();
        }
      }

      return success;
    } catch (error) {
      console.error('Error deleting user account:', error);
      return false;
    }
  }

  /**
   * Delete user by username (for admin use)
   * @param username - Username to delete
   * @returns Promise<boolean> - Success status
   */
  async deleteUserByUsername(username: string): Promise<boolean> {
    try {
      return await this.dbService.deleteUserByUsername(username);
    } catch (error) {
      console.error('Error deleting user by username:', error);
      return false;
    }
  }

  /**
   * Delete user by email (for admin use)
   * @param email - Email to delete
   * @returns Promise<boolean> - Success status
   */
  async deleteUserByEmail(email: string): Promise<boolean> {
    try {
      return await this.dbService.deleteUserByEmail(email);
    } catch (error) {
      console.error('Error deleting user by email:', error);
      return false;
    }
  }

  /**
   * Delete user by phone (for admin use)
   * @param phone - Phone number to delete
   * @returns Promise<boolean> - Success status
   */
  async deleteUserByPhone(phone: string): Promise<boolean> {
    try {
      return await this.dbService.deleteUserByPhone(phone);
    } catch (error) {
      console.error('Error deleting user by phone:', error);
      return false;
    }
  }


  /**
   * Dismiss admin to regular user (only makopolo can do this)
   * @param userId - ID of admin to dismiss
   * @returns Promise<boolean> - Success status
   */
  async dismissAdminToUser(userId: string): Promise<boolean> {
    try {
      if (!this.currentUser?.isAdmin || this.currentUser.username !== 'makopolo') {
        console.log('Only makopolo can dismiss other admins');
        return false;
      }
      
      return await this.dbService.demoteAdminToUser(userId, this.currentUser.id);
    } catch (error) {
      console.error('Error dismissing admin to user:', error);
      return false;
    }
  }

  /**
   * Validate checkout/deletion with financial checks
   * @returns Promise<checkout validation result>
   */
  async validateCheckout(): Promise<{
    canCheckout: boolean;
    debt: number;
    credit: number;
    netAmount: number;
    message: string;
    requiresPayment: boolean;
    refundAmount: number;
  }> {
    try {
      if (!this.currentUser) {
        return {
          canCheckout: false,
          debt: 0,
          credit: 0,
          netAmount: 0,
          message: 'No user logged in',
          requiresPayment: false,
          refundAmount: 0
        };
      }

      return await this.financialService.validateCheckout(this.currentUser.id);
    } catch (error) {
      console.error('Error validating checkout:', error);
      return {
        canCheckout: false,
        debt: 0,
        credit: 0,
        netAmount: 0,
        message: 'Error validating checkout',
        requiresPayment: false,
        refundAmount: 0
      };
    }
  }

  /**
   * Process checkout with financial validation
   * @param paymentMethod - Payment method for refunds
   * @returns Promise<boolean> - Success status
   */
  async processCheckout(paymentMethod: string): Promise<boolean> {
    try {
      if (!this.currentUser) {
        return false;
      }

      const validation = await this.validateCheckout();
      
      if (!validation.canCheckout) {
        console.log('Checkout validation failed:', validation.message);
        return false;
      }

      // Process refund if there's credit
      if (validation.refundAmount > 0) {
        await this.financialService.processRefund(
          this.currentUser.id, 
          validation.refundAmount, 
          paymentMethod
        );
      }

      // Clear all user data from system
      await this.clearAllUserData(this.currentUser.id);
      
      // Terminate session and clear history
      await this.terminateSession();
      
      console.log('Checkout processed successfully - all data cleared');
      return true;
    } catch (error) {
      console.error('Error processing checkout:', error);
      return false;
    }
  }

  /**
   * Process account deletion with financial validation
   * @param paymentMethod - Payment method for refunds
   * @returns Promise<boolean> - Success status
   */
  async processAccountDeletion(paymentMethod: string): Promise<boolean> {
    try {
      if (!this.currentUser) {
        return false;
      }

      // Prevent deletion of permanent users
      if (this.currentUser.isPermanent) {
        console.log('Cannot delete permanent user');
        return false;
      }

      const validation = await this.validateCheckout();
      
      if (!validation.canCheckout) {
        console.log('Account deletion validation failed:', validation.message);
        return false;
      }

      // Process refund if there's credit
      if (validation.refundAmount > 0) {
        await this.financialService.processRefund(
          this.currentUser.id, 
          validation.refundAmount, 
          paymentMethod
        );
      }

      // Clear all user data from system
      await this.clearAllUserData(this.currentUser.id);
      
      // Terminate session and clear history
      await this.terminateSession();
      
      console.log('Account deletion processed successfully - all data cleared');
      return true;
    } catch (error) {
      console.error('Error processing account deletion:', error);
      return false;
    }
  }

  /**
   * Calculate plan change financial adjustment
   * @param currentPlan - Current plan type
   * @param newPlan - New plan type
   * @param roomPrices - Room prices object
   * @param daysRemaining - Days remaining in current billing cycle
   * @returns Plan change calculation
   */
  async calculatePlanChange(
    currentPlan: string,
    newPlan: string,
    roomPrices: { single: number; double: number; suite: number },
    daysRemaining: number = 30
  ) {
    return this.financialService.calculatePlanChange(
      currentPlan, 
      newPlan, 
      roomPrices, 
      daysRemaining
    );
  }

  /**
   * Calculate multi-month booking
   * @param roomPrice - Monthly room price
   * @param months - Number of months to book
   * @returns Multi-month booking calculation
   */
  async calculateMultiMonthBooking(roomPrice: number, months: number) {
    return this.financialService.calculateMultiMonthBooking(roomPrice, months);
  }

  /**
   * Clear all user data from the system
   * @param userId - ID of user to clear data for
   */
  private async clearAllUserData(userId: string): Promise<void> {
    try {
      // Clear financial records
      await this.financialService.clearUserFinancialRecords(userId);
      
      // Clear user from database
      await this.dbService.deleteUser(userId);
      
      // Clear chat conversations
      const chatService = ChatService.getInstance();
      chatService.clearAllData();
      
      // Clear any other user-specific data
      const userKeys = Object.keys(localStorage).filter(key => 
        key.includes(userId) || 
        key.includes('booking') || 
        key.includes('payment') ||
        key.includes('profile')
      );
      
      userKeys.forEach(key => {
        localStorage.removeItem(key);
      });
      
      console.log('All user data cleared from system');
    } catch (error) {
      console.error('Error clearing user data:', error);
    }
  }

  /**
   * Terminate current session and clear browser history
   */
  private async terminateSession(): Promise<void> {
    try {
      // Clear current user session
      this.currentUser = null;
      localStorage.removeItem('currentUser');
      
      // Clear session storage
      sessionStorage.clear();
      
      // Clear all application data
      localStorage.removeItem('authToken');
      localStorage.removeItem('userSession');
      localStorage.removeItem('theme');
      localStorage.removeItem('preferences');
      
        // Force reload to clear all state
        navigateToSignin();
      // Clear browser history and redirect to sign-in
      if (typeof window !== 'undefined') {
        // Clear browser history
        window.history.replaceState(null, '', '/signin');
        
        // Force reload to clear all state
        navigateToSignin();
      }
      
      console.log('Session terminated and history cleared');
    } catch (error) {
      console.error('Error terminating session:', error);
    }
  }
}

export default NewAuthService;
