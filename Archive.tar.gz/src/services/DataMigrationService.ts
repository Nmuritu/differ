/**
 * Data Migration Service
 * 
 * Handles data migration and persistence across app updates
 * Ensures user data is preserved when the app is updated
 */

interface MigrationVersion {
  version: string;
  description: string;
  migrate: () => void;
}

class DataMigrationService {
  private static instance: DataMigrationService;
  private currentVersion = '1.0.0';
  private migrations: MigrationVersion[] = [];

  private constructor() {
    this.initializeMigrations();
  }

  public static getInstance(): DataMigrationService {
    if (!DataMigrationService.instance) {
      DataMigrationService.instance = new DataMigrationService();
    }
    return DataMigrationService.instance;
  }

  /**
   * Initialize migration definitions
   */
  private initializeMigrations(): void {
    this.migrations = [
      {
        version: '1.0.0',
        description: 'Initial data structure migration',
        migrate: () => {
          this.migrateToV1_0_0();
        }
      },
      {
        version: '1.1.0',
        description: 'Add user settings and preferences',
        migrate: () => {
          this.migrateToV1_1_0();
        }
      },
      {
        version: '1.2.0',
        description: 'Add chat and forum data',
        migrate: () => {
          this.migrateToV1_2_0();
        }
      }
    ];
  }

  /**
   * Run all pending migrations
   */
  public runMigrations(): void {
    const lastVersion = localStorage.getItem('appVersion') || '0.0.0';

    if (this.compareVersions(lastVersion, this.currentVersion) >= 0) {
      return;
    }

    
    for (const migration of this.migrations) {
      if (this.compareVersions(lastVersion, migration.version) < 0) {
        try {
          migration.migrate();
        } catch (error) {
          console.error(`Migration ${migration.version} failed:`, error);
        }
      }
    }

    // Update version after successful migrations
    localStorage.setItem('appVersion', this.currentVersion);
  }

  /**
   * Compare two version strings
   * Returns: -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2
   */
  private compareVersions(v1: string, v2: string): number {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    
    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const part1 = parts1[i] || 0;
      const part2 = parts2[i] || 0;
      
      if (part1 < part2) return -1;
      if (part1 > part2) return 1;
    }
    
    return 0;
  }

  /**
   * Migration to version 1.0.0
   * Ensures basic data structure exists
   */
  private migrateToV1_0_0(): void {
    // Ensure users array exists
    if (!localStorage.getItem('users')) {
      localStorage.setItem('users', JSON.stringify([]));
    }

    // Ensure currentUser exists or create preview user
    if (!localStorage.getItem('currentUser')) {
      const previewUser = {
        id: 'preview-' + Date.now(),
        username: 'Preview User',
        email: 'preview@example.com',
        phone: '0000000000',
        profileImage: '/images/default-profile.svg',
        isActive: true,
        isAdmin: false,
        isPreview: true,
        isPermanent: false,
        selectedPlan: 'single',
        createdAt: new Date().toISOString(),
        settings: {
          theme: 'system',
          notifications: true,
          language: 'en'
        }
      };
      localStorage.setItem('currentUser', JSON.stringify(previewUser));
    }
  }

  /**
   * Migration to version 1.1.0
   * Adds user settings and preferences
   */
  private migrateToV1_1_0(): void {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      const user = JSON.parse(currentUser);
      if (!user.settings) {
        user.settings = {
          theme: 'system',
          notifications: true,
          language: 'en'
        };
        localStorage.setItem('currentUser', JSON.stringify(user));
      }
    }
  }

  /**
   * Migration to version 1.2.0
   * Adds chat and forum data structures
   */
  private migrateToV1_2_0(): void {
    // Ensure chat data exists
    if (!localStorage.getItem('chatThreads')) {
      localStorage.setItem('chatThreads', JSON.stringify([]));
    }
    if (!localStorage.getItem('chatMessages')) {
      localStorage.setItem('chatMessages', JSON.stringify([]));
    }

    // Ensure forum data exists
    if (!localStorage.getItem('forumQuestions')) {
      localStorage.setItem('forumQuestions', JSON.stringify([]));
    }
    if (!localStorage.getItem('forumAnswers')) {
      localStorage.setItem('forumAnswers', JSON.stringify([]));
    }
  }

  /**
   * Backup user data before migration
   */
  public backupUserData(): Record<string, unknown> {
    const backup = {
      users: localStorage.getItem('users'),
      currentUser: localStorage.getItem('currentUser'),
      chatThreads: localStorage.getItem('chatThreads'),
      chatMessages: localStorage.getItem('chatMessages'),
      forumQuestions: localStorage.getItem('forumQuestions'),
      forumAnswers: localStorage.getItem('forumAnswers'),
      appImages: localStorage.getItem('appImages'),
      timestamp: new Date().toISOString()
    };
    
    localStorage.setItem('userDataBackup', JSON.stringify(backup));
    return backup;
  }

  /**
   * Restore user data from backup
   */
  public restoreUserData(): boolean {
    try {
      const backup = localStorage.getItem('userDataBackup');
      if (!backup) {
        return false;
      }

      const backupData = JSON.parse(backup);
      
      // Restore all data
      Object.entries(backupData).forEach(([key, value]) => {
        if (key !== 'timestamp' && value) {
          localStorage.setItem(key, value as string);
        }
      });

      return true;
    } catch (error) {
      console.error('Error restoring user data:', error);
      return false;
    }
  }

  /**
   * Get data integrity status
   */
  public getDataIntegrityStatus(): {
    isHealthy: boolean;
    issues: string[];
    lastBackup: string | null;
  } {
    const issues: string[] = [];
    let isHealthy = true;

    // Check critical data
    if (!localStorage.getItem('users')) {
      issues.push('Users data missing');
      isHealthy = false;
    }

    if (!localStorage.getItem('currentUser')) {
      issues.push('Current user data missing');
      isHealthy = false;
    }

    // Check backup
    const backup = localStorage.getItem('userDataBackup');
    let lastBackup: string | null = null;
    if (backup) {
      try {
        const backupData = JSON.parse(backup);
        lastBackup = backupData.timestamp;
      } catch (error) {
        issues.push('Backup data corrupted');
        isHealthy = false;
      }
    }

    return {
      isHealthy,
      issues,
      lastBackup
    };
  }
}

export default DataMigrationService;
