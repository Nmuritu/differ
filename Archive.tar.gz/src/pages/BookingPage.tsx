import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CalendarIcon, User, Mail, Phone, CreditCard, ArrowLeft, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useRooms } from '@/contexts/RoomContext';
import { BookingDetails } from '@/types/booking';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/NewAuthContext';
import BookingService from '@/services/BookingService';

const bookingSchema = z.object({
  guestName: z.string().min(2, 'Name must be at least 2 characters').max(100, 'Name must be less than 100 characters'),
  email: z.string().email('Invalid email address').max(255, 'Email must be less than 255 characters'),
  phone: z.string().regex(/^(\+254|0)[1-9]\d{8}$/, 'Please enter a valid Kenyan phone number'),
  idNumber: z.string().min(7, 'ID number must be at least 7 characters').max(20, 'ID number must be less than 20 characters'),
  checkIn: z.date({
    required_error: 'Check-in date is required',
  }),
  checkOut: z.date({
    required_error: 'Check-out date is required',
  }),
}).refine(
  (data) => data.checkOut > data.checkIn,
  {
    message: 'Check-out date must be after check-in date',
    path: ['checkOut'],
  }
);

type BookingForm = z.infer<typeof bookingSchema>;

const BookingPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const { user, isPreview } = useAuth();
  const { rooms, getSelectedRoom, setSelectedRoom } = useRooms();
  const [selectedRoom, setSelectedRoomState] = useState<{ id: string; type: string; price: number; available: number } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const form = useForm<BookingForm>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      guestName: '',
      email: '',
      phone: '',
      idNumber: '',
    },
  });

  useEffect(() => {
    // Check if user is in preview mode
    if (isPreview) {
      setShowPreviewModal(true);
      return;
    }

    const roomId = searchParams.get('roomId');
    if (roomId) {
      // Set the selected room in context
      setSelectedRoom(roomId);
      const room = rooms.find(r => r.id === roomId);
      if (room && room.isAvailable) {
        setSelectedRoomState(room);
      } else {
        toast({
          title: 'Room Not Available',
          description: 'The selected room is no longer available.',
          variant: 'destructive',
        });
        navigate('/rooms');
      }
    } else {
      // Try to get room from context
      const contextRoom = getSelectedRoom();
      if (contextRoom) {
        setSelectedRoomState(contextRoom);
      } else {
        toast({
          title: 'No Room Selected',
          description: 'Please select a room first.',
          variant: 'destructive',
        });
        navigate('/rooms');
      }
    }
  }, [searchParams, navigate, toast, isPreview, rooms, getSelectedRoom, setSelectedRoom]);

  /**
   * Handle preview user action - redirect to registration
   */
  const handleCreateAccount = () => {
    setShowPreviewModal(false);
    navigate('/register');
  };

  /**
   * Handle preview modal close - redirect to rooms
   */
  const handleClosePreview = () => {
    setShowPreviewModal(false);
    navigate('/rooms');
  };

  const calculateTotal = (checkIn: Date, checkOut: Date) => {
    if (!selectedRoom || !checkIn || !checkOut) return 0;
    const days = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
    const months = Math.ceil(days / 30);
    return selectedRoom.price * months;
  };

  const onSubmit = async (data: BookingForm) => {
    if (!selectedRoom) {
      toast({
        title: 'No Room Selected',
        description: 'Please select a room first.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const bookingService = BookingService.getInstance();
      
      // Validate booking data
      const validation = bookingService.validateBooking({
        guestName: data.guestName,
        email: data.email,
        phone: data.phone,
        idNumber: data.idNumber,
        checkIn: data.checkIn,
        checkOut: data.checkOut,
        roomId: selectedRoom.id,
        totalAmount: calculateTotal(data.checkIn, data.checkOut)
      });

      if (!validation.isValid) {
        toast({
          title: 'Validation Error',
          description: validation.errors.join(', '),
          variant: 'destructive',
        });
        return;
      }

      // Create booking with proper ID generation
      const booking = await bookingService.createBooking({
        guestName: data.guestName,
        email: data.email,
        phone: data.phone,
        idNumber: data.idNumber,
        checkIn: data.checkIn,
        checkOut: data.checkOut,
        roomId: selectedRoom.id,
        totalAmount: calculateTotal(data.checkIn, data.checkOut),
        status: 'pending',
        paymentStatus: 'pending'
      });

      // Navigate to payment page with the generated booking ID
      navigate(`/payment?bookingId=${booking.id}`);

      toast({
        title: 'Booking Created Successfully',
        description: `Booking ID: ${booking.id}. Proceeding to payment...`,
      });
    } catch (error) {
      console.error('Booking creation error:', error);
      toast({
        title: 'Booking Failed',
        description: 'There was an error creating your booking. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClearForm = () => {
    // Reset the form to default values
    form.reset();
    
    // Show confirmation
  };

  if (!selectedRoom) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <p className="text-lg mb-4">No room selected</p>
            <Button onClick={() => navigate('/rooms')}>
              Select a Room
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const checkIn = form.watch('checkIn');
  const checkOut = form.watch('checkOut');
  const totalAmount = calculateTotal(checkIn, checkOut);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-6 sm:mb-8">
            <BackButton variant="both" size="sm" className="mb-4" />
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-2">Complete Your Booking</h1>
            <p className="text-sm sm:text-base lg:text-lg text-muted-foreground">
              Fill in your details to reserve your room
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {/* Booking Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Guest Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="guestName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="john@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="+254712345678" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="idNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ID Number</FormLabel>
                              <FormControl>
                                <Input placeholder="12345678" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="checkIn"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Check-in Date</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant="outline"
                                      className={cn(
                                        "pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    disabled={(date) => date < new Date()}
                                    initialFocus
                                    className="p-3 pointer-events-auto"
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="checkOut"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Check-out Date</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant="outline"
                                      className={cn(
                                        "pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    disabled={(date) => date <= (checkIn || new Date())}
                                    initialFocus
                                    className="p-3 pointer-events-auto"
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="space-y-3">
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={isSubmitting}
                          variant="hero"
                          size="lg"
                        >
                          {isSubmitting ? 'Processing...' : 'Proceed to Payment'}
                          <CreditCard className="ml-2 h-4 w-4" />
                        </Button>
                        <Button 
                          type="button" 
                          variant="secondary" 
                          className="w-full" 
                          onClick={handleClearForm}
                          disabled={isSubmitting}
                        >
                          Clear Form
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>

            {/* Booking Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg capitalize">
                      {selectedRoom.type} Room
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Room ID: {selectedRoom.id}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Price per month:</span>
                      <span>KSh {selectedRoom.price.toLocaleString()}</span>
                    </div>
                    {checkIn && checkOut && (
                      <>
                        <div className="flex justify-between">
                          <span>Duration:</span>
                          <span>
                            {Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))} days
                          </span>
                        </div>
                        <div className="border-t pt-2">
                          <div className="flex justify-between font-semibold text-lg">
                            <span>Total:</span>
                            <span className="text-primary">
                              KSh {totalAmount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="text-xs text-muted-foreground">
                    <p>• Payment is required to confirm booking</p>
                    <p>• Cancellation policy applies</p>
                    <p>• All prices include Wi-Fi and utilities</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Preview Mode Modal */}
      <Dialog open={showPreviewModal} onOpenChange={setShowPreviewModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              Create Account Required
            </DialogTitle>
            <DialogDescription>
              To book a room, you need to create a full account. Preview mode has limited access.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="h-5 w-5 text-yellow-600" />
                <h4 className="font-semibold text-yellow-800 dark:text-yellow-200">Preview Mode Active</h4>
              </div>
              <p className="text-sm text-yellow-700 dark:text-yellow-300 mb-3">
                You're currently in preview mode. To make bookings and access payment features, please create a full account.
              </p>
              <ul className="text-xs text-yellow-700 dark:text-yellow-300 space-y-1">
                <li>• Create a full account to book rooms</li>
                <li>• Access payment features</li>
                <li>• Save your preferences</li>
                <li>• Get booking confirmations</li>
              </ul>
            </div>
          </div>
          <DialogFooter className="flex gap-2">
            <Button variant="outline" onClick={handleClosePreview}>
              Back to Rooms
            </Button>
            <Button onClick={handleCreateAccount} className="w-full">
              Create Full Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BookingPage;