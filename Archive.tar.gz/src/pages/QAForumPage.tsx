import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MessageSquare, Users, HelpCircle } from 'lucide-react';
import { QAForum } from '@/components/ui/qa-forum';
import { useAuth } from '@/contexts/NewAuthContext';

/**
 * Q&A Forum Page Component
 * 
 * A dedicated page for the community-driven question and answer system.
 * Users can ask questions, search for answers, and help each other.
 * 
 * Features:
 * - Community-driven Q&A system
 * - Search and filtering capabilities
 * - Voting system for helpful answers
 * - Admin moderation and responses
 * - User reputation tracking
 */
const QAForumPage = () => {
  const { isAuthenticated, isPreview } = useAuth();

  // Redirect preview users to sign up
  if (isPreview) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md mx-auto text-center">
          <div className="mb-6">
            <MessageSquare className="h-16 w-16 text-primary mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">Community Forum Access Required</h1>
            <p className="text-muted-foreground">
              The Community Q&A Forum is only available to registered users. 
              Please create an account to participate in community discussions.
            </p>
          </div>
          <div className="space-y-3">
            <Button asChild className="w-full">
              <Link to="/register">Create Account</Link>
            </Button>
            <Button asChild variant="outline" className="w-full">
              <Link to="/signin">Sign In</Link>
            </Button>
            <Button asChild variant="ghost" className="w-full">
              <Link to="/help">View Support Options</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Button asChild variant="outline" size="sm">
              <Link to="/home">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Link>
            </Button>
          </div>
          <div className="flex items-center gap-3">
            <MessageSquare className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Community Q&A</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Ask questions, share knowledge, and help fellow users
          </p>
        </div>

        {/* Forum Component */}
        <QAForum />

        {/* Help Section */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <Users className="h-8 w-8 text-primary mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Community Help</h3>
            <p className="text-sm text-muted-foreground">
              Get help from other users who have faced similar issues
            </p>
          </div>
          
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <HelpCircle className="h-8 w-8 text-primary mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Quick Answers</h3>
            <p className="text-sm text-muted-foreground">
              Find instant answers to common questions and problems
            </p>
          </div>
          
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <MessageSquare className="h-8 w-8 text-primary mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Share Knowledge</h3>
            <p className="text-sm text-muted-foreground">
              Help others by answering questions and sharing tips
            </p>
          </div>
        </div>

        {/* Additional Help Options */}
        <div className="mt-8 p-6 bg-muted/30 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">Need More Help?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">For Quick Questions:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Try our AI Assistant for instant answers</li>
                <li>• Check the User Manual for detailed guides</li>
                <li>• Search existing questions in this forum</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">For Complex Issues:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Contact admin directly for urgent matters</li>
                <li>• Post detailed questions in this forum</li>
                <li>• Include screenshots and error messages</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QAForumPage;
