import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, User, Mail, Phone, Lock, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { PreviewModal } from '@/components/ui/preview-modal';
// Services are now handled through NewAuthContext
import { useBackNavigation } from '@/hooks/useBackNavigation';

const RegistrationPage = () => {
  const navigate = useNavigate();
  const { loginAsPreview, register } = useAuth();
  // Initialize form data from localStorage or empty values
  const [formData, setFormData] = useState(() => {
    const savedData = localStorage.getItem('registrationFormData');
    if (savedData) {
      try {
        return JSON.parse(savedData);
      } catch (error) {
        console.error('Error parsing saved form data:', error);
      }
    }
    return {
      username: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: ''
    };
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState({ score: 0, level: 'Very Weak', color: 'text-red-600', feedback: [] as string[] });

  // Track existing user suggestions
  const [existingUserSuggestion, setExistingUserSuggestion] = useState<'email' | 'username' | 'phone' | null>(null);

  // Save form data to localStorage whenever it changes
  useEffect(() => {
    // Only save if form has some data (not all empty)
    const hasData = Object.values(formData).some(value => (value as string).trim() !== '');
    if (hasData) {
      localStorage.setItem('registrationFormData', JSON.stringify(formData));
    }
  }, [formData]);

  const validateEmail = (email: string) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail|yahoo|proton)\.(com|org)$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string) => {
    const phoneRegex = /^\d{10,}$/;
    return phoneRegex.test(phone);
  };

  const validatePassword = (password: string) => {
    // Check minimum length
    if (password.length < 6) {
      return { isValid: false, message: 'Password must be at least 6 characters long' };
    }

    // Check for uppercase letter
    if (!/[A-Z]/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one uppercase letter (A-Z)' };
    }

    // Check for lowercase letter
    if (!/[a-z]/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one lowercase letter (a-z)' };
    }

    // Check for special character
    if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one special character (!@#$%^&*()_+-=[]{}|;:,.<>?)' };
    }

    return { isValid: true, message: '' };
  };

  const getPasswordStrength = (password: string) => {
    let strength = 0;
    const feedback = [];

    if (password.length >= 6) strength += 1;
    else feedback.push('At least 6 characters');

    if (/[A-Z]/.test(password)) strength += 1;
    else feedback.push('One uppercase letter');

    if (/[a-z]/.test(password)) strength += 1;
    else feedback.push('One lowercase letter');

    if (/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) strength += 1;
    else feedback.push('One special character');

    if (password.length >= 12) strength += 1;

    const strengthLevels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    const strengthColors = ['text-red-600', 'text-orange-600', 'text-yellow-600', 'text-blue-600', 'text-green-600'];
    
    return {
      score: strength,
      level: strengthLevels[Math.min(strength, 4)],
      color: strengthColors[Math.min(strength, 4)],
      feedback: feedback
    };
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: typeof formData) => ({ ...prev, [name]: value }));
    
    // Update password strength in real-time
    if (name === 'password') {
      setPasswordStrength(getPasswordStrength(value));
    }
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }

    // Clear existing user suggestion when user modifies the field
    if (existingUserSuggestion && (name === 'username' || name === 'email' || name === 'phone')) {
      setExistingUserSuggestion(null);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Username validation
    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.toLowerCase() === 'makopolo') {
      newErrors.username = 'This username is reserved for admin use. Please choose a different username.';
        }

    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please use Gmail, Yahoo, or Proton email';
    } else if (formData.email.toLowerCase() === 'makopolo@gmail.com') {
      newErrors.email = 'This email is reserved for admin use. Please use a different email.';
    } else if (formData.email.toLowerCase() === 'soni-q@gmail.com') {
      newErrors.email = 'This email is reserved for permanent user use. Please use a different email.';
        }

    // Phone validation
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Phone number must be at least 10 digits';
    } else if (formData.phone === '0712345678' || formData.phone === '0712345679') {
      newErrors.phone = 'This phone number is reserved. Please use a different phone number.';
        }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else {
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid) {
        newErrors.password = passwordValidation.message;
      }
    }

    // Confirm password validation
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePreview = () => {
    // Create a preview user with the current form data
    const previewUser = {
      id: 'preview-' + Date.now(),
      username: formData.username || 'Preview User',
      email: formData.email || 'preview@example.com',
      phone: formData.phone || '1234567890',
      password: 'preview',
      isPreview: true
    };

        loginAsPreview(previewUser);
    navigate('/home');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Create new user using the new authentication system
      const result = await register({
        username: formData.username,
        email: formData.email,
        phone: formData.phone,
        password: formData.password
      });

      if (result.success) {
        // Clear saved form data on successful registration
        localStorage.removeItem('registrationFormData');
        // Show success message and redirect
        alert('Registration successful! Please sign in with your credentials.');
        navigate('/signin');
      } else {
        setErrors({ general: result.error || 'Registration failed. Please try again.' });
      }
    } catch (error) {
      console.error('Registration error:', error);
      setErrors({ general: 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearForm = () => {
    // Clear all form data
    setFormData({
      username: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: ''
    });
    
    // Clear all errors
    setErrors({});
    
    // Clear existing user suggestions
    setExistingUserSuggestion(null);
    
    // Reset password strength
    setPasswordStrength({ score: 0, level: 'Very Weak', color: 'text-red-600', feedback: [] as string[] });
    
    // Clear saved form data from localStorage
    localStorage.removeItem('registrationFormData');
    
    // Show confirmation
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Button onClick={() => navigate('/signin')} variant="outline" size="sm" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Sign In
          </Button>
          <div className="text-center">
            <h1 className="text-3xl font-bold">Create Account</h1>
            <p className="text-muted-foreground mt-2">
              Join Thika Mains Hostels today
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-center">Sign Up</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {errors.general && (
                <Alert variant="destructive">
                  <AlertDescription>{errors.general}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="username"
                    name="username"
                    type="text"
                    placeholder="Enter unique username"
                    value={formData.username}
                    onChange={handleInputChange}
                    className={`pl-10 ${errors.username ? 'border-destructive' : ''}`}
                  />
                </div>
                {errors.username && (
                  <div className="space-y-2">
                    <p className="text-sm text-destructive">{errors.username}</p>
                    {existingUserSuggestion === 'username' && (
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                        <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
                          Already have an account? Sign in instead.
                        </p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => navigate('/signin')}
                          className="border-blue-300 text-blue-700 hover:bg-blue-100"
                        >
                          Go to Sign In
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={`pl-10 ${errors.email ? 'border-destructive' : ''}`}
                  />
                </div>
                {errors.email && (
                  <div className="space-y-2">
                    <p className="text-sm text-destructive">{errors.email}</p>
                    {existingUserSuggestion === 'email' && (
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                        <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
                          Already have an account? Sign in instead.
                        </p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => navigate('/signin')}
                          className="border-blue-300 text-blue-700 hover:bg-blue-100"
                        >
                          Go to Sign In
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="0712345678"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={`pl-10 ${errors.phone ? 'border-destructive' : ''}`}
                  />
                </div>
                {errors.phone && (
                  <div className="space-y-2">
                    <p className="text-sm text-destructive">{errors.phone}</p>
                    {existingUserSuggestion === 'phone' && (
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                        <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
                          Already have an account? Sign in instead.
                        </p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => navigate('/signin')}
                          className="border-blue-300 text-blue-700 hover:bg-blue-100"
                        >
                          Go to Sign In
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                
                {/* Password Manager Encouragement */}
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800 mb-3">
                  <p className="text-xs text-blue-800 dark:text-blue-200">
                    <strong> Pro Tip:</strong> Use a password manager like Bitwarden, 1Password, or LastPass to generate and store strong, unique passwords securely.
                  </p>
                </div>
                
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Must include: A-Z, a-z, special char, 6+ chars"
                    value={formData.password}
                    onChange={handleInputChange}
                    className={`pl-10 pr-10 ${errors.password ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 h-4 w-4 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                
                {/* Password Strength Indicator */}
                {formData.password && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Password Strength:</span>
                      <span className={`text-xs font-medium ${passwordStrength.color}`}>
                        {passwordStrength.level}
                      </span>
                    </div>
                    
                    {/* Strength Bar */}
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${
                          passwordStrength.score === 0 ? 'bg-red-500' :
                          passwordStrength.score === 1 ? 'bg-orange-500' :
                          passwordStrength.score === 2 ? 'bg-yellow-500' :
                          passwordStrength.score === 3 ? 'bg-blue-500' :
                          'bg-green-500'
                        }`}
                        style={{ width: `${(passwordStrength.score / 4) * 100}%` }}
                      ></div>
                    </div>
                    
                    {/* Requirements Checklist */}
                    {passwordStrength.feedback.length > 0 && (
                      <div className="text-xs text-muted-foreground">
                        <p className="mb-1">Missing requirements:</p>
                        <ul className="list-disc list-inside space-y-0.5">
                          {passwordStrength.feedback.map((item, index) => (
                            <li key={index}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
                
                {errors.password && (
                  <p className="text-sm text-destructive">{errors.password}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    className={`pl-10 pr-10 ${errors.confirmPassword ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-3 h-4 w-4 text-muted-foreground hover:text-foreground"
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-sm text-destructive">{errors.confirmPassword}</p>
                )}
              </div>

              <div className="space-y-3">
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Button>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" className="flex-1" onClick={handlePreview}>
                    Preview Account
                  </Button>
                  <Button 
                    type="button" 
                    variant="secondary" 
                    className="flex-1" 
                    onClick={handleClearForm}
                    disabled={isLoading}
                  >
                    Clear Form
                  </Button>
                </div>
              </div>
            </form>

            <div className="mt-6 space-y-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <h4 className="font-semibold mb-2 text-sm">Before joining our community:</h4>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• You'll need to upload a profile picture (max 2MB)</li>
                  <li>• Choose your room plan and payment method</li>
                  <li>• Download your payment receipt for records</li>
                  <li>• Access your user dashboard after registration</li>
                  <li>• Update your profile information anytime</li>
                </ul>
              </div>
              
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  Already have an account?{' '}
                  <Link to="/signin" className="text-primary hover:underline">
                    Sign in here
                  </Link>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegistrationPage;
