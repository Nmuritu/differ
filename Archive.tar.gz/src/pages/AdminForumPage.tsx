/**
 * Admin Forum Page
 * 
 * Admin interface for managing client conversations and support
 */

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { BackButton } from '@/components/ui/back-button';
import { useAuth } from '@/contexts/NewAuthContext';
import ChatForum from '@/components/ChatForum';

const AdminForumPage = () => {
  const { isAuthenticated, isAdmin } = useAuth();
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);

  // Redirect non-admin users
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md p-6 text-center">
          <h1 className="text-2xl font-bold mb-4">Admin Access Required</h1>
          <p className="text-muted-foreground mb-6">
            Only administrators can access this page.
          </p>
          <BackButton />
        </Card>
      </div>
    );
  }

  // Redirect non-authenticated users
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md p-6 text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Required</h1>
          <p className="text-muted-foreground mb-6">
            Please sign in to access the admin forum.
          </p>
          <BackButton />
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <BackButton />
        </div>
        
        <Card className="h-[700px]">
          <ChatForum 
            isAdmin={true}
            selectedConversationId={selectedConversationId}
            onConversationSelect={setSelectedConversationId}
          />
        </Card>
      </div>
    </div>
  );
};

export default AdminForumPage;