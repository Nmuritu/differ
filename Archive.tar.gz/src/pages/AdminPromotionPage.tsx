/**
 * Admin Promotion/Demotion Page
 * 
 * This page is only accessible to makopolo (main admin) and allows
 * promotion and demotion of users to/from admin status. It shows
 * usernames, emails, and phone numbers of eligible users.
 * 
 * Features:
 * - Only accessible to makopolo
 * - Shows all users except soni-q and makopolo
 * - Real-time updates when users are promoted/demoted
 * - Admin contact info becomes visible to regular users
 * - Dynamic user list with current admin status
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Users, 
  Shield, 
  UserPlus, 
  UserMinus, 
  Search,
  Mail,
  Phone,
  User,
  Crown,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import NewAuthService from '@/services/NewAuthService';

interface UserForPromotion {
  id: string;
  username: string;
  email: string;
  phone: string;
  isAdmin: boolean;
  isPermanent: boolean;
  createdAt: string;
  lastLoginAt?: string;
}

const AdminPromotionPage = () => {
  const { user, isAuthenticated } = useAuth();
  const [users, setUsers] = useState<UserForPromotion[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserForPromotion[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [message, setMessage] = useState<{type: 'success' | 'error' | 'info', text: string} | null>(null);

  const authService = NewAuthService.getInstance();

  // Check if current user is makopolo
  const isMakopolo = user?.username === 'makopolo' && user?.isAdmin;

  // Load users on component mount and set up real-time updates
  useEffect(() => {
    loadUsers();
    
    // Set up real-time updates every 5 seconds
    const interval = setInterval(() => {
      loadUsers();
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  // Filter users based on search term
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(user => 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.phone.includes(searchTerm)
      );
      setFilteredUsers(filtered);
    }
  }, [searchTerm, users]);

  /**
   * Load all users from the database
   */
  const loadUsers = async () => {
    try {
      setIsLoading(true);
      
      // Read directly from localStorage for real-time updates
      const usersData = localStorage.getItem('thika_users');
      const allUsers = usersData ? JSON.parse(usersData) : [];
      
      // Filter out soni-q and makopolo, exclude password data
      const eligibleUsers = allUsers
        .filter(u => 
          u.username !== 'soni-q' && 
          u.username !== 'makopolo' &&
          !u.isPermanent
        )
        .map(u => ({
          id: u.id,
          username: u.username,
          email: u.email,
          phone: u.phone,
          isAdmin: u.isAdmin,
          isPermanent: u.isPermanent,
          createdAt: u.createdAt,
          lastLoginAt: u.lastLoginAt,
          isActive: u.isActive
        }));

      setUsers(eligibleUsers);
      setFilteredUsers(eligibleUsers);
    } catch (error) {
      console.error('Error loading users:', error);
      setMessage({ type: 'error', text: 'Failed to load users' });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Promote user to admin
   */
  const handlePromoteUser = async (userId: string, username: string) => {
    try {
      setActionLoading(userId);
      const success = await authService.promoteUserToAdmin(userId);
      
      if (success) {
        setMessage({ type: 'success', text: `${username} has been promoted to admin` });
        await loadUsers(); // Refresh the list
      } else {
        setMessage({ type: 'error', text: `Failed to promote ${username}` });
      }
    } catch (error) {
      console.error('Error promoting user:', error);
      setMessage({ type: 'error', text: `Failed to promote ${username}` });
    } finally {
      setActionLoading(null);
    }
  };

  /**
   * Demote admin to regular user
   */
  const handleDemoteUser = async (userId: string, username: string) => {
    try {
      setActionLoading(userId);
      const success = await authService.demoteAdminToUser(userId);
      
      if (success) {
        setMessage({ type: 'success', text: `${username} has been demoted to regular user` });
        await loadUsers(); // Refresh the list
      } else {
        setMessage({ type: 'error', text: `Failed to demote ${username}` });
      }
    } catch (error) {
      console.error('Error demoting user:', error);
      setMessage({ type: 'error', text: `Failed to demote ${username}` });
    } finally {
      setActionLoading(null);
    }
  };

  /**
   * Clear message after 5 seconds
   */
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        setMessage(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  // Redirect if not makopolo
  if (!isMakopolo) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Crown className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground mb-4">
              This page is only accessible to the main administrator (makopolo).
            </p>
            <Button asChild>
              <Link to="/admin">Return to Admin Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <BackButton variant="both" size="sm" />
          </div>
          <div className="flex items-center gap-3">
            <Crown className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Admin Promotion Management</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Promote or demote users to/from admin status. Admin contact info becomes visible to regular users.
          </p>
        </div>

        {/* Message Display */}
        {message && (
          <div className={`mb-6 p-4 rounded-lg border ${
            message.type === 'success' ? 'bg-green-50 border-green-200 text-green-800' :
            message.type === 'error' ? 'bg-red-50 border-red-200 text-red-800' :
            'bg-blue-50 border-blue-200 text-blue-800'
          }`}>
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              <span className="font-medium">{message.text}</span>
            </div>
          </div>
        )}

        {/* Search and Stats */}
        <div className="mb-6 space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search users by username, email, or phone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Badge variant="outline" className="text-sm">
              {filteredUsers.length} users found
            </Badge>
            <Badge variant="secondary" className="text-sm">
              {filteredUsers.filter(u => u.isAdmin).length} admins
            </Badge>
          </div>
        </div>

        {/* Users List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading users...</p>
            </div>
          </div>
        ) : filteredUsers.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Users Found</h3>
              <p className="text-muted-foreground">
                {searchTerm ? 'No users match your search criteria.' : 'No eligible users found.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredUsers.map((user) => (
              <Card key={user.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="flex items-center gap-2">
                          <User className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold text-lg">{user.username}</span>
                          {user.isAdmin && (
                            <Badge variant="default" className="bg-primary">
                              <Crown className="h-3 w-3 mr-1" />
                              Admin
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          <span>{user.email}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          <span>{user.phone}</span>
                        </div>
                      </div>
                      
                      <div className="mt-2 text-xs text-muted-foreground">
                        Joined: {new Date(user.createdAt).toLocaleDateString()}
                        {user.lastLoginAt && (
                          <span className="ml-4">
                            Last login: {new Date(user.lastLoginAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 ml-4">
                      {user.isAdmin ? (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDemoteUser(user.id, user.username)}
                          disabled={actionLoading === user.id}
                        >
                          {actionLoading === user.id ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          ) : (
                            <>
                              <UserMinus className="h-4 w-4 mr-1" />
                              Demote
                            </>
                          )}
                        </Button>
                      ) : (
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handlePromoteUser(user.id, user.username)}
                          disabled={actionLoading === user.id}
                        >
                          {actionLoading === user.id ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          ) : (
                            <>
                              <UserPlus className="h-4 w-4 mr-1" />
                              Promote
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Info Card */}
        <Card className="mt-8 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                  Admin Promotion Information
                </h3>
                <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                  <li>• When promoted to admin, users become permanent and cannot logout, checkout, or delete their account</li>
                  <li>• Admin contact information (email and phone) becomes visible to regular users in the support section</li>
                  <li>• Only makopolo can promote or demote other admins</li>
                  <li>• soni-q and makopolo are excluded from this list as they are permanent users</li>
                  <li>• Changes take effect immediately and are reflected across the entire application</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminPromotionPage;
