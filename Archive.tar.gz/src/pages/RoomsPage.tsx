import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import RoomCard from '@/components/ui/room-card';
import { useRooms } from '@/contexts/RoomContext';
import { Room } from '@/types/booking';
import { Filter } from 'lucide-react';

const RoomsPage = () => {
  const navigate = useNavigate();
  const { rooms, selectedRoom, setSelectedRoom, getRoomStats } = useRooms();
  const [filteredRooms, setFilteredRooms] = useState<Room[]>(rooms);
  const [filterType, setFilterType] = useState<'all' | 'single' | 'double' | 'suite'>('all');
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);

  // Get room statistics from room management data
  const roomStats = getRoomStats();

  useEffect(() => {
    let filtered = rooms;
    
    if (filterType !== 'all') {
      filtered = filtered.filter(room => room.type === filterType);
    }
    
    if (showAvailableOnly) {
      filtered = filtered.filter(room => room.isAvailable);
    }
    
    setFilteredRooms(filtered);
  }, [filterType, showAvailableOnly, rooms]);

  /**
   * Handle room selection with intuitive click behavior
   * - First click: Selects the room
   * - Second click on same room: Deselects the room
   * - Click on different room: Switches selection
   */
  const handleRoomSelect = (roomId: string) => {
    if (selectedRoom === roomId) {
      setSelectedRoom(null); // Deselect if clicking the same room
    } else {
      setSelectedRoom(roomId); // Select new room
    }
  };

  const handleProceedToBooking = () => {
    if (selectedRoom) {
      navigate(`/booking?roomId=${selectedRoom}`);
    }
  };

  // Use room management data for counts
  const availableRooms = roomStats.availableRooms;
  const totalRooms = roomStats.totalRooms;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">Choose Your Room</h1>
          <p className="text-sm sm:text-base lg:text-lg text-muted-foreground mb-2 px-2">
            Browse our available rooms and find the perfect accommodation for your stay
          </p>
          <p className="text-xs sm:text-sm text-muted-foreground mb-4 sm:mb-6 px-2">
            Click once to select a room, click again to deselect
          </p>
          <div className="flex items-center justify-center gap-2 sm:gap-4 text-xs sm:text-sm">
            <Badge variant="outline" className="text-xs sm:text-sm">
              {availableRooms} Available
            </Badge>
            <Badge variant="secondary" className="text-xs sm:text-sm">
              {totalRooms} Total Rooms
            </Badge>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6 sm:mb-8">
          <CardHeader className="pb-3 sm:pb-6">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <Filter className="h-4 w-4 sm:h-5 sm:w-5" />
              Filter & Sort
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={filterType === 'all' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs sm:text-sm"
                  onClick={() => setFilterType('all')}
                >
                  All Rooms
                </Button>
                <Button
                  variant={filterType === 'single' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs sm:text-sm"
                  onClick={() => setFilterType('single')}
                >
                  Single
                </Button>
                <Button
                  variant={filterType === 'double' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs sm:text-sm"
                  onClick={() => setFilterType('double')}
                >
                  Double
                </Button>
                <Button
                  variant={filterType === 'suite' ? 'default' : 'outline'}
                  size="sm"
                  className="text-xs sm:text-sm"
                  onClick={() => setFilterType('suite')}
                >
                  Suite
                </Button>
              </div>
              
              <Button
                variant={showAvailableOnly ? 'default' : 'outline'}
                size="sm"
                className="text-xs sm:text-sm w-full sm:w-auto"
                onClick={() => setShowAvailableOnly(!showAvailableOnly)}
              >
                Available Only
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Rooms Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          {filteredRooms.map((room) => (
            <RoomCard
              key={room.id}
              room={room}
              onSelect={handleRoomSelect}
              isSelected={selectedRoom === room.id}
            />
          ))}
        </div>

        {filteredRooms.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-muted-foreground mb-4">
              No rooms match your current filters
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setFilterType('all');
                setShowAvailableOnly(false);
              }}
            >
              Reset Filters
            </Button>
          </div>
        )}

        {/* Selected Room Action */}
        {selectedRoom && (
          <Card className="sticky bottom-4 bg-primary text-primary-foreground shadow-card-hover">
            <CardContent className="flex items-center justify-between p-6">
              <div>
                <p className="font-semibold">Room Selected</p>
                <p className="text-sm opacity-90">
                  {(() => {
                    const room = rooms.find(r => r.id === selectedRoom);
                    if (!room) return 'Room Selected';
                    return `${room.type?.charAt(0).toUpperCase() + room.type?.slice(1)} Room - KSh ${room.price?.toLocaleString()}/month`;
                  })()}
                </p>
              </div>
              <Button
                variant="secondary"
                onClick={handleProceedToBooking}
              >
                Proceed to Booking
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default RoomsPage;