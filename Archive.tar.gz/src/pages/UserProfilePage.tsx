import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ImageService from '@/services/ImageService';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { 
  User, 
  Upload, 
  Camera, 
  Download, 
  CreditCard,
  CheckCircle,
  X,
  AlertCircle,
  Calendar,
  DollarSign,
  Home,
  Clock,
  Shield,
  Trash2
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { SubscriptionReminder } from '@/components/ui/subscription-reminder';
import { useFacilities } from '@/hooks/useFacilities';

/**
 * User Profile Page Component
 * 
 * Comprehensive profile management with plan change functionality and room availability tracking.
 * 
 * Features:
 * - Profile image upload and management
 * - Plan selection and change with payment calculations
 * - Room availability tracking and booking management
 * - Payment history and receipt generation
 * - Preview mode restrictions
 * - Plan change options (immediate vs end of month)
 */
const UserProfilePage = () => {
  const { user, isPreview, updateProfile, deleteUserAccount } = useAuth();
  const { activeFacilities } = useFacilities();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Profile and UI state
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<string>('single');
  const [paymentMethod, setPaymentMethod] = useState<string>('mpesa');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string>('');
  
  // Plan change functionality
  const [showPlanChangeDialog, setShowPlanChangeDialog] = useState(false);
  const [newPlan, setNewPlan] = useState<string>('');
  const [changeOption, setChangeOption] = useState<'immediate' | 'end-of-month'>('immediate');
  const [roomAvailability, setRoomAvailability] = useState<Record<string, number>>({
    single: 20,
    double: 12,
    suite: 12
  });
  const [planChangeRequests, setPlanChangeRequests] = useState<Array<{
    id: string;
    fromPlan: string;
    toPlan: string;
    status: 'pending' | 'approved' | 'rejected';
    requestedAt: Date;
    adminReason?: string;
  }>>([]);
  const [pendingPlanChange, setPendingPlanChange] = useState<string | null>(null);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showMultiMonthModal, setShowMultiMonthModal] = useState(false);
  const [bookingMonths, setBookingMonths] = useState(1);

  // Plan details with pricing and availability
  const userPlans = {
    single: {
      name: 'Single Room',
      price: 4500,
      priceDisplay: 'KSh 4,500',
      duration: 'Monthly',
      features: ['Single occupancy', ...activeFacilities.map(f => f.name)],
      maxRooms: 20,
      image: ImageService.getInstance().getRoomImage('single')
    },
    double: {
      name: 'Double Room',
      price: 6000,
      priceDisplay: 'KSh 6,000',
      duration: 'Monthly',
      features: ['Double occupancy', ...activeFacilities.map(f => f.name)],
      maxRooms: 12,
      image: ImageService.getInstance().getRoomImage('double')
    },
    suite: {
      name: 'Suite',
      price: 8500,
      priceDisplay: 'KSh 8,500',
      duration: 'Monthly',
      features: ['Up to 2 occupants', ...activeFacilities.map(f => f.name), 'Extra amenities'],
      maxRooms: 12,
      image: ImageService.getInstance().getRoomImage('suite')
    }
  };

  // Initialize selected plan from user data
  useEffect(() => {
    if (user?.selectedPlan) {
      setSelectedPlan(user.selectedPlan);
    }
  }, [user]);


  /**
   * Calculate plan change costs and prorated amounts
   */
  const calculatePlanChangeCost = (fromPlan: string, toPlan: string, option: 'immediate' | 'end-of-month') => {
    const currentPlan = userPlans[fromPlan as keyof typeof userPlans];
    const newPlan = userPlans[toPlan as keyof typeof userPlans];
    const isDowngrade = newPlan.price < currentPlan.price;
    
    if (option === 'immediate') {
      // Calculate prorated refund for current plan
      const daysInMonth = 30;
      const currentDate = new Date();
      const daysRemaining = daysInMonth - currentDate.getDate();
      const proratedRefund = Math.round((currentPlan.price * daysRemaining) / daysInMonth);
      
      // Calculate prorated cost for new plan
      const proratedNewPlan = Math.round((newPlan.price * daysRemaining) / daysInMonth);
      
      // For downgrades, calculate extra money to be refunded
      const extraMoney = isDowngrade ? Math.max(0, proratedRefund - proratedNewPlan) : 0;
      
      return {
        proratedRefund,
        proratedNewPlan,
        netCost: Math.max(0, proratedNewPlan - proratedRefund),
        extraMoney, // Extra money from downgrade
        isDowngrade,
        nextMonthDiscount: extraMoney // Amount to subtract from next month's payment
      };
    } else {
      // End of month - no proration
      const extraMoney = isDowngrade ? Math.max(0, currentPlan.price - newPlan.price) : 0;
      
      return {
        proratedRefund: 0,
        proratedNewPlan: newPlan.price,
        netCost: Math.max(0, newPlan.price - currentPlan.price),
        extraMoney, // Extra money from downgrade
        isDowngrade,
        nextMonthDiscount: extraMoney // Amount to subtract from next month's payment
      };
    }
  };

  /**
   * Check if a plan is available for booking
   */
  const isPlanAvailable = (planKey: string) => {
    return roomAvailability[planKey] > 0;
  };

  /**
   * Handle plan change request - automatically initiate if different from current plan
   * Soni-q can change plans immediately without admin approval
   */
  const handlePlanChangeRequest = (planKey: string) => {
    if (planKey === selectedPlan) {
      // Same plan selected, no change needed
      return;
    }
    
    if (!isPlanAvailable(planKey)) {
      alert(`Sorry, ${userPlans[planKey as keyof typeof userPlans].name} is currently fully booked. Please choose a different plan.`);
      return;
    }
    
    // If user is soni-q, allow immediate plan change without admin approval
    if (user?.isPermanent && user?.username === 'soni-q') {
      setSelectedPlan(planKey);
      alert(`Plan successfully changed to ${userPlans[planKey as keyof typeof userPlans].name}! Soni-q has special access to all plans.`);
      return;
    }
    
    // Create plan change request for admin approval
    const requestId = `plan-change-${Date.now()}`;
    const newRequest = {
      id: requestId,
      fromPlan: selectedPlan,
      toPlan: planKey,
      status: 'pending' as const,
      requestedAt: new Date()
    };
    
    setPlanChangeRequests(prev => [...prev, newRequest]);
    setPendingPlanChange(planKey);
    setNewPlan(planKey);
    setShowPlanChangeDialog(true);
    
    // Show notification
    alert(`Plan change request submitted for ${userPlans[planKey as keyof typeof userPlans].name}. Waiting for admin approval.`);
  };

  /**
   * Process plan change after admin approval
   */
  const processPlanChange = () => {
    if (!newPlan || !user) return;
    
    const costCalculation = calculatePlanChangeCost(selectedPlan, newPlan, changeOption);
    const newPlanData = userPlans[newPlan as keyof typeof userPlans];
    
    // Update room availability
    setRoomAvailability(prev => ({
      ...prev,
      [selectedPlan]: prev[selectedPlan] + 1,
      [newPlan]: prev[newPlan] - 1
    }));
    
    // Process payment if there's a cost
    if (costCalculation.netCost > 0) {
      const success = true; // Simplified payment processing
      console.log('Payment processed:', 
        `KSh ${costCalculation.netCost}`,
        `Plan Change to ${newPlanData.name}`,
        paymentMethod
      );
      
      if (success) {
        // Update user's plan and add refund credit for downgrades
        const updatedUser = {
          ...user,
          selectedPlan: newPlan,
          lastPaymentDate: new Date().toISOString()
        };
        
        // Add refund credit for downgrades
        if (costCalculation.isDowngrade && costCalculation.nextMonthDiscount > 0) {
          (updatedUser as Record<string, unknown>).nextMonthDiscount = ((updatedUser as Record<string, unknown>).nextMonthDiscount as number || 0) + costCalculation.nextMonthDiscount;
        }
        
        updateProfile?.(updatedUser);
        setSelectedPlan(newPlan);
        setShowPlanChangeDialog(false);
        setPendingPlanChange(null);
        
        // Update plan change request status
        setPlanChangeRequests(prev => 
          prev.map(req => 
            req.id === planChangeRequests[planChangeRequests.length - 1]?.id 
              ? { ...req, status: 'approved' as const }
              : req
          )
        );

        // Simplified financial tracking
        
        alert(`Plan successfully changed to ${newPlanData.name}!${costCalculation.isDowngrade ? ` Refund of KSh ${costCalculation.nextMonthDiscount} will be applied to your next payment.` : ''}`);
      } else {
        alert('Payment failed. Please try again.');
      }
    } else {
      // No additional cost - just update the plan
      const updatedUser = {
        ...user,
        selectedPlan: newPlan
      };
      
      // Add refund credit for downgrades even with no immediate cost
      if (costCalculation.isDowngrade && costCalculation.nextMonthDiscount > 0) {
        (updatedUser as Record<string, unknown>).nextMonthDiscount = ((updatedUser as Record<string, unknown>).nextMonthDiscount as number || 0) + costCalculation.nextMonthDiscount;
      }
      
      updateProfile?.(updatedUser);
      setSelectedPlan(newPlan);
      setShowPlanChangeDialog(false);
      setPendingPlanChange(null);
      
      // Update plan change request status
      setPlanChangeRequests(prev => 
        prev.map(req => 
          req.id === planChangeRequests[planChangeRequests.length - 1]?.id 
            ? { ...req, status: 'approved' as const }
            : req
        )
      );

      // Simplified financial tracking
      
      alert(`Plan successfully changed to ${newPlanData.name}!${costCalculation.isDowngrade ? ` Refund of KSh ${costCalculation.nextMonthDiscount} will be applied to your next payment.` : ''}`);
    }
  };

  const paymentMethods = [
    { id: 'mpesa', name: 'M-Pesa', icon: '📱' },
    { id: 'card', name: 'Credit/Debit Card', icon: '💳' },
    { id: 'bank', name: 'Bank Transfer', icon: '🏦' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setUploadError('Image size must be less than 2MB');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file');
      return;
    }

    setIsUploading(true);
    setUploadError('');

    // Simulate upload process
    const reader = new FileReader();
    reader.onload = (e) => {
      setProfileImage(e.target?.result as string);
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setProfileImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGenerateReceipt = (paymentId: string) => {
    if (isPreview) return;
    
    // Simplified receipt generation
    const receiptContent = `Receipt for ${user?.username} - Payment ID: ${paymentId}`;

    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt-${user?.username}-${paymentId}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };


  const handlePayment = () => {
    if (isPreview) return;
    
    const plan = userPlans[selectedPlan as keyof typeof userPlans];
    const totalAmount = plan.price * bookingMonths;
    const success = true; // Simplified payment processing
    
    if (success) {
      // Update user with multi-month booking
      const updatedUser = {
        ...user,
        bookingMonths: (user?.bookingMonths || 0) + bookingMonths,
        lastPaymentDate: new Date().toISOString()
      };
      updateProfile?.(updatedUser);
      
      alert(`Payment of KSh ${totalAmount} for ${bookingMonths} month${bookingMonths > 1 ? 's' : ''} via ${paymentMethods.find(p => p.id === paymentMethod)?.name} processed successfully!`);
      setShowMultiMonthModal(false);
    } else {
      alert('Payment failed. Please try again.');
    }
  };

  /**
   * Handle checkout request
   */
  const handleCheckout = async () => {
    if (!user?.id) return;
    
    try {
      // For checkout, we also delete the user account and all data
      const success = await deleteUserAccount(user.id);
      if (success) {
        alert('Checkout completed. Your account and all data have been removed from the system.');
        setShowCheckoutModal(false);
        // User will be automatically logged out by the deleteUserAccount method
      } else {
        alert('Failed to process checkout. Please try again or contact support.');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      alert('An error occurred during checkout. Please try again.');
    }
  };

  /**
   * Handle account deletion request
   */
  const handleAccountDeletion = async () => {
    if (!user?.id) return;
    
    try {
      const success = await deleteUserAccount(user.id);
      if (success) {
        alert('Your account and all related data have been permanently deleted.');
        // User will be automatically logged out by the deleteUserAccount method
      } else {
        alert('Failed to delete account. Please try again or contact support.');
      }
    } catch (error) {
      console.error('Account deletion error:', error);
      alert('An error occurred while deleting your account. Please try again.');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <X className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground mb-4">
              You need to be signed in to access this page.
            </p>
            <Button asChild>
              <Link to="/signin">Sign In</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container mx-auto max-w-4xl">
        {/* Subscription Reminder */}
        <SubscriptionReminder />
        
        <div className="mb-6">
          <BackButton variant="both" className="mb-4" />
          <div className="flex items-center gap-3">
            <User className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">User Profile</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Manage your profile, view your plan, and access receipts
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Profile Section */}
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Image Upload */}
              <div className="space-y-4">
                <Label>Profile Picture</Label>
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                    {profileImage ? (
                      <img 
                        src={profileImage} 
                        alt="Profile" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Camera className="h-8 w-8 text-muted-foreground" />
                    )}
                  </div>
                  <div className="space-y-2">
                    <Input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      {isUploading ? 'Uploading...' : 'Upload Image'}
                    </Button>
                    {profileImage && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleRemoveImage}
                      >
                        <X className="h-4 w-4 mr-2" />
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
                {uploadError && (
                  <Alert variant="destructive">
                    <AlertDescription>{uploadError}</AlertDescription>
                  </Alert>
                )}
                <p className="text-xs text-muted-foreground">
                  Maximum file size: 2MB. Supported formats: JPG, PNG, GIF
                </p>
              </div>

              {/* User Info Display */}
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Username</Label>
                  <p className="text-sm text-muted-foreground">{user.username}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Email</Label>
                  <p className="text-sm text-muted-foreground">{user.email}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Phone</Label>
                  <p className="text-sm text-muted-foreground">{user.phone}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Plan & Plan Change */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Current Plan</CardTitle>
                {pendingPlanChange && (
                  <Badge variant="secondary" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    Pending Approval
                  </Badge>
                )}
                {user?.pendingCheckout && (
                  <Badge variant="secondary" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    Checkout Pending
                  </Badge>
                )}
                {user?.pendingDeletion && (
                  <Badge variant="secondary" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    Deletion Pending
                  </Badge>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowMultiMonthModal(true)}
                  disabled={isPreview && !user?.isAdmin && !user?.isPermanent}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Book Multiple Months
                </Button>
                {!user?.isAdmin && !user?.isPermanent && (
                  <>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setShowCheckoutModal(true)}
                      disabled={isPreview}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Checkout
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (window.confirm('Are you sure you want to permanently delete your account? This action cannot be undone.')) {
                          handleAccountDeletion();
                        }
                      }}
                      disabled={isPreview}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete Account
                    </Button>
                  </>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Admin/Permanent User Notice */}
              {(user?.isAdmin || user?.isPermanent) && (
                <div className="p-4 border border-blue-200 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-blue-600" />
                    <div>
                      <h4 className="font-semibold text-blue-800 dark:text-blue-200">
                        {user?.isAdmin ? 'Admin Account' : 'Permanent Account'}
                      </h4>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        {user?.isAdmin 
                          ? 'Admin accounts are permanent and cannot be checked out or deleted. This ensures continuous system operation and administrative access.'
                          : 'Permanent accounts cannot be checked out or deleted. This ensures continuous system access and data integrity.'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Current Plan Display */}
              <div className="p-4 border border-primary bg-primary/5 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-primary">{userPlans[selectedPlan as keyof typeof userPlans].name}</h3>
                  <Badge variant="default">
                    {userPlans[selectedPlan as keyof typeof userPlans].priceDisplay}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{userPlans[selectedPlan as keyof typeof userPlans].duration}</p>
                <ul className="text-sm space-y-1">
                  {userPlans[selectedPlan as keyof typeof userPlans].features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Available Plans */}
              <div className="space-y-3">
                <h4 className="font-medium">Available Plans</h4>
                {Object.entries(userPlans).map(([key, plan]) => (
                  <div
                    key={key}
                    className={`p-3 border rounded-lg transition-all ${
                      selectedPlan === key
                        ? 'border-primary bg-primary/5'
                        : isPlanAvailable(key)
                        ? 'border-border hover:border-primary/50 cursor-pointer'
                        : 'border-gray-300 bg-gray-50 opacity-60'
                    }`}
                    onClick={() => selectedPlan !== key && isPlanAvailable(key) && handlePlanChangeRequest(key)}
                  >
                    <div className="flex gap-3">
                      {/* Room Image */}
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                        <img 
                          src={plan.image} 
                          alt={plan.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {/* Plan Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{plan.name}</h4>
                            {!isPlanAvailable(key) && (
                              <Badge variant="destructive" className="text-xs">Fully Booked</Badge>
                            )}
                            {selectedPlan === key && (
                              <Badge variant="default" className="text-xs">Current</Badge>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{plan.priceDisplay}</div>
                            <div className="text-xs text-muted-foreground">
                              {roomAvailability[key]} rooms available
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Home className="h-3 w-3" />
                          {plan.features.slice(0, 2).join(' • ')}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Payment Method - Hidden for preview users */}
          {!isPreview && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${
                      paymentMethod === method.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => setPaymentMethod(method.id)}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{method.icon}</span>
                      <span className="font-medium">{method.name}</span>
                      {paymentMethod === method.id && (
                        <CheckCircle className="h-5 w-5 text-primary ml-auto" />
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Payment & Receipt - Hidden for preview users */}
          {!isPreview && (
            <Card>
              <CardHeader>
                <CardTitle>Payment & Receipt</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold mb-2">Order Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Plan:</span>
                      <span>{userPlans[selectedPlan as keyof typeof userPlans].name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Amount:</span>
                      <span className="font-semibold">{userPlans[selectedPlan as keyof typeof userPlans].price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Payment Method:</span>
                      <span>{paymentMethods.find(p => p.id === paymentMethod)?.name}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button onClick={handlePayment} className="w-full">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Pay Now
                  </Button>
                </div>

                {/* Payment History */}
                {user?.paymentHistory && user.paymentHistory.length > 0 && (
                  <div className="mt-6">
                    <h4 className="font-semibold mb-3">Payment History</h4>
                    <div className="space-y-2">
                      {user.paymentHistory.map((payment) => (
                        <div key={payment.id} className="p-3 border rounded-lg flex items-center justify-between">
                          <div>
                            <p className="font-medium">{payment.plan}</p>
                            <p className="text-sm text-muted-foreground">
                              {payment.amount} • {new Date(payment.date).toLocaleDateString()}
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleGenerateReceipt(payment.id)}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Receipt
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Preview Mode Message */}
          {isPreview && (
            <Card>
              <CardHeader>
                <CardTitle>Preview Mode</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-5 w-5 text-yellow-600" />
                    <h4 className="font-semibold text-yellow-800 dark:text-yellow-200">Preview Mode Active</h4>
                  </div>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300 mb-3">
                    You're currently in preview mode. To access payment features and make bookings, please create a full account.
                  </p>
                  <Button asChild className="w-full">
                    <Link to="/register">Create Full Account</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Plan Change Dialog */}
        <Dialog open={showPlanChangeDialog} onOpenChange={setShowPlanChangeDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Plan Change Request</DialogTitle>
              <DialogDescription>
                Your plan change request has been submitted for admin approval. Choose when to change your plan and see the cost breakdown.
              </DialogDescription>
            </DialogHeader>
            
            {newPlan && (
              <div className="space-y-4">
                {/* Plan Selection */}
                <div>
                  <Label className="text-sm font-medium">New Plan</Label>
                  <div className="p-3 border rounded-lg bg-muted/50">
                    <div className="flex gap-3">
                      {/* Room Image */}
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                        <img 
                          src={userPlans[newPlan as keyof typeof userPlans].image} 
                          alt={userPlans[newPlan as keyof typeof userPlans].name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {/* Plan Details */}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{userPlans[newPlan as keyof typeof userPlans].name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {userPlans[newPlan as keyof typeof userPlans].priceDisplay} per month
                            </p>
                          </div>
                          <Badge variant="outline">
                            {roomAvailability[newPlan]} rooms available
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Change Option */}
                <div>
                  <Label className="text-sm font-medium">When to Change</Label>
                  <div className="space-y-2 mt-2">
                    <div
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        changeOption === 'immediate'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => setChangeOption('immediate')}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          checked={changeOption === 'immediate'}
                          onChange={() => setChangeOption('immediate')}
                          className="text-primary"
                        />
                        <div>
                          <div className="font-medium">Change Now</div>
                          <div className="text-sm text-muted-foreground">
                            Prorated billing based on remaining days
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        changeOption === 'end-of-month'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => setChangeOption('end-of-month')}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          checked={changeOption === 'end-of-month'}
                          onChange={() => setChangeOption('end-of-month')}
                          className="text-primary"
                        />
                        <div>
                          <div className="font-medium">End of Month</div>
                          <div className="text-sm text-muted-foreground">
                            Full new plan price starting next month
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cost Breakdown */}
                {(() => {
                  const costCalculation = calculatePlanChangeCost(selectedPlan, newPlan, changeOption);
                  return (
                    <div className="p-4 bg-muted rounded-lg space-y-2">
                      <h4 className="font-medium flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Cost Breakdown
                      </h4>
                      
                      {changeOption === 'immediate' && costCalculation.proratedRefund > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Refund for current plan:</span>
                          <span className="text-green-600">-KSh {costCalculation.proratedRefund}</span>
                        </div>
                      )}
                      
                      <div className="flex justify-between text-sm">
                        <span>New plan cost:</span>
                        <span>KSh {costCalculation.proratedNewPlan}</span>
                      </div>
                      
                      {costCalculation.isDowngrade && costCalculation.nextMonthDiscount > 0 && (
                        <div className="flex justify-between text-sm text-blue-600">
                          <span>Refund credit (next month):</span>
                          <span>+KSh {costCalculation.nextMonthDiscount}</span>
                        </div>
                      )}
                      
                      <div className="border-t pt-2">
                        <div className="flex justify-between font-medium">
                          <span>Total to pay:</span>
                          <span className={costCalculation.netCost > 0 ? 'text-primary' : 'text-green-600'}>
                            {costCalculation.netCost > 0 ? `KSh ${costCalculation.netCost}` : 'No additional cost'}
                          </span>
                        </div>
                        {costCalculation.isDowngrade && costCalculation.nextMonthDiscount > 0 && (
                          <div className="text-xs text-muted-foreground mt-1">
                            *KSh {costCalculation.nextMonthDiscount} will be deducted from your next month's payment
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowPlanChangeDialog(false)}
              >
                Close
              </Button>
              <Button
                onClick={processPlanChange}
                disabled={!newPlan}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Process After Approval
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Checkout Modal */}
        <Dialog open={showCheckoutModal} onOpenChange={setShowCheckoutModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Checkout & Leave System</DialogTitle>
              <DialogDescription>
                Settle all financial obligations before leaving the system
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Financial Balance Display */}
              {(() => {
                // Simplified financial balance calculation
                const financialBalance = { totalCredits: 0, outstandingDebt: 0, netBalance: 0, canCheckout: true };
                return (
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <h4 className="font-medium flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Financial Summary
                    </h4>
                    
                    <div className="flex justify-between text-sm">
                      <span>Total Credits:</span>
                      <span className="text-green-600">KSh {financialBalance.totalCredits}</span>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span>Outstanding Debt:</span>
                      <span className="text-red-600">KSh {financialBalance.outstandingDebt}</span>
                    </div>
                    
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-medium">
                        <span>Net Balance:</span>
                        <span className={financialBalance.netBalance >= 0 ? 'text-green-600' : 'text-red-600'}>
                          KSh {financialBalance.netBalance}
                        </span>
                      </div>
                    </div>
                    
                    {!financialBalance.canCheckout && (
                      <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-800">
                          <strong>Cannot checkout:</strong> You have outstanding debt that must be settled first.
                        </p>
                      </div>
                    )}
                    
                    {financialBalance.canCheckout && financialBalance.totalCredits > 0 && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm text-green-800">
                          <strong>Refund available:</strong> KSh {financialBalance.totalCredits} will be refunded to your {user?.paymentMethod || 'M-Pesa'} account.
                        </p>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowCheckoutModal(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCheckout}
                variant="destructive"
              >
                <X className="h-4 w-4 mr-2" />
                Process Checkout
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Multi-Month Booking Modal */}
        <Dialog open={showMultiMonthModal} onOpenChange={setShowMultiMonthModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Book Multiple Months</DialogTitle>
              <DialogDescription>
                Book your room for multiple months in advance
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Plan Selection */}
              <div>
                <Label className="text-sm font-medium">Select Plan</Label>
                <div className="grid grid-cols-1 gap-2 mt-2">
                  {Object.entries(userPlans).map(([key, plan]) => (
                    <div
                      key={key}
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        selectedPlan === key
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => setSelectedPlan(key)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{plan.name}</h4>
                          <p className="text-sm text-muted-foreground">{plan.priceDisplay}/month</p>
                        </div>
                        {selectedPlan === key && (
                          <Badge variant="default" className="text-xs">Selected</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Number of Months */}
              <div>
                <Label htmlFor="months" className="text-sm font-medium">Number of Months</Label>
                <Input
                  id="months"
                  type="number"
                  min="1"
                  max="12"
                  value={bookingMonths}
                  onChange={(e) => setBookingMonths(Math.max(1, parseInt(e.target.value) || 1))}
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Book between 1-12 months in advance
                </p>
              </div>

              {/* Payment Method */}
              <div>
                <Label className="text-sm font-medium">Payment Method</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {paymentMethods.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id)}
                      className={`p-3 border rounded-lg text-center transition-all ${
                        paymentMethod === method.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="text-2xl mb-1">{method.icon}</div>
                      <div className="text-xs">{method.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Cost Calculation */}
              {(() => {
                const plan = userPlans[selectedPlan as keyof typeof userPlans];
                const totalAmount = plan.price * bookingMonths;
                const savings = bookingMonths > 1 ? Math.round(plan.price * bookingMonths * 0.05) : 0; // 5% discount for multi-month
                const finalAmount = totalAmount - savings;
                
                return (
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <h4 className="font-medium flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Cost Breakdown
                    </h4>
                    
                    <div className="flex justify-between text-sm">
                      <span>{plan.name} × {bookingMonths} month{bookingMonths > 1 ? 's' : ''}:</span>
                      <span>KSh {totalAmount}</span>
                    </div>
                    
                    {savings > 0 && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>Multi-month discount (5%):</span>
                        <span>-KSh {savings}</span>
                      </div>
                    )}
                    
                    <div className="border-t pt-2">
                      <div className="flex justify-between font-medium">
                        <span>Total Amount:</span>
                        <span>KSh {finalAmount}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowMultiMonthModal(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handlePayment}
                disabled={isPreview}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Pay Now
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default UserProfilePage;
