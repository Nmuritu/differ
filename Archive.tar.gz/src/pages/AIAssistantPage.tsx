import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Bot, 
  Send, 
  MessageSquare, 
  HelpCircle, 
  AlertCircle,
  Lightbulb,
  BookOpen,
  CreditCard,
  Settings,
  User,
  Home,
  Trash2
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import AILearningService from '@/services/AILearningService';
import { useFacilities } from '@/hooks/useFacilities';

/**
 * AI Assistant Page Component
 * 
 * Interactive AI assistant with learning capabilities and preview user restrictions.
 * 
 * Features:
 * - Intelligent responses with learning from interactions
 * - Preview user prompt limits (3 per day)
 * - Clear chat functionality
 * - Real-time conversation interface
 * - Smart suggestions and contextual help
 */
const AIAssistantPage = () => {
  const { isPreview } = useAuth();
  const { activeFacilities } = useFacilities();
  const aiLearningService = AILearningService.getInstance();
  
  // State management
  const [userInput, setUserInput] = useState('');
  
  // Preview user prompt limits (3 per day)
  const [promptCount, setPromptCount] = useState(0);
  const [messages, setMessages] = useState<Array<{
    id: string;
    type: 'user' | 'ai';
    content: string;
    timestamp: Date;
    suggestions?: string[];
  }>>([]);
  
  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load prompt count for preview users
  useEffect(() => {
    if (isPreview) {
      const today = new Date().toDateString();
      const savedCount = localStorage.getItem(`ai_prompt_count_${today}`);
      if (savedCount) {
        setPromptCount(parseInt(savedCount, 10));
      }
    }
  }, [isPreview]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Preview user restrictions
  const hasReachedLimit = isPreview && promptCount >= 3;
  const remainingPrompts = isPreview ? Math.max(0, 3 - promptCount) : Infinity;
  const showLimitWarning = isPreview && promptCount >= 1;

  // Handle sending messages
  const handleSendMessage = async () => {
    if (!userInput.trim() || isLoading || hasReachedLimit) return;

    const userMessage = {
      id: Date.now().toString(),
      type: 'user' as const,
      content: userInput.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setUserInput('');
    setIsLoading(true);

    // Increment prompt count for preview users
    if (isPreview) {
      const newCount = promptCount + 1;
      setPromptCount(newCount);
      const today = new Date().toDateString();
      localStorage.setItem(`ai_prompt_count_${today}`, newCount.toString());
    }

    try {
      // Generate AI response using learning service
      const aiResponse = await generateAIResponse(userMessage.content);
      
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai' as const,
        content: aiResponse.content,
        timestamp: new Date(),
        suggestions: aiResponse.suggestions
      };

      setMessages(prev => [...prev, aiMessage]);
      
      // Learn from this interaction
      aiLearningService.learnFromInteraction(
        userMessage.content, 
        aiResponse.content, 
        'AI Assistant Chat',
        isPreview ? 'preview' : 'client',
        'ai-assistant'
      );
      
      // Store unknown questions for admin review
      if (aiResponse.content.includes("I want to make sure I give you the most accurate information") || 
          aiResponse.content.includes("I'm constantly learning")) {
        // Store question for admin review
        const unknownQuestions = JSON.parse(localStorage.getItem('unknownQuestions') || '[]');
        unknownQuestions.push({
          question: userMessage.content,
          timestamp: new Date().toISOString(),
          userType: isPreview ? 'preview' : 'client'
        });
        localStorage.setItem('unknownQuestions', JSON.stringify(unknownQuestions));
      }
    } catch (error) {
      console.error('Error generating AI response:', error);
      const errorMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai' as const,
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Get room data from localStorage or use defaults
  const getRoomData = () => {
    try {
      const roomData = localStorage.getItem('roomManagement');
      if (roomData) {
        const parsed = JSON.parse(roomData);
        return {
          single: { available: parsed.single?.available || 20, max: parsed.single?.maxRooms || 20, price: parsed.single?.price || 4500 },
          double: { available: parsed.double?.available || 12, max: parsed.double?.maxRooms || 12, price: parsed.double?.price || 6000 },
          suite: { available: parsed.suite?.available || 8, max: parsed.suite?.maxRooms || 12, price: parsed.suite?.price || 8500 }
        };
      }
    } catch (error) {
      console.error('Error loading room data:', error);
    }
    
    // Default values
    return {
      single: { available: 20, max: 20, price: 4500 },
      double: { available: 12, max: 12, price: 6000 },
      suite: { available: 8, max: 12, price: 8500 }
    };
  };

  // Predefined Q&A database
  const qaDatabase = {
    // Room availability calculations
    "rooms available": () => {
      const roomData = getRoomData();
      const totalAvailable = roomData.single.available + roomData.double.available + roomData.suite.available;
      return {
        content: `Current room availability:\n• Single Rooms: ${roomData.single.available} available (${roomData.single.max} total)\n• Double Rooms: ${roomData.double.available} available (${roomData.double.max} total)\n• Suites: ${roomData.suite.available} available (${roomData.suite.max} total)\n\nTotal: ${totalAvailable} rooms available for booking.`,
        suggestions: ['Book a room', 'Room details', 'Pricing info', 'Check availability']
      };
    },
    
    "total rooms": () => {
      const roomData = getRoomData();
      const totalRooms = roomData.single.max + roomData.double.max + roomData.suite.max;
      return {
        content: `We have a total of ${totalRooms} rooms:\n• ${roomData.single.max} Single Rooms (KSh ${roomData.single.price.toLocaleString()}/month)\n• ${roomData.double.max} Double Rooms (KSh ${roomData.double.price.toLocaleString()}/month)\n• ${roomData.suite.max} Suites (KSh ${roomData.suite.price.toLocaleString()}/month)\n\nAll rooms are fully furnished and include modern amenities.`,
        suggestions: ['Room availability', 'Room features', 'Booking process', 'Pricing']
      };
    },
    
    // Pricing calculations
    "monthly cost": (input: string) => {
      const roomData = getRoomData();
      const match = input.match(/(\d+)\s*(single|double|suite)/i);
      if (match) {
        const quantity = parseInt(match[1]);
        const roomType = match[2].toLowerCase() as keyof typeof roomData;
        const price = roomData[roomType].price;
        const total = quantity * price;
        const available = roomData[roomType].available;
        
        let availabilityNote = '';
        if (quantity > available) {
          availabilityNote = `\n⚠️ Note: Only ${available} ${roomType} room${available !== 1 ? 's' : ''} available.`;
        }
        
        return {
          content: `${quantity} ${roomType} room${quantity > 1 ? 's' : ''} would cost KSh ${total.toLocaleString()} per month.\n\nBreakdown:\n• ${roomType.charAt(0).toUpperCase() + roomType.slice(1)} Room: KSh ${price.toLocaleString()}\n• Quantity: ${quantity}\n• Total: KSh ${total.toLocaleString()}${availabilityNote}`,
          suggestions: ['Book now', 'Room details', 'Payment methods', 'Multi-month discount']
        };
      }
      return null;
    },
    
    // Multi-month calculations
    "multi month": (input: string) => {
      const roomData = getRoomData();
      const match = input.match(/(\d+)\s*(single|double|suite).*?(\d+)\s*month/i);
      if (match) {
        const quantity = parseInt(match[1]);
        const roomType = match[2].toLowerCase() as keyof typeof roomData;
        const months = parseInt(match[3]);
        const price = roomData[roomType].price;
        const monthlyTotal = quantity * price;
        const totalCost = monthlyTotal * months;
        const discount = months > 1 ? Math.round(totalCost * 0.05) : 0; // 5% discount for multi-month
        const finalCost = totalCost - discount;
        
        return {
          content: `${quantity} ${roomType} room${quantity > 1 ? 's' : ''} for ${months} month${months > 1 ? 's' : ''}:\n\n• Monthly cost: KSh ${monthlyTotal.toLocaleString()}\n• Total cost: KSh ${totalCost.toLocaleString()}\n• Multi-month discount (5%): -KSh ${discount.toLocaleString()}\n• Final cost: KSh ${finalCost.toLocaleString()}\n• Average per month: KSh ${Math.round(finalCost / months).toLocaleString()}`,
          suggestions: ['Book now', 'Room details', 'Payment methods', 'Check availability']
        };
      }
      return null;
    },
    
    // Common questions - Dynamic based on active facilities
    "wifi": () => {
      const wifiFacility = activeFacilities.find(f => f.name.toLowerCase().includes('wifi') || f.name.toLowerCase().includes('wi-fi'));
      return {
        content: wifiFacility ? 
          `Yes! All our rooms include ${wifiFacility.name.toLowerCase()}. ${wifiFacility.description}` :
          "Yes! All our rooms include free high-speed Wi-Fi internet. The connection is reliable and suitable for work, streaming, and online learning.",
        suggestions: ['Room amenities', 'Booking process', 'Room types', 'Contact support']
      };
    },
    
    "security": () => {
      const securityFacility = activeFacilities.find(f => f.name.toLowerCase().includes('security'));
      return {
        content: securityFacility ? 
          `We provide ${securityFacility.name.toLowerCase()} with:\n• ${securityFacility.description}\n\nYour safety is our priority!` :
          "We provide 24/7 security with:\n• CCTV surveillance\n• Security guards on duty\n• Secure access control\n• Well-lit premises\n\nYour safety is our priority!",
        suggestions: ['Room booking', 'Facilities', 'Contact admin', 'Safety measures']
      };
    },
    
    "parking": () => {
      const parkingFacility = activeFacilities.find(f => f.name.toLowerCase().includes('parking'));
      return {
        content: parkingFacility ? 
          `Yes, we provide ${parkingFacility.name.toLowerCase()}. ${parkingFacility.description}` :
          "Yes, we provide free parking space for all residents. The parking area is secure and well-lit.",
        suggestions: ['Room booking', 'Facilities', 'Location info', 'Contact support']
      };
    },
    
    "payment methods": () => ({
      content: "We accept various payment methods:\n• M-Pesa\n• Credit/Debit Cards\n• Bank Transfer\n• Cash (at reception)\n\nAll payments are secure and processed immediately.",
      suggestions: ['Book a room', 'Payment process', 'Room pricing', 'Contact admin']
    }),
    
    "check in": () => ({
      content: "Check-in process:\n1. Visit our reception\n2. Present your ID and booking confirmation\n3. Complete registration forms\n4. Receive your room key\n5. Get orientation tour\n\nReception is open 24/7 for your convenience.",
      suggestions: ['Book a room', 'Contact admin', 'Room details', 'Location info']
    }),
    
    "rules": () => ({
      content: "Our hostel rules:\n• No smoking in rooms\n• Quiet hours: 10 PM - 6 AM\n• No pets allowed\n• Keep rooms clean\n• Respect other residents\n• Report issues to admin\n\nThese rules ensure everyone has a comfortable stay.",
      suggestions: ['Contact admin', 'Room booking', 'Facilities', 'Help']
    }),
    
    "facilities": () => ({
      content: `Our current facilities include:\n${activeFacilities.map(f => `• ${f.icon} ${f.name} - ${f.description}`).join('\n')}\n\nAll facilities are available to all residents.`,
      suggestions: ['Room booking', 'Room types', 'Contact admin', 'Help']
    }),
    
    "amenities": () => ({
      content: `We offer the following amenities:\n${activeFacilities.map(f => `• ${f.icon} ${f.name} - ${f.description}`).join('\n')}\n\nThese amenities are included in your room rent.`,
      suggestions: ['Room booking', 'Room types', 'Contact admin', 'Help']
    })
  };

  // Generate AI response with learning and human-like interaction
  const generateAIResponse = async (input: string): Promise<{ content: string; suggestions?: string[] }> => {
    const lowerInput = input.toLowerCase();
    
    // Check for greetings
    if (lowerInput.includes('hello') || lowerInput.includes('hi') || lowerInput.includes('hey')) {
      return {
        content: "Hello! I'm your AI assistant for Thika Mains Hostels. I'm here to help you with any questions about our accommodation, booking process, or services. How can I assist you today?",
        suggestions: ['Tell me about rooms', 'How do I book?', 'What are the prices?', 'Room availability']
      };
    }
    
    // Check predefined Q&A database first
    for (const [key, handler] of Object.entries(qaDatabase)) {
      if (lowerInput.includes(key)) {
        const result = typeof handler === 'function' ? handler(input) : handler;
        if (result) return result;
      }
    }
    
    // Check for room-related questions
    if (lowerInput.includes('room') || lowerInput.includes('accommodation')) {
      return {
        content: "We offer three types of rooms:\n• Single Room - KSh 4,500/month\n• Double Room - KSh 6,000/month\n• Suite - KSh 8,500/month\n\nAll rooms include free Wi-Fi, 24/7 security, and parking space. Would you like to know more about availability or specific room features?",
        suggestions: ['Room availability', 'Room features', 'How to book?', 'Pricing details']
      };
    }
    
    // Check for booking questions
    if (lowerInput.includes('book') || lowerInput.includes('reserve')) {
      return {
        content: "To book a room, you can:\n1. Visit our Rooms page to see availability\n2. Select your preferred room type\n3. Choose your payment method\n4. Complete the booking process\n\nWould you like me to check current availability or guide you through the booking process?",
        suggestions: ['Check availability', 'Room types', 'Payment methods', 'Booking process']
      };
    }
    
    // Check for price questions
    if (lowerInput.includes('price') || lowerInput.includes('cost') || lowerInput.includes('fee')) {
      return {
        content: "Our current room prices are:\n• Single Room: KSh 4,500 per month\n• Double Room: KSh 6,000 per month\n• Suite: KSh 8,500 per month\n\nAll prices include utilities, Wi-Fi, and security. We also offer multi-month booking discounts! Need help calculating costs for multiple rooms?",
        suggestions: ['Calculate cost', 'Room availability', 'Multi-month discount', 'Payment methods']
      };
    }
    
    // Check for contact/support questions
    if (lowerInput.includes('contact') || lowerInput.includes('support') || lowerInput.includes('help')) {
      return {
        content: "For support, you can:\n• Use the 'Ask Admin' feature in the app\n• Contact us through the chat forum\n• Visit our Help page for FAQs\n• Check the User Manual for detailed guides\n\nIs there something specific you need help with? I can also try to find more information for you.",
        suggestions: ['Ask Admin', 'Chat Forum', 'Help Page', 'User Manual']
      };
    }
    
    // Check for arithmetic/calculation requests
    if (lowerInput.includes('calculate') || lowerInput.includes('math') || lowerInput.includes('total')) {
      return {
        content: "I can help with calculations! Try asking me things like:\n• 'How much for 2 single rooms?'\n• 'Total cost for 3 months?'\n• 'How many rooms are available?'\n\nWhat would you like me to calculate for you?",
        suggestions: ['Room cost calculation', 'Availability check', 'Multi-month pricing', 'Room comparison']
      };
    }
    
    // Check for specific calculation patterns
    const calculationPatterns = [
      /(\d+)\s*(single|double|suite)\s*room/i,
      /(\d+)\s*month/i,
      /total.*?cost/i,
      /how much.*?(\d+)/i
    ];
    
    for (const pattern of calculationPatterns) {
      if (pattern.test(input)) {
        return {
          content: "I can help you calculate that! Could you please be more specific? For example:\n• 'How much for 2 single rooms?'\n• 'Cost for 3 months in a double room?'\n• 'Total for 1 suite for 6 months?'\n\nI'll give you a detailed breakdown with current pricing and availability.",
          suggestions: ['Room cost calculation', 'Multi-month pricing', 'Availability check', 'Payment methods']
        };
      }
    }
    
    // Learning response for unknown questions
    if (lowerInput.includes('what') || lowerInput.includes('how') || lowerInput.includes('when') || lowerInput.includes('where')) {
      return {
        content: "That's an interesting question! I want to make sure I give you the most accurate information. Could you please provide more details about what specifically you're asking about? This will help me give you a better answer or connect you with the right person who can help.\n\nI can assist with:\n• Room information and availability\n• Pricing and cost calculations\n• Booking process\n• Hostel facilities and rules\n• Payment methods\n\nOr I can connect you with our admin team for more specific queries.",
        suggestions: ['Ask Admin', 'Contact support', 'Room information', 'Booking help']
      };
    }
    
    // Check if it's a question that needs admin attention
    const adminKeywords = ['complaint', 'issue', 'problem', 'refund', 'cancel', 'change', 'modify', 'special', 'request'];
    const needsAdmin = adminKeywords.some(keyword => lowerInput.includes(keyword));
    
    if (needsAdmin) {
      return {
        content: "I understand you have a specific request or concern. For matters like complaints, special requests, refunds, or account changes, I'll need to connect you with our admin team who can provide personalized assistance.\n\nWould you like me to:\n• Direct you to the 'Ask Admin' feature\n• Help you with general information first\n• Connect you with our support team",
        suggestions: ['Ask Admin', 'Contact support', 'General info', 'Help']
      };
    }
    
    // Default learning response
    return {
      content: "I'm here to help you with Thika Mains Hostels! I'm constantly learning to provide better assistance. Could you please rephrase your question or be more specific about what you need help with?\n\nI can assist with:\n• Room information and availability\n• Pricing and cost calculations\n• Booking process and procedures\n• Hostel facilities and amenities\n• Payment methods and options\n• General questions about our services\n\nOr I can connect you with our admin team for more complex queries.",
      suggestions: ['Room information', 'Booking process', 'Ask Admin', 'Contact support']
    };
  };

  // Clear chat history
  const clearChatHistory = () => {
    setMessages([]);
  };

  // Handle key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <BackButton variant="both" className="mb-4" />
          <div className="flex items-center gap-3">
            <Bot className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">AI Assistant</h1>
            {isPreview && (
              <Badge variant="secondary" className="ml-2">
                Preview Mode
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground mt-2">
            Get help with your hostel-related questions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Chat with AI Assistant
                  {isPreview && (
                    <Badge variant="outline" className="ml-2">
                      {remainingPrompts} prompts left
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Messages */}
                <div className="h-96 overflow-y-auto space-y-4 mb-4 p-4 border rounded-lg">
                  {messages.length === 0 ? (
                    <div className="text-center text-muted-foreground">
                      <Bot className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Start a conversation with the AI assistant</p>
                      <p className="text-sm mt-2">Ask about rooms, booking, prices, or just say hello!</p>
                    </div>
                  ) : (
                    messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                            message.type === 'user'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          <p className="text-xs opacity-70 mt-1">
                            {message.timestamp.toLocaleTimeString()}
                          </p>
                          {message.suggestions && message.suggestions.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {message.suggestions.map((suggestion, index) => (
                                <button
                                  key={index}
                                  className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded mr-1 mb-1"
                                  onClick={() => setUserInput(suggestion)}
                                >
                                  {suggestion}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-muted rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                          <span className="text-sm">AI is thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="space-y-2">
                  {hasReachedLimit && (
                    <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <AlertCircle className="h-5 w-5 text-red-600" />
                      <p className="text-sm text-red-800">
                        You've reached your daily limit of 3 prompts. Please create a full account for unlimited access.
                      </p>
                    </div>
                  )}
                  
                  {showLimitWarning && !hasReachedLimit && (
                    <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <AlertCircle className="h-5 w-5 text-yellow-600" />
                      <p className="text-sm text-yellow-800">
                        {remainingPrompts} prompt{remainingPrompts !== 1 ? 's' : ''} remaining today
                      </p>
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <Input
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={hasReachedLimit ? "Prompt limit reached" : "Type your message..."}
                      disabled={isLoading || hasReachedLimit}
                      className="flex-1"
                    />
                    {hasReachedLimit ? (
                      <div className="flex items-center justify-center px-4 py-2 bg-red-100 border border-red-300 rounded-md">
                        <AlertCircle className="h-5 w-5 text-red-600" />
                      </div>
                    ) : (
                      <Button
                        onClick={handleSendMessage}
                        disabled={!userInput.trim() || isLoading}
                      >
                        {isLoading ? (
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("Tell me about rooms")}
                  disabled={hasReachedLimit}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Room Information
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("How do I book a room?")}
                  disabled={hasReachedLimit}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Booking Help
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("What are the prices?")}
                  disabled={hasReachedLimit}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Pricing Info
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("I need support")}
                  disabled={hasReachedLimit}
                >
                  <User className="h-4 w-4 mr-2" />
                  Get Support
                </Button>
              </CardContent>
            </Card>

            {/* Quick Calculations */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Calculations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("How many rooms are available?")}
                  disabled={hasReachedLimit}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Room Availability
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("Calculate monthly cost for 2 single rooms")}
                  disabled={hasReachedLimit}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Cost Calculator
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("What are the total rooms?")}
                  disabled={hasReachedLimit}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Total Rooms
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("What payment methods do you accept?")}
                  disabled={hasReachedLimit}
                >
                  <User className="h-4 w-4 mr-2" />
                  Payment Info
                </Button>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Common Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("Do you have WiFi?")}
                  disabled={hasReachedLimit}
                >
                  <Lightbulb className="h-4 w-4 mr-2" />
                  WiFi Info
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("What about security?")}
                  disabled={hasReachedLimit}
                >
                  <HelpCircle className="h-4 w-4 mr-2" />
                  Security
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("Is parking available?")}
                  disabled={hasReachedLimit}
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  Parking
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setUserInput("What are the hostel rules?")}
                  disabled={hasReachedLimit}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Hostel Rules
                </Button>
              </CardContent>
            </Card>

            {/* Clear Chat */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Chat Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={clearChatHistory}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear Chat History
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistantPage;