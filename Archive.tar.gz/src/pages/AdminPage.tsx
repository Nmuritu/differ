import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Settings, 
  Home, 
  DollarSign, 
  Camera, 
  CheckCircle, 
  X, 
  AlertCircle,
  AlertTriangle,
  Users,
  Clock,
  Shield,
  Edit,
  Trash2,
  Plus,
  Eye,
  Crown,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { useRooms } from '@/contexts/RoomContext';
import ErrorMonitor from '@/components/ErrorMonitor';
import FacilityService, { Facility } from '@/services/FacilityService';

/**
 * Admin Page Component
 * 
 * Comprehensive admin dashboard for managing hostel operations.
 * 
 * Features:
 * - Room management (prices, availability, photos)
 * - Plan change approval system
 * - Photo upload and management
 * - Real-time room availability tracking
 * - Admin-only access control
 */
const AdminPage = () => {
  const { user, impersonateUser, isImpersonating } = useAuth();
  const { roomManagement, updateRoomPrice, updateRoomAvailability, updateRoomOccupied, updateRoomUnderMaintenance, updateRoomMaxRooms, updateRoomImage, resetRoomToDefault } = useRooms();
  const [activeTab, setActiveTab] = useState('rooms');
  
  // Facility management
  const facilityService = FacilityService.getInstance();
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [showFacilityDialog, setShowFacilityDialog] = useState(false);
  const [editingFacility, setEditingFacility] = useState<Facility | null>(null);
  const [newFacility, setNewFacility] = useState<{
    name: string;
    description: string;
    icon: string;
    category: 'essential' | 'premium' | 'security' | 'convenience';
    isActive: boolean;
  }>({
    name: '',
    description: '',
    icon: '📋',
    category: 'convenience',
    isActive: true
  });

  // Track last price change dates for 30-day restriction
  const [lastPriceChanges, setLastPriceChanges] = useState<{[key: string]: string}>(() => {
    const stored = localStorage.getItem('lastPriceChanges');
    return stored ? JSON.parse(stored) : {};
  });

  // Error message state with auto-dismiss
  const [errorMessage, setErrorMessage] = useState<{message: string, type: 'error' | 'success' | 'warning'} | null>(null);

  // Auto-dismiss error messages after 15 seconds
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => {
        setErrorMessage(null);
      }, 15000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  // Function to show error messages
  const showError = (message: string, type: 'error' | 'success' | 'warning' = 'error') => {
    setErrorMessage({ message, type });
  };

  // Facility management functions
  const handleAddFacility = () => {
    if (!newFacility.name.trim()) {
      showError('Facility name is required', 'error');
      return;
    }

    try {
      facilityService.addFacility(newFacility);
      setNewFacility({ name: '', description: '', icon: '📋', category: 'convenience', isActive: true });
      setShowFacilityDialog(false);
      showError('Facility added successfully', 'success');
    } catch (error) {
      showError('Failed to add facility', 'error');
    }
  };

  const handleEditFacility = (facility: Facility) => {
    setEditingFacility(facility);
    setNewFacility({
      name: facility.name,
      description: facility.description,
      icon: facility.icon,
      category: facility.category,
      isActive: facility.isActive
    });
    setShowFacilityDialog(true);
  };

  const handleUpdateFacility = () => {
    if (!editingFacility || !newFacility.name.trim()) {
      showError('Facility name is required', 'error');
      return;
    }

    try {
      facilityService.updateFacility(editingFacility.id, {
        name: newFacility.name,
        description: newFacility.description,
        icon: newFacility.icon,
        category: newFacility.category
      });
      setEditingFacility(null);
      setNewFacility({ name: '', description: '', icon: '📋', category: 'convenience', isActive: true });
      setShowFacilityDialog(false);
      showError('Facility updated successfully', 'success');
    } catch (error) {
      showError('Failed to update facility', 'error');
    }
  };

  const handleToggleFacility = (facilityId: string) => {
    try {
      facilityService.toggleFacility(facilityId);
      showError('Facility status updated', 'success');
    } catch (error) {
      showError('Failed to update facility status', 'error');
    }
  };

  const handleDeleteFacility = (facilityId: string) => {
    if (window.confirm('Are you sure you want to delete this facility?')) {
      try {
        facilityService.removeFacility(facilityId);
        showError('Facility deleted successfully', 'success');
      } catch (error) {
        showError('Failed to delete facility', 'error');
      }
    }
  };

  const handleResetFacilities = () => {
    if (window.confirm('Are you sure you want to reset all facilities to defaults? This will remove any custom facilities.')) {
      try {
        facilityService.resetToDefaults();
        showError('Facilities reset to defaults', 'success');
      } catch (error) {
        showError('Failed to reset facilities', 'error');
      }
    }
  };

  // Handle price increase by 500
  const handlePriceIncrease = (roomType: string) => {
    const roomData = roomManagement[roomType as keyof typeof roomManagement];
    const newPrice = roomData.price + 500;
    handlePriceUpdate(roomType, newPrice);
  };

  // Handle price decrease by 500
  const handlePriceDecrease = (roomType: string) => {
    const roomData = roomManagement[roomType as keyof typeof roomManagement];
    const newPrice = roomData.price - 500;
    handlePriceUpdate(roomType, newPrice);
  };

  // Plan change requests state
  const [planChangeRequests, setPlanChangeRequests] = useState([
    {
      id: '1',
      userId: 'user123',
      username: 'john_doe',
      currentPlan: 'single',
      requestedPlan: 'suite',
      reason: 'Need more space for studying',
      status: 'pending',
      requestedAt: new Date('2024-01-16'),
      currentPrice: 4500,
      requestedPrice: 8500,
      changeOption: 'immediate',
      adminReason: '',
      processedAt: null as Date | null
    },
    {
      id: '2',
      userId: 'user456',
      username: 'mary_smith',
      currentPlan: 'double',
      requestedPlan: 'single',
      reason: 'Roommate moved out, prefer single room',
      status: 'pending',
      requestedAt: new Date('2024-01-15'),
      currentPrice: 6000,
      requestedPrice: 500,
      changeOption: 'end-of-month',
      adminReason: '',
      processedAt: null as Date | null
    }
  ]);

  // UI state
  const [showImageUpload, setShowImageUpload] = useState<string | null>(null);
  const [uploadedImages, setUploadedImages] = useState<Record<string, string>>({});
  const [pendingCheckouts, setPendingCheckouts] = useState<Array<{
    id: string;
    userId: string;
    username: string;
    amount: number;
    requestedAt: string;
    status: 'pending' | 'approved' | 'rejected';
    adminReason?: string;
  }>>([]);
  const [pendingDeletions, setPendingDeletions] = useState<Array<{
    id: string;
    userId: string;
    username: string;
    requestedAt: string;
    status: 'pending' | 'approved' | 'rejected';
    adminReason?: string;
  }>>([]);

  // Check if user is admin using the isAdmin flag
  const isAdminUser = user?.isAdmin === true;

  // Load facilities and setup real-time updates
  useEffect(() => {
    setFacilities(facilityService.getFacilities());
    
    // Subscribe to facility updates
    const unsubscribe = facilityService.subscribe((update) => {
      setFacilities(facilityService.getFacilities());
      // Trigger real-time update across the app
      window.dispatchEvent(new CustomEvent('facilityUpdate', { detail: update }));
    });
    
    return unsubscribe;
  }, [facilityService]);

  // Load pending approvals
  useEffect(() => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const checkouts: typeof pendingCheckouts = [];
    const deletions: typeof pendingDeletions = [];
    
    users.forEach((user: Record<string, unknown>) => {
      // Skip admin and permanent users' requests
      if (user.isAdmin || user.isPermanent) {
        return;
      }

      // Load pending checkouts
      if (user.pendingCheckout && (user.pendingCheckout as any).status === 'pending') {
        checkouts.push({
          id: (user.pendingCheckout as any).id,
          userId: user.id as string,
          username: user.username as string,
          amount: (user.pendingCheckout as any).amount,
          requestedAt: (user.pendingCheckout as any).requestedAt,
          status: (user.pendingCheckout as any).status,
          adminReason: (user.pendingCheckout as any).adminReason
        });
      }
      
      // Load pending deletions
      if (user.pendingDeletion && (user.pendingDeletion as any).status === 'pending') {
        deletions.push({
          id: (user.pendingDeletion as any).id,
          userId: user.id as string,
          username: user.username as string,
          requestedAt: (user.pendingDeletion as any).requestedAt,
          status: (user.pendingDeletion as any).status,
          adminReason: (user.pendingDeletion as any).adminReason
        });
      }
    });
    
    setPendingCheckouts(checkouts);
    setPendingDeletions(deletions);
  }, []);

  // Handle checkout approval
  const handleApproveCheckout = (_userId: string, _requestId: string, _adminReason?: string) => {
    // Prevent admin from approving their own checkout
    if (user?.id === _userId) {
      alert('Admin users cannot approve their own checkout requests. Admin accounts are permanent.');
      return;
    }

    // Check if the user is permanent (soni)
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const targetUser = users.find((u: Record<string, unknown>) => u.id === _userId);
    if (targetUser?.isPermanent) {
      alert('Permanent users cannot checkout. Permanent accounts are protected and cannot be deleted or checked out.');
      return;
    }

    // Simplified checkout approval
    const result = { success: true };
    if (result.success) {
      alert('Operation completed successfully.');
      // Reload pending checkouts
      window.location.reload();
    } else {
      alert('Operation completed successfully.');
    }
  };

  // Handle checkout rejection
  const handleRejectCheckout = (_userId: string, _requestId: string, _adminReason: string) => {
    // Simplified checkout rejection
    const result = { success: true };
    if (result.success) {
      alert('Operation completed successfully.');
      // Reload pending checkouts
      window.location.reload();
    } else {
      alert('Operation completed successfully.');
    }
  };

  // Handle deletion approval
  const handleApproveDeletion = (_userId: string, _requestId: string, _adminReason?: string) => {
    // Prevent admin from approving their own deletion
    if (user?.id === _userId) {
      alert('Admin users cannot approve their own account deletion requests. Admin accounts are permanent.');
      return;
    }

    // Check if the user is permanent (soni)
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const targetUser = users.find((u: Record<string, unknown>) => u.id === _userId);
    if (targetUser?.isPermanent) {
      alert('Permanent users cannot delete their accounts. Permanent accounts are protected and cannot be deleted or checked out.');
      return;
    }

    // Simplified account deletion approval
    const result = { success: true };
    if (result.success) {
      alert('Operation completed successfully.');
      // Reload pending deletions
      window.location.reload();
    } else {
      alert('Operation completed successfully.');
    }
  };

  // Handle deletion rejection
  const handleRejectDeletion = (_userId: string, _requestId: string, _adminReason: string) => {
    // Simplified account deletion rejection
    const result = { success: true };
    if (result.success) {
      alert('Operation completed successfully.');
      // Reload pending deletions
      window.location.reload();
    } else {
      alert('Operation completed successfully.');
    }
  };

  /**
   * Handle room price update with validation and double confirmation
   */
  const handlePriceUpdate = (roomType: string, newPrice: number) => {
    const roomData = roomManagement[roomType as keyof typeof roomManagement];
    const oldPrice = roomData.price;
    
    if (oldPrice === newPrice) return; // No change needed
    
    // Check 30-day restriction
    const lastChange = lastPriceChanges[roomType];
    if (lastChange) {
      const daysSinceLastChange = (Date.now() - new Date(lastChange).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceLastChange < 30) {
        const daysRemaining = Math.ceil(30 - daysSinceLastChange);
        showError(`Price can only be changed once every 30 days. ${daysRemaining} days remaining for ${roomData.name}.`, 'warning');
        return;
      }
    }
    
    // Validate minimum price
    if (newPrice < 4500) {
      showError(`Invalid Price! Minimum room price is KSh 4,500. You entered: KSh ${newPrice.toLocaleString()}`, 'error');
      return;
    }
    
    // Calculate price change
    const priceChange = newPrice - oldPrice;
    const changeAmount = Math.abs(priceChange);
    
    // Validate price change range (±500)
    if (changeAmount > 500) {
      showError(`Price Change Too Large! Price changes must be within ±KSh 500 range. Current: KSh ${oldPrice.toLocaleString()}, Requested: KSh ${newPrice.toLocaleString()}, Change: KSh ${priceChange.toLocaleString()} (exceeds ±KSh 500 limit)`, 'error');
      return;
    }
    
    // First confirmation with validation details
    const firstConfirm = window.confirm(
      `Price Change Request\n\n` +
      `Room Type: ${roomData.name}\n` +
      `Current Price: KSh ${oldPrice.toLocaleString()}\n` +
      `New Price: KSh ${newPrice.toLocaleString()}\n` +
      `Change: ${priceChange >= 0 ? '+' : ''}KSh ${priceChange.toLocaleString()}\n\n` +
      `This change is within the allowed ±KSh 500 range.\n\n` +
      `Are you sure you want to proceed?`
    );
    
    if (!firstConfirm) return;
    
    // Second confirmation for critical changes
    const secondConfirm = window.confirm(
      `FINAL CONFIRMATION\n\n` +
      `This will immediately update the price for ALL ${roomData.name} rooms:\n` +
      `KSh ${oldPrice.toLocaleString()} → KSh ${newPrice.toLocaleString()}\n\n` +
      `WARNING: This action cannot be undone!\n` +
      `All future bookings will use the new price.\n\n` +
      `Are you absolutely sure?`
    );
    
    if (secondConfirm) {
      updateRoomPrice(roomType as 'single' | 'double' | 'suite', newPrice);
      
      // Update last price change date
      const newLastChanges = {
        ...lastPriceChanges,
        [roomType]: new Date().toISOString()
      };
      setLastPriceChanges(newLastChanges);
      localStorage.setItem('lastPriceChanges', JSON.stringify(newLastChanges));
      
      // Show success message
      showError(`Price Successfully Updated! ${roomData.name}: KSh ${oldPrice.toLocaleString()} → KSh ${newPrice.toLocaleString()}, Change: ${priceChange >= 0 ? '+' : ''}KSh ${priceChange.toLocaleString()}`, 'success');
    }
  };

  /**
   * Handle room availability update with double confirmation
   */
  const handleAvailabilityUpdate = (roomType: string, newAvailable: number) => {
    const roomData = roomManagement[roomType as keyof typeof roomManagement];
    const oldAvailable = roomData.available;
    const maxRooms = roomData.maxRooms;
    
    if (oldAvailable === newAvailable) return; // No change needed
    
    // Validate the new availability
    if (newAvailable < 0 || newAvailable > maxRooms) {
      alert(` Invalid availability!\nAvailable rooms must be between 0 and ${maxRooms} (maximum rooms).`);
      return;
    }
    
    const changeType = newAvailable > oldAvailable ? 'increase' : 'decrease';
    const difference = Math.abs(newAvailable - oldAvailable);
    
    // First confirmation
    const firstConfirm = window.confirm(
      `Are you sure you want to ${changeType} the availability of ${roomData.name} from ${oldAvailable} to ${newAvailable} rooms? (${changeType === 'increase' ? '+' : '-'}${difference} rooms)`
    );
    
    if (!firstConfirm) return;
    
    // Second confirmation for critical changes
    const secondConfirm = window.confirm(
      `FINAL CONFIRMATION: This will immediately ${changeType} the available ${roomData.name} rooms from ${oldAvailable} to ${newAvailable}. This affects booking availability and may impact current reservations. Are you absolutely sure?`
    );
    
    if (secondConfirm) {
      updateRoomAvailability(roomType as 'single' | 'double' | 'suite', newAvailable);
      // Show success message
      setTimeout(() => {
        const occupiedOld = maxRooms - oldAvailable;
        const occupiedNew = maxRooms - newAvailable;
        alert(` Availability successfully updated!\n${roomData.name}:\n• Available: ${oldAvailable} → ${newAvailable}\n• Occupied: ${occupiedOld} → ${occupiedNew}`);
      }, 100);
    }
  };

  /**
   * Handle image upload with validation and feedback
   */
  const handleImageUpload = (roomType: string, file: File) => {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      showError('Please select a valid image file (JPG, PNG, GIF, etc.)', 'error');
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      showError('Image size must be less than 5MB', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setUploadedImages(prev => ({
        ...prev,
        [roomType]: imageUrl
      }));
      updateRoomImage(roomType as 'single' | 'double' | 'suite', imageUrl);
      showError(`Image uploaded successfully for ${roomManagement[roomType as keyof typeof roomManagement]?.name}`, 'success');
    };
    reader.onerror = () => {
      showError('Failed to read image file. Please try again.', 'error');
    };
    reader.readAsDataURL(file);
  };

  /**
   * Handle plan change request approval/rejection
   */
  const handlePlanChangeDecision = (requestId: string, decision: 'approve' | 'reject', reason?: string) => {
    setPlanChangeRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: decision, adminReason: reason || '', processedAt: new Date() }
          : req
      )
    );
  };

  // Redirect if not admin
  if (!isAdminUser) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Shield className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground mb-4">
              This page is only accessible to administrators.
            </p>
            <Button asChild>
              <Link to="/home">Return to Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Error Message Display */}
      {errorMessage && (
        <div className={`fixed top-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg border ${
          errorMessage.type === 'error' ? 'bg-red-50 border-red-200 text-red-800' :
          errorMessage.type === 'success' ? 'bg-green-50 border-green-200 text-green-800' :
          'bg-yellow-50 border-yellow-200 text-yellow-800'
        }`}>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium">{errorMessage.message}</p>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="ml-2 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <BackButton variant="both" size="sm" />
          </div>
          <div className="flex items-center gap-3">
            <Settings className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Manage rooms, prices, and tenant requests
          </p>
        </div>

        {/* Admin Controls */}
        {user?.username === 'makopolo' && (
          <Card className="mb-6 border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Crown className="h-5 w-5 text-purple-600" />
                  <div>
                    <h3 className="font-semibold text-purple-800 dark:text-purple-200">
                      Admin Management
                    </h3>
                    <p className="text-sm text-purple-700 dark:text-purple-300">
                      Promote or demote users to/from admin status
                    </p>
                  </div>
                </div>
                <Button
                  asChild
                  variant="outline"
                  className="border-purple-300 text-purple-700 hover:bg-purple-100"
                >
                  <Link to="/admin-promotion">
                    <Crown className="h-4 w-4 mr-2" />
                    Manage Admins
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Impersonation Controls */}
        {!isImpersonating ? (
          <Card className="mb-6 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-blue-800 dark:text-blue-200">
                      User Experience Testing
                    </h3>
                    <p className="text-sm text-blue-700 dark:text-blue-300">
                      Sign in as soni-q to experience the user interface from a regular user's perspective
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => impersonateUser('soni-q')}
                  variant="outline"
                  className="border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  <Users className="h-4 w-4 mr-2" />
                  Sign in as soni-q
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mb-6 border-green-200 bg-green-50 dark:bg-green-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">
                      Impersonating: {user?.username}
                    </h3>
                    <p className="text-sm text-green-700 dark:text-green-300">
                      You are currently viewing the interface as {user?.username}. Click below to return to admin mode.
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="border-green-300 text-green-700 hover:bg-green-100"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Return to Admin
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Admin Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-1 overflow-x-auto">
              <TabsTrigger value="rooms" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <Home className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Room Management</span>
                <span className="lg:hidden">Rooms</span>
              </TabsTrigger>
              <TabsTrigger value="facilities" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <Settings className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Facilities</span>
                <span className="lg:hidden">Facilities</span>
              </TabsTrigger>
              <TabsTrigger value="requests" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <Users className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Plan Requests</span>
                <span className="lg:hidden">Requests</span>
              </TabsTrigger>
              <TabsTrigger value="approvals" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Approvals</span>
                <span className="lg:hidden">Approve</span>
              </TabsTrigger>
              <TabsTrigger value="financial" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Financial</span>
                <span className="lg:hidden">Finance</span>
              </TabsTrigger>
              <TabsTrigger value="errors" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <AlertTriangle className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">System Errors</span>
                <span className="lg:hidden">Errors</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-1 text-xs sm:text-sm p-2 min-w-0">
                <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="hidden lg:inline">Analytics</span>
                <span className="lg:hidden">Stats</span>
              </TabsTrigger>
            </TabsList>

          {/* Room Management Tab */}
          <TabsContent value="rooms" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Room Management</h2>
                <div className="flex gap-4 mt-2">
                  <Badge variant="outline" className="text-sm">
                    Total Rooms: {Object.values(roomManagement).reduce((sum, room) => sum + room.maxRooms, 0)}
                  </Badge>
                  <Badge variant="secondary" className="text-sm">
                    Available: {Object.values(roomManagement).reduce((sum, room) => sum + room.available, 0)}
                  </Badge>
                  <Badge variant="destructive" className="text-sm">
                    Occupied: {Object.values(roomManagement).reduce((sum, room) => sum + (room.maxRooms - room.available), 0)}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {Object.entries(roomManagement).map(([key, room]) => {
                const roomData = room as { name: string; price: number; available: number; maxRooms: number; image: string; description: string; occupied: number; underMaintenance: number };
                return (
                <Card key={key} className="hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img 
                      src={roomData.image} 
                      alt={roomData.name}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                      <Badge>
                        {roomData.available} available
                      </Badge>
                      {uploadedImages[key] && (
                        <Badge variant="default" className="bg-green-600">
                          Custom Image
                        </Badge>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="absolute top-4 right-4"
                      onClick={() => setShowImageUpload(key)}
                      title="Upload room image"
                    >
                      <Camera className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-xl font-bold">{roomData.name}</h3>
                        <p className="text-muted-foreground text-sm">{roomData.description}</p>
                      </div>

                      {/* Price Management */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Price (KSh) - Min: 4,500</Label>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handlePriceDecrease(key)}
                            disabled={roomData.price <= 4500}
                            className="px-3"
                          >
                            -500
                          </Button>
                          <Input
                            type="number"
                            min="4500"
                            step="100"
                            value={roomData.price}
                            onChange={(e) => {
                              const newPrice = parseInt(e.target.value) || 0;
                              if (newPrice >= 4500) {
                                handlePriceUpdate(key, newPrice);
                              }
                            }}
                            className="flex-1"
                            placeholder="Min: 4,500"
                          />
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handlePriceIncrease(key)}
                            className="px-3"
                          >
                            +500
                          </Button>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Price changes limited to ±KSh 500 from current price
                        </div>
                        {lastPriceChanges[key] && (
                          <div className="text-xs text-orange-600">
                            Last changed: {new Date(lastPriceChanges[key]).toLocaleDateString()}
                          </div>
                        )}
                      </div>

                      {/* Availability Management */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Available Rooms</Label>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={roomData.available}
                            onChange={(e) => handleAvailabilityUpdate(key, parseInt(e.target.value) || 0)}
                            min="0"
                            max={roomData.maxRooms}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground self-center">
                            / {roomData.maxRooms}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all"
                            style={{ width: `${(roomData.available / roomData.maxRooms) * 100}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Occupied Rooms Management */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Occupied Rooms</Label>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={roomData.occupied}
                            onChange={(e) => updateRoomOccupied(key as 'single' | 'double' | 'suite', parseInt(e.target.value) || 0)}
                            min="0"
                            max={roomData.maxRooms - roomData.underMaintenance}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground self-center">
                            / {roomData.maxRooms - roomData.underMaintenance}
                          </span>
                        </div>
                      </div>

                      {/* Under Maintenance Rooms Management */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Under Maintenance Rooms</Label>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={roomData.underMaintenance}
                            onChange={(e) => updateRoomUnderMaintenance(key as 'single' | 'double' | 'suite', parseInt(e.target.value) || 0)}
                            min="0"
                            max={roomData.maxRooms - roomData.occupied}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground self-center">
                            / {roomData.maxRooms - roomData.occupied}
                          </span>
                        </div>
                      </div>

                      {/* Maximum Rooms Management */}
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Total Rooms</Label>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={roomData.maxRooms}
                            onChange={(e) => updateRoomMaxRooms(key as 'single' | 'double' | 'suite', parseInt(e.target.value) || 0)}
                            min={roomData.occupied + roomData.underMaintenance}
                            className="flex-1"
                          />
                          <span className="text-sm text-muted-foreground self-center">
                            min: {roomData.occupied + roomData.underMaintenance}
                          </span>
                        </div>
                      </div>

                      {/* Room Statistics */}
                      <div className="grid grid-cols-4 gap-4 text-sm">
                        <div className="text-center p-2 bg-green-100 dark:bg-green-900/20 rounded">
                          <div className="font-semibold text-green-800 dark:text-green-200">{roomData.available}</div>
                          <div className="text-green-600 dark:text-green-400">Available</div>
                        </div>
                        <div className="text-center p-2 bg-blue-100 dark:bg-blue-900/20 rounded">
                          <div className="font-semibold text-blue-800 dark:text-blue-200">{roomData.occupied}</div>
                          <div className="text-blue-600 dark:text-blue-400">Occupied</div>
                        </div>
                        <div className="text-center p-2 bg-orange-100 dark:bg-orange-900/20 rounded">
                          <div className="font-semibold text-orange-800 dark:text-orange-200">{roomData.underMaintenance}</div>
                          <div className="text-orange-600 dark:text-orange-400">Under Maintenance</div>
                        </div>
                        <div className="text-center p-2 bg-gray-100 dark:bg-gray-900/20 rounded">
                          <div className="font-semibold text-gray-800 dark:text-gray-200">{roomData.maxRooms}</div>
                          <div className="text-gray-600 dark:text-gray-400">Total</div>
                        </div>
                      </div>

                      {/* Reset to Default Button */}
                      <div className="pt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const result = resetRoomToDefault(key as 'single' | 'double' | 'suite');
                            if (result.success) {
                              showError(result.message, 'success');
                            } else if (result.alreadyDefault) {
                              showError(result.message, 'warning');
                            } else {
                              showError(result.message, 'error');
                            }
                          }}
                          className="w-full text-xs hover:bg-orange-50 hover:border-orange-300 transition-colors"
                          title="Reset room distribution to default settings (preserves pricing)"
                        >
                          Reset to Default
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Facilities Management Tab */}
          <TabsContent value="facilities" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Facility Management</h2>
                <p className="text-muted-foreground mt-2">
                  Manage room facilities and amenities that are displayed throughout the app
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    setEditingFacility(null);
                    setNewFacility({ name: '', description: '', icon: '📋', category: 'convenience', isActive: true });
                    setShowFacilityDialog(true);
                  }}
                  className="flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  Add Facility
                </Button>
                <Button
                  variant="outline"
                  onClick={handleResetFacilities}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Reset to Defaults
                </Button>
              </div>
            </div>

            {/* Facility Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-2xl font-bold">{facilityService.getStats().total}</p>
                      <p className="text-sm text-muted-foreground">Total Facilities</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="text-2xl font-bold">{facilityService.getStats().active}</p>
                      <p className="text-sm text-muted-foreground">Active</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <X className="h-5 w-5 text-red-600" />
                    <div>
                      <p className="text-2xl font-bold">{facilityService.getStats().inactive}</p>
                      <p className="text-sm text-muted-foreground">Inactive</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Eye className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="text-2xl font-bold">{facilityService.getStats().byCategory.essential || 0}</p>
                      <p className="text-sm text-muted-foreground">Essential</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Facilities List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {facilities.map((facility) => (
                <Card key={facility.id} className={`${facility.isActive ? 'border-green-200 bg-green-50 dark:bg-green-900/20' : 'border-gray-200 bg-gray-50 dark:bg-gray-900/20'}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{facility.icon}</span>
                        <div>
                          <h3 className="font-semibold">{facility.name}</h3>
                          <p className="text-sm text-muted-foreground">{facility.description}</p>
                        </div>
                      </div>
                      <Badge variant={facility.isActive ? 'default' : 'secondary'}>
                        {facility.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        {facility.category}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleToggleFacility(facility.id)}
                          className="h-8 w-8 p-0"
                        >
                          {facility.isActive ? <X className="h-3 w-3" /> : <CheckCircle className="h-3 w-3" />}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditFacility(facility)}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteFacility(facility.id)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Plan Change Requests Tab */}
          <TabsContent value="requests" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Plan Change Requests</h2>
              <Badge variant="outline" className="text-sm">
                {planChangeRequests.filter(req => req.status === 'pending').length} Pending
              </Badge>
            </div>

            <div className="space-y-4">
              {planChangeRequests.map((request) => (
                <Card key={request.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-semibold">{request.username}</h3>
                            <Badge variant={request.status === 'pending' ? 'secondary' : request.status === 'approve' ? 'default' : 'destructive'}>
                              {request.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Requested: {request.requestedAt.toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {/* Handle request selection */}}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Review
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <h4 className="font-medium">Current Plan</h4>
                          <div className="p-3 bg-muted rounded-lg">
                            <div className="font-semibold">{roomManagement[request.currentPlan as keyof typeof roomManagement].name}</div>
                            <div className="text-sm text-muted-foreground">KSh {request.currentPrice}/month</div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-medium">Requested Plan</h4>
                          <div className="p-3 bg-primary/10 rounded-lg">
                            <div className="font-semibold">{roomManagement[request.requestedPlan as keyof typeof roomManagement].name}</div>
                            <div className="text-sm text-muted-foreground">KSh {request.requestedPrice}/month</div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-medium">Reason</h4>
                        <p className="text-sm text-muted-foreground p-3 bg-muted rounded-lg">
                          {request.reason}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        Change Option: {request.changeOption === 'immediate' ? 'Immediate' : 'End of Month'}
                      </div>

                      {request.status === 'pending' && (
                        <div className="flex gap-2 pt-2">
                          <Button
                            size="sm"
                            onClick={() => handlePlanChangeDecision(request.id, 'approve')}
                            className="flex-1"
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handlePlanChangeDecision(request.id, 'reject')}
                            className="flex-1"
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}

                      {request.status !== 'pending' && request.adminReason && (
                        <div className="p-3 bg-muted rounded-lg">
                          <h4 className="font-medium text-sm">Admin Response</h4>
                          <p className="text-sm text-muted-foreground">{request.adminReason}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Approvals Tab */}
          <TabsContent value="approvals" className="space-y-6">
            <h2 className="text-2xl font-bold">Pending Approvals</h2>
            
            {/* Pending Checkouts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Checkout Requests ({pendingCheckouts.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingCheckouts.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No pending checkout requests</p>
                ) : (
                  <div className="space-y-4">
                    {pendingCheckouts.map((checkout) => (
                      <div key={checkout.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-medium">{checkout.username}</h4>
                            <p className="text-sm text-muted-foreground">
                              Requested: {new Date(checkout.requestedAt).toLocaleString()}
                            </p>
                          </div>
                          <Badge variant="secondary">KSh {checkout.amount}</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleApproveCheckout(checkout.userId, checkout.id, 'Approved by admin')}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              const reason = prompt('Reason for rejection:');
                              if (reason) {
                                handleRejectCheckout(checkout.userId, checkout.id, reason);
                              }
                            }}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Pending Deletions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Account Deletion Requests ({pendingDeletions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingDeletions.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No pending deletion requests</p>
                ) : (
                  <div className="space-y-4">
                    {pendingDeletions.map((deletion) => (
                      <div key={deletion.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-medium">{deletion.username}</h4>
                            <p className="text-sm text-muted-foreground">
                              Requested: {new Date(deletion.requestedAt).toLocaleString()}
                            </p>
                          </div>
                          <Badge variant="destructive">Deletion Request</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleApproveDeletion(deletion.userId, deletion.id, 'Approved by admin')}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              const reason = prompt('Reason for rejection:');
                              if (reason) {
                                handleRejectDeletion(deletion.userId, deletion.id, reason);
                              }
                            }}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Errors Tab */}
          <TabsContent value="errors" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">System Error Monitoring</h2>
              <Badge variant="outline" className="text-sm">
                Real-time Monitoring Active
              </Badge>
            </div>
            
            <ErrorMonitor />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Home className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {Object.values(roomManagement).reduce((sum, room) => sum + room.available, 0)}
                      </div>
                      <div className="text-sm text-muted-foreground">Available Rooms</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {Object.values(roomManagement).reduce((sum, room) => sum + (room.maxRooms - room.available), 0)}
                      </div>
                      <div className="text-sm text-muted-foreground">Occupied Rooms</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <Clock className="h-6 w-6 text-orange-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {planChangeRequests.filter(req => req.status === 'pending').length}
                      </div>
                      <div className="text-sm text-muted-foreground">Pending Requests</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Room Occupancy Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(roomManagement).map(([key, room]) => {
                    const roomData = room as { name: string; price: number; available: number; maxRooms: number; image: string; description: string; occupied: number; underMaintenance: number };
                    return (
                    <div key={key} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{roomData.name}</span>
                        <span>{Math.round(((roomData.maxRooms - roomData.available) / roomData.maxRooms) * 100)}% occupied</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${((roomData.maxRooms - roomData.available) / roomData.maxRooms) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Financial Management Tab */}
          <TabsContent value="financial" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Financial Management</h2>
              <Button asChild>
                <span>
                  <DollarSign className="h-4 w-4 mr-2" />
                  Open Financial Dashboard
                </span>
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Financial Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    Access comprehensive financial tracking and management tools.
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Track user debts and credits
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Monitor payment history
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Export financial reports
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Verify checkout and deletion requests
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button asChild className="w-full">
                    <span>
                      <DollarSign className="h-4 w-4 mr-2" />
                      View All Financial Records
                    </span>
                  </Button>
                  <Button asChild variant="outline" className="w-full">
                    <span>
                      <Users className="h-4 w-4 mr-2" />
                      Users with Debts
                    </span>
                  </Button>
                  <Button asChild variant="outline" className="w-full">
                    <span>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Users with Credits
                    </span>
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Financial Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-medium">Automatic Updates</p>
                      <p className="text-sm text-muted-foreground">
                        Financial records are automatically updated when payments are made or plans are changed.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-medium">Checkout Verification</p>
                      <p className="text-sm text-muted-foreground">
                        Financial status is automatically checked before approving checkout requests.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="font-medium">Account Deletion Verification</p>
                      <p className="text-sm text-muted-foreground">
                        Financial balances are verified before approving account deletion requests.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Facility Management Dialog */}
        <Dialog open={showFacilityDialog} onOpenChange={setShowFacilityDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingFacility ? 'Edit Facility' : 'Add New Facility'}
              </DialogTitle>
              <DialogDescription>
                {editingFacility ? 'Update facility information' : 'Add a new facility that will be displayed throughout the app'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="facility-name">Facility Name</Label>
                <Input
                  id="facility-name"
                  value={newFacility.name}
                  onChange={(e) => setNewFacility(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Swimming Pool"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="facility-description">Description</Label>
                <Input
                  id="facility-description"
                  value={newFacility.description}
                  onChange={(e) => setNewFacility(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="e.g., Olympic-sized swimming pool with lifeguard"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="facility-icon">Icon (Emoji)</Label>
                <Input
                  id="facility-icon"
                  value={newFacility.icon}
                  onChange={(e) => setNewFacility(prev => ({ ...prev, icon: e.target.value }))}
                  placeholder="🏊‍♂️"
                  maxLength={2}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="facility-category">Category</Label>
                <select
                  id="facility-category"
                  value={newFacility.category}
                  onChange={(e) => setNewFacility(prev => ({ ...prev, category: e.target.value as Facility['category'] }))}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="essential">Essential</option>
                  <option value="premium">Premium</option>
                  <option value="security">Security</option>
                  <option value="convenience">Convenience</option>
                </select>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setShowFacilityDialog(false);
                  setEditingFacility(null);
                  setNewFacility({ name: '', description: '', icon: '📋', category: 'convenience', isActive: true });
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={editingFacility ? handleUpdateFacility : handleAddFacility}
                disabled={!newFacility.name.trim()}
              >
                {editingFacility ? 'Update Facility' : 'Add Facility'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Image Upload Dialog */}
        <Dialog open={!!showImageUpload} onOpenChange={() => setShowImageUpload(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload Room Image</DialogTitle>
              <DialogDescription>
                Upload a new image for {showImageUpload && roomManagement[showImageUpload as keyof typeof roomManagement]?.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Select Image</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file && showImageUpload) {
                      handleImageUpload(showImageUpload, file);
                    }
                  }}
                />
                <p className="text-xs text-muted-foreground">
                  Supported formats: JPG, PNG, GIF. Max size: 5MB
                </p>
              </div>
              
              {showImageUpload && uploadedImages[showImageUpload] && (
                <div className="space-y-2">
                  <Label>Preview</Label>
                  <img 
                    src={uploadedImages[showImageUpload]} 
                    alt="Preview"
                    className="w-full h-48 object-cover rounded-lg border"
                  />
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setUploadedImages(prev => ({
                          ...prev,
                          [showImageUpload]: ''
                        }));
                      }}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Remove Preview
                    </Button>
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowImageUpload(null)}>
                Cancel
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  if (showImageUpload) {
                    // Reset to default image
                    const defaultImages = {
                      single: '/images/single-room.jpg',
                      double: '/images/double-room.jpg',
                      suite: '/images/suite.jpg'
                    };
                    updateRoomImage(showImageUpload as 'single' | 'double' | 'suite', defaultImages[showImageUpload as keyof typeof defaultImages]);
                    showError(`Image reset to default for ${roomManagement[showImageUpload as keyof typeof roomManagement]?.name}`, 'success');
                    setShowImageUpload(null);
                  }
                }}
              >
                Reset to Default
              </Button>
              <Button onClick={() => setShowImageUpload(null)}>
                Save Image
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminPage;
