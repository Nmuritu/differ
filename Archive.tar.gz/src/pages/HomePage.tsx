import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Wifi, 
  Car, 
  Shield, 
  Clock, 
  Users, 
  MapPin,
  Star,
  ArrowRight,
  BookOpen,
  Bot,
  MessageSquare,
  HelpCircle
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useRooms } from '@/contexts/RoomContext';
import { useAuth } from '@/contexts/NewAuthContext';

const HomePage = () => {
  const [mounted, setMounted] = useState(false);
  const { roomManagement } = useRooms();
  const { isAdmin, isImpersonating } = useAuth();

  useEffect(() => {
    setMounted(true);
  }, []);

  const features = [
    {
      icon: <Wifi className="h-6 w-6" />,
      title: "Free Wi-Fi",
      description: "High-speed internet in all rooms"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "24/7 Security",
      description: "Safe and secure environment"
    },
    {
      icon: <Car className="h-6 w-6" />,
      title: "Parking",
      description: "Secure parking space available"
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Flexible Terms",
      description: "Monthly and semester bookings"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Mwangi",
      review: "Great facilities and very affordable. The Wi-Fi is excellent for my studies!",
      rating: 5
    },
    {
      name: "David Kiprotich",
      review: "Clean rooms and friendly staff. Perfect location near the campus.",
      rating: 5
    },
    {
      name: "Grace Njeri",
      review: "Safe environment and 24/7 security. My parents feel comfortable with me staying here.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className={`relative bg-hero-gradient text-white py-20 transition-all duration-1000 ${
        mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}>
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Welcome to Thika Mains Hostels
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90">
              Comfortable, affordable student accommodation in the heart of Thika. 
              Your home away from home.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="hero-button text-lg px-8">
                <Link to="/rooms">
                  View Rooms
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" className="outline-button text-lg px-8">
                <Link to="/booking">Book Now</Link>
              </Button>
              <Button asChild size="lg" className="secondary-button text-lg px-8">
                <Link to="/settings">Settings</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Thika Mains Hostels?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We provide everything you need for a comfortable and productive stay
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-card-hover transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="text-primary mb-4 flex justify-center">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Room Types Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Room Options</h2>
            <p className="text-lg text-muted-foreground">Choose the perfect room for your needs</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Single Room */}
            <Card className="hover:shadow-card-hover transition-all duration-300">
              <div className="relative">
                <img 
                  src={roomManagement.single.image} 
                  alt="Single Room"
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4">Most Popular</Badge>
                <Badge variant="outline" className="absolute top-4 right-4 bg-white/90 text-black">
                  {roomManagement.single.available} rooms available
                </Badge>
              </div>
              <CardContent className="p-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Single Room</h3>
                  <p className="text-3xl font-bold text-primary mb-4">KSh {roomManagement.single.price.toLocaleString()}</p>
                  <p className="text-muted-foreground mb-4">Perfect for individual students who value privacy</p>
                  <ul className="text-sm space-y-2 mb-6">
                    <li className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-primary" />
                      Single occupancy
                    </li>
                    <li className="flex items-center gap-2">
                      <Wifi className="h-4 w-4 text-primary" />
                      Free Wi-Fi
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      24/7 Security
                    </li>
                  </ul>
                  <Button asChild className="w-full">
                    <Link to="/rooms">View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Double Room */}
            <Card className="hover:shadow-card-hover transition-all duration-300">
              <div className="relative">
                <img 
                  src={roomManagement.double.image} 
                  alt="Double Room"
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge variant="outline" className="absolute top-4 right-4 bg-white/90 text-black">
                  {roomManagement.double.available} rooms available
                </Badge>
              </div>
              <CardContent className="p-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Double Room</h3>
                  <p className="text-3xl font-bold text-primary mb-4">KSh {roomManagement.double.price.toLocaleString()}</p>
                  <p className="text-muted-foreground mb-4">Share with a friend and save on costs</p>
                  <ul className="text-sm space-y-2 mb-6">
                    <li className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-primary" />
                      Double occupancy
                    </li>
                    <li className="flex items-center gap-2">
                      <Wifi className="h-4 w-4 text-primary" />
                      Free Wi-Fi
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      24/7 Security
                    </li>
                  </ul>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/rooms">View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Suite */}
            <Card className="hover:shadow-card-hover transition-all duration-300">
              <div className="relative">
                <img 
                  src={roomManagement.suite.image} 
                  alt="Suite"
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge variant="secondary" className="absolute top-4 left-4">Premium</Badge>
                <Badge variant="outline" className="absolute top-4 right-4 bg-white/90 text-black">
                  {roomManagement.suite.available} rooms available
                </Badge>
              </div>
              <CardContent className="p-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Suite</h3>
                  <p className="text-3xl font-bold text-primary mb-4">KSh {roomManagement.suite.price.toLocaleString()}</p>
                  <p className="text-muted-foreground mb-4">Luxurious accommodation with extra amenities</p>
                  <ul className="text-sm space-y-2 mb-6">
                    <li className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-primary" />
                      Up to 2 occupants
                    </li>
                    <li className="flex items-center gap-2">
                      <Wifi className="h-4 w-4 text-primary" />
                      Premium Wi-Fi
                    </li>
                    <li className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      24/7 Security
                    </li>
                  </ul>
                  <Button asChild variant="secondary" className="w-full">
                    <Link to="/rooms">View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Students Say</h2>
            <p className="text-lg text-muted-foreground">Don't just take our word for it</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-secondary text-secondary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">"{testimonial.review}"</p>
                  <p className="font-semibold">- {testimonial.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Need Help?</h2>
            <p className="text-lg text-muted-foreground">We're here to help you every step of the way</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-card-hover transition-all duration-300">
              <CardContent className="p-6 text-center">
                <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">User Manual</h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  Complete guide to using our platform
                </p>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/user-manual">Read Manual</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-card-hover transition-all duration-300">
              <CardContent className="p-6 text-center">
                <Bot className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">AI Assistant</h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  Get instant answers to common questions
                </p>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/ask-ai">Ask AI</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Hide Ask Admin for admins unless impersonating */}
            {(!isAdmin || isImpersonating) && (
              <Card className="hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <MessageSquare className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Contact Admin</h3>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Real-time chat with our admin team
                  </p>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/chat-forum">Start Chat</Link>
                  </Button>
                </CardContent>
              </Card>
            )}

            <Card className="hover:shadow-card-hover transition-all duration-300">
              <CardContent className="p-6 text-center">
                <HelpCircle className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Community Q&A</h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  Ask questions and help others
                </p>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/qa-forum">Join Forum</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Book Your Room?</h2>
          <p className="text-xl mb-8 opacity-90">Join hundreds of satisfied students at Thika Mains Hostels</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="hero-button">
              <Link to="/booking">Book Now</Link>
            </Button>
            <Button asChild size="lg" className="outline-button">
              <Link to="/rooms">View All Rooms</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Prime Location</h2>
            <p className="text-lg text-muted-foreground mb-6">
              Located in the heart of Thika, close to major institutions and amenities
            </p>
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <MapPin className="h-5 w-5" />
              <span>Thika Main Campus Area, Kiambu County</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;