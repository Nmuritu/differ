import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  MessageSquare, 
  Send, 
  Users, 
  Clock, 
  AlertCircle,
  CheckCircle,
  XCircle,
  Eye,
  User,
  Bell
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import ChatService, { ChatThread, ChatMessage } from '@/services/ChatService';

/**
 * Admin Chat Forum Component
 * 
 * Real-time chat interface for admins to handle client issues
 * with live notifications and thread management.
 */
const AdminChatForum = () => {
  const { user } = useAuth();
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [selectedThread, setSelectedThread] = useState<ChatThread | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const [filter, setFilter] = useState<'all' | 'open' | 'assigned' | 'resolved'>('all');

  const chatService = ChatService.getInstance();

  useEffect(() => {
    // Load initial data
    loadThreads();
    loadUnreadCount();

    // Subscribe to real-time updates
    const unsubscribeThreads = chatService.subscribeToThreads((updatedThreads) => {
      setThreads(updatedThreads);
      loadUnreadCount();
    });

    // Start real-time updates
    chatService.startRealTimeUpdates();

    return () => {
      unsubscribeThreads();
    };
  }, []);

  useEffect(() => {
    if (selectedThread) {
      loadMessages(selectedThread.id);
      
      // Subscribe to message updates for this thread
      const unsubscribeMessages = chatService.subscribeToMessages(
        selectedThread.id,
        (updatedMessages) => {
          setMessages(updatedMessages);
        }
      );

      // Mark messages as read
      chatService.markMessagesAsRead(selectedThread.id, user?.id || '');

      return () => {
        unsubscribeMessages();
      };
    }
  }, [selectedThread, user?.id]);

  const loadThreads = () => {
    const adminThreads = chatService.getAdminThreads();
    setThreads(adminThreads);
  };

  const loadMessages = (threadId: string) => {
    const threadMessages = chatService.getThreadMessages(threadId);
    setMessages(threadMessages);
  };

  const loadUnreadCount = () => {
    const count = chatService.getAdminUnreadCount();
    setUnreadCount(count);
  };

  const handleThreadSelect = (thread: ChatThread) => {
    setSelectedThread(thread);
  };

  const handleSendMessage = () => {
    if (!selectedThread || !newMessage.trim() || !user) return;

    chatService.sendMessage(
      selectedThread.id,
      user.id,
      user.username,
      'admin',
      newMessage.trim()
    );

    setNewMessage('');
  };

  const handleAssignThread = (threadId: string) => {
    if (!user) return;
    
    chatService.assignThread(threadId, user.id, user.username);
  };

  const handleUpdateStatus = (threadId: string, status: 'open' | 'assigned' | 'resolved' | 'closed') => {
    chatService.updateThreadStatus(threadId, status);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'assigned': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredThreads = threads.filter(thread => {
    if (filter === 'all') return true;
    return thread.status === filter;
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold">Admin Chat Forum</h1>
                <p className="text-muted-foreground">Handle client issues in real-time</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              <Badge variant="destructive" className="text-sm">
                {unreadCount} Unread
              </Badge>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Threads List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Client Issues
                </CardTitle>
                <div className="flex gap-2">
                  {['all', 'open', 'assigned', 'resolved'].map((status) => (
                    <Button
                      key={status}
                      variant={filter === status ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFilter(status as 'all' | 'open' | 'closed' | 'pending')}
                      className="text-xs"
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </Button>
                  ))}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {filteredThreads.map((thread) => (
                    <div
                      key={thread.id}
                      className={`p-4 border-b cursor-pointer hover:bg-muted/50 transition-colors ${
                        selectedThread?.id === thread.id ? 'bg-primary/10' : ''
                      }`}
                      onClick={() => handleThreadSelect(thread)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{thread.clientName}</h4>
                          <p className="text-xs text-muted-foreground truncate">
                            {thread.subject}
                          </p>
                        </div>
                        {thread.unreadCount > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            {thread.unreadCount}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={`text-xs ${getStatusColor(thread.status)}`}>
                          {thread.status}
                        </Badge>
                        <Badge className={`text-xs ${getPriorityColor(thread.priority)}`}>
                          {thread.priority}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {new Date(thread.updatedAt).toLocaleString()}
                      </div>
                      
                      {thread.lastMessage && (
                        <p className="text-xs text-muted-foreground mt-1 truncate">
                          {thread.lastMessage.message}
                        </p>
                      )}
                    </div>
                  ))}
                  
                  {filteredThreads.length === 0 && (
                    <div className="p-4 text-center text-muted-foreground">
                      No threads found
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            {selectedThread ? (
              <Card className="h-[600px] flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{selectedThread.clientName}</CardTitle>
                      <p className="text-sm text-muted-foreground">{selectedThread.subject}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(selectedThread.status)}>
                        {selectedThread.status}
                      </Badge>
                      <Badge className={getPriorityColor(selectedThread.priority)}>
                        {selectedThread.priority}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    {selectedThread.status === 'open' && (
                      <Button
                        size="sm"
                        onClick={() => handleAssignThread(selectedThread.id)}
                        className="text-xs"
                      >
                        <User className="h-3 w-3 mr-1" />
                        Assign to Me
                      </Button>
                    )}
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedThread.id, 'resolved')}
                      className="text-xs"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Mark Resolved
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateStatus(selectedThread.id, 'closed')}
                      className="text-xs"
                    >
                      <XCircle className="h-3 w-3 mr-1" />
                      Close
                    </Button>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-1 flex flex-col p-0">
                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.senderType === 'admin' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                            message.senderType === 'admin'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <div className="text-xs font-medium mb-1">
                            {message.senderName}
                          </div>
                          <div className="text-sm">{message.message}</div>
                          <div className="text-xs opacity-70 mt-1">
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Message Input */}
                  <div className="border-t p-4">
                    <div className="flex gap-2">
                      <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="min-h-[60px] resize-none"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim()}
                        size="sm"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Select a Thread</h3>
                  <p className="text-muted-foreground">
                    Choose a client thread from the list to start chatting
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminChatForum;
