import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, CreditCard, Smartphone, Banknote, CheckCircle, Clock } from 'lucide-react';
import { BookingDetails } from '@/types/booking';
import { useRooms } from '@/contexts/RoomContext';
import { useToast } from '@/hooks/use-toast';

const PaymentPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const { rooms } = useRooms();
  const [booking, setBooking] = useState<BookingDetails | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'mpesa' | 'card' | 'cash'>('mpesa');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);

  useEffect(() => {
    const bookingId = searchParams.get('bookingId');
    if (bookingId) {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      const foundBooking = bookings.find((b: BookingDetails) => b.id === bookingId);
      if (foundBooking) {
        setBooking(foundBooking);
      } else {
        toast({
          title: 'Booking Not Found',
          description: 'The booking could not be found.',
          variant: 'destructive',
        });
        navigate('/');
      }
    }
  }, [searchParams, navigate, toast]);

  const handlePayment = async () => {
    if (!booking) return;

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      // Update booking status
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      const updatedBookings = bookings.map((b: BookingDetails) =>
        b.id === booking.id
          ? { ...b, status: 'confirmed', paymentStatus: 'paid' }
          : b
      );
      localStorage.setItem('bookings', JSON.stringify(updatedBookings));

      // In a real app, this would update the backend room availability

      setPaymentComplete(true);
      setIsProcessing(false);

      toast({
        title: 'Payment Successful!',
        description: 'Your booking has been confirmed.',
      });
    }, 3000);
  };

  if (!booking) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <p className="text-lg mb-4">Loading payment details...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const room = rooms.find(r => r.id === booking.roomId);

  if (paymentComplete) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto text-center">
            <Card className="border-success">
              <CardContent className="pt-8 pb-8">
                <div className="text-success mb-4">
                  <CheckCircle className="h-16 w-16 mx-auto" />
                </div>
                <h1 className="text-3xl font-bold text-success mb-4">
                  Payment Successful!
                </h1>
                <p className="text-lg text-muted-foreground mb-6">
                  Your booking has been confirmed. You will receive a confirmation email shortly.
                </p>
                
                <div className="bg-muted p-4 rounded-lg mb-6 text-left">
                  <h3 className="font-semibold mb-2">Booking Details</h3>
                  <div className="space-y-1 text-sm">
                    <p><strong>Booking ID:</strong> {booking.id}</p>
                    <p><strong>Room:</strong> {room?.type.charAt(0).toUpperCase()}{room?.type.slice(1)} Room</p>
                    <p><strong>Guest:</strong> {booking.guestName}</p>
                    <p><strong>Check-in:</strong> {new Date(booking.checkIn).toLocaleDateString()}</p>
                    <p><strong>Check-out:</strong> {new Date(booking.checkOut).toLocaleDateString()}</p>
                    <p><strong>Total Paid:</strong> KSh {booking.totalAmount.toLocaleString()}</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button onClick={() => navigate('/')} variant="outline">
                    Return Home
                  </Button>
                  <Button onClick={() => navigate(`/booking?bookingId=${booking.id}`)}>
                    Manage Booking
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const paymentMethods = [
    {
      id: 'mpesa',
      name: 'M-Pesa',
      icon: <Smartphone className="h-5 w-5" />,
      description: 'Pay using M-Pesa mobile money',
    },
    {
      id: 'card',
      name: 'Card Payment',
      icon: <CreditCard className="h-5 w-5" />,
      description: 'Pay with Visa or Mastercard',
    },
    {
      id: 'cash',
      name: 'Cash Payment',
      icon: <Banknote className="h-5 w-5" />,
      description: 'Pay cash at the hostel office',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <Button
              variant="ghost"
              onClick={() => navigate('/booking')}
              className="mb-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Booking
            </Button>
            <h1 className="text-4xl font-bold mb-2">Complete Payment</h1>
            <p className="text-lg text-muted-foreground">
              Choose your payment method to confirm your booking
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Payment Methods */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {paymentMethods.map((method) => (
                    <div
                      key={method.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                        selectedPaymentMethod === method.id
                          ? 'border-primary bg-primary/5'
                          : 'border-border'
                      }`}
                      onClick={() => setSelectedPaymentMethod(method.id as string)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-full ${
                          selectedPaymentMethod === method.id
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}>
                          {method.icon}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{method.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {method.description}
                          </p>
                        </div>
                        <div className={`w-4 h-4 rounded-full border-2 ${
                          selectedPaymentMethod === method.id
                            ? 'border-primary bg-primary'
                            : 'border-muted-foreground'
                        }`} />
                      </div>
                    </div>
                  ))}

                  <Separator className="my-6" />

                  {selectedPaymentMethod === 'mpesa' && (
                    <div className="p-4 bg-muted rounded-lg">
                      <h4 className="font-medium mb-2">M-Pesa Payment Instructions</h4>
                      <ol className="text-sm space-y-1 list-decimal list-inside">
                        <li>Go to M-Pesa menu on your phone</li>
                        <li>Select "Lipa na M-Pesa"</li>
                        <li>Select "Pay Bill"</li>
                        <li>Enter Business Number: <strong>174379</strong></li>
                        <li>Enter Account Number: <strong>{booking.id}</strong></li>
                        <li>Enter Amount: <strong>KSh {booking.totalAmount}</strong></li>
                        <li>Enter your M-Pesa PIN and confirm</li>
                      </ol>
                    </div>
                  )}

                  {selectedPaymentMethod === 'cash' && (
                    <div className="p-4 bg-muted rounded-lg">
                      <h4 className="font-medium mb-2">Cash Payment Instructions</h4>
                      <p className="text-sm mb-2">
                        Visit our office at Thika Mains Hostels to complete your payment.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Office Hours:</strong> Monday - Sunday, 8:00 AM - 8:00 PM
                      </p>
                    </div>
                  )}

                  <Button
                    onClick={handlePayment}
                    disabled={isProcessing}
                    className="w-full"
                    variant="hero"
                    size="lg"
                  >
                    {isProcessing ? (
                      <>
                        <Clock className="mr-2 h-4 w-4 animate-spin" />
                        Processing Payment...
                      </>
                    ) : (
                      `Pay KSh ${booking.totalAmount.toLocaleString()}`
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Payment Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle>Payment Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold">Booking #{booking.id}</h3>
                    <Badge variant="outline" className="mt-1">
                      {booking.status}
                    </Badge>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Guest:</span>
                      <span className="text-sm font-medium">{booking.guestName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Room:</span>
                      <span className="text-sm font-medium capitalize">
                        {room?.type} Room
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Check-in:</span>
                      <span className="text-sm font-medium">
                        {new Date(booking.checkIn).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Check-out:</span>
                      <span className="text-sm font-medium">
                        {new Date(booking.checkOut).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Total Amount:</span>
                    <span className="text-xl font-bold text-primary">
                      KSh {booking.totalAmount.toLocaleString()}
                    </span>
                  </div>

                  <div className="text-xs text-muted-foreground">
                    <p>• Secure payment processing</p>
                    <p>• Confirmation email will be sent</p>
                    <p>• 24/7 customer support available</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;