import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { 
  MessageSquare, 
  Send, 
  Plus, 
  Clock, 
  AlertCircle,
  CheckCircle,
  User,
  Bell
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import ChatService, { ChatThread, ChatMessage } from '@/services/ChatService';

/**
 * Client Chat Forum Component
 * 
 * Real-time chat interface for clients to communicate with admins
 * with issue creation and live messaging.
 */
const ClientChatForum = () => {
  const { user } = useAuth();
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [selectedThread, setSelectedThread] = useState<ChatThread | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newThreadSubject, setNewThreadSubject] = useState('');
  const [newThreadPriority, setNewThreadPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [newThreadMessage, setNewThreadMessage] = useState('');

  const chatService = ChatService.getInstance();

  useEffect(() => {
    if (!user) return;

    // Load initial data
    loadThreads();
    loadUnreadCount();

    // Subscribe to real-time updates
    const unsubscribeThreads = chatService.subscribeToThreads((updatedThreads) => {
      const clientThreads = updatedThreads.filter(t => t.clientId === user.id);
      setThreads(clientThreads);
    });

    // Start real-time updates
    chatService.startRealTimeUpdates();

    return () => {
      unsubscribeThreads();
    };
  }, [user]);

  useEffect(() => {
    if (selectedThread) {
      loadMessages(selectedThread.id);
      
      // Subscribe to message updates for this thread
      const unsubscribeMessages = chatService.subscribeToMessages(
        selectedThread.id,
        (updatedMessages) => {
          setMessages(updatedMessages);
        }
      );

      // Mark messages as read
      chatService.markMessagesAsRead(selectedThread.id, user?.id || '');

      return () => {
        unsubscribeMessages();
      };
    }
  }, [selectedThread, user?.id]);

  const loadThreads = () => {
    if (!user) return;
    const clientThreads = chatService.getClientThreads(user.id);
    setThreads(clientThreads);
  };

  const loadMessages = (threadId: string) => {
    const threadMessages = chatService.getThreadMessages(threadId);
    setMessages(threadMessages);
  };

  const loadUnreadCount = () => {
    if (!user) return;
    const count = chatService.getClientUnreadCount(user.id);
    setUnreadCount(count);
  };

  const handleThreadSelect = (thread: ChatThread) => {
    setSelectedThread(thread);
  };

  const handleSendMessage = () => {
    if (!selectedThread || !newMessage.trim() || !user) return;

    chatService.sendMessage(
      selectedThread.id,
      user.id,
      user.username,
      'client',
      newMessage.trim()
    );

    setNewMessage('');
  };

  const handleCreateThread = () => {
    if (!user || !newThreadSubject.trim() || !newThreadMessage.trim()) return;

    const thread = chatService.createThread(
      user.id,
      user.username,
      newThreadSubject.trim(),
      newThreadPriority
    );

    // Send initial message
    chatService.sendMessage(
      thread.id,
      user.id,
      user.username,
      'client',
      newThreadMessage.trim()
    );

    // Reset form
    setNewThreadSubject('');
    setNewThreadMessage('');
    setNewThreadPriority('medium');
    setShowCreateDialog(false);
    setSelectedThread(thread);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'assigned': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold">Support Chat</h1>
                <p className="text-muted-foreground">Get help from our admin team</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              <Badge variant="destructive" className="text-sm">
                {unreadCount} Unread
              </Badge>
              <Button
                onClick={() => setShowCreateDialog(true)}
                className="ml-2"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Issue
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Threads List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  My Issues
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {threads.map((thread) => (
                    <div
                      key={thread.id}
                      className={`p-4 border-b cursor-pointer hover:bg-muted/50 transition-colors ${
                        selectedThread?.id === thread.id ? 'bg-primary/10' : ''
                      }`}
                      onClick={() => handleThreadSelect(thread)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{thread.subject}</h4>
                          <p className="text-xs text-muted-foreground">
                            {thread.adminName ? `Assigned to ${thread.adminName}` : 'Unassigned'}
                          </p>
                        </div>
                        {thread.unreadCount > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            {thread.unreadCount}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={`text-xs ${getStatusColor(thread.status)}`}>
                          {thread.status}
                        </Badge>
                        <Badge className={`text-xs ${getPriorityColor(thread.priority)}`}>
                          {thread.priority}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {new Date(thread.updatedAt).toLocaleString()}
                      </div>
                      
                      {thread.lastMessage && (
                        <p className="text-xs text-muted-foreground mt-1 truncate">
                          {thread.lastMessage.message}
                        </p>
                      )}
                    </div>
                  ))}
                  
                  {threads.length === 0 && (
                    <div className="p-4 text-center text-muted-foreground">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>No issues yet</p>
                      <p className="text-xs">Create a new issue to get started</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            {selectedThread ? (
              <Card className="h-[600px] flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{selectedThread.subject}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {selectedThread.adminName ? `Assigned to ${selectedThread.adminName}` : 'Awaiting assignment'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(selectedThread.status)}>
                        {selectedThread.status}
                      </Badge>
                      <Badge className={getPriorityColor(selectedThread.priority)}>
                        {selectedThread.priority}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-1 flex flex-col p-0">
                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.senderType === 'client' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                            message.senderType === 'client'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <div className="text-xs font-medium mb-1">
                            {message.senderName}
                          </div>
                          <div className="text-sm">{message.message}</div>
                          <div className="text-xs opacity-70 mt-1">
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Message Input */}
                  <div className="border-t p-4">
                    <div className="flex gap-2">
                      <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="min-h-[60px] resize-none"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim()}
                        size="sm"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Select an Issue</h3>
                  <p className="text-muted-foreground mb-4">
                    Choose an issue from the list or create a new one
                  </p>
                  <Button onClick={() => setShowCreateDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create New Issue
                  </Button>
                </div>
              </Card>
            )}
          </div>
        </div>

        {/* Create New Thread Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Issue</DialogTitle>
              <DialogDescription>
                Describe your issue and we'll get back to you as soon as possible
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Subject</label>
                <Input
                  value={newThreadSubject}
                  onChange={(e) => setNewThreadSubject(e.target.value)}
                  placeholder="Brief description of your issue"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Priority</label>
                <select
                  value={newThreadPriority}
                  onChange={(e) => setNewThreadPriority(e.target.value as 'low' | 'medium' | 'high' | 'urgent')}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="low">Low - General inquiry</option>
                  <option value="medium">Medium - Standard issue</option>
                  <option value="high">High - Urgent issue</option>
                  <option value="urgent">Urgent - Critical problem</option>
                </select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Message</label>
                <Textarea
                  value={newThreadMessage}
                  onChange={(e) => setNewThreadMessage(e.target.value)}
                  placeholder="Please provide details about your issue..."
                  className="min-h-[100px]"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateThread}
                disabled={!newThreadSubject.trim() || !newThreadMessage.trim()}
              >
                Create Issue
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default ClientChatForum;
