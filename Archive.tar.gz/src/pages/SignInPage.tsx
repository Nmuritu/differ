import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';

/**
 * Sign In Page Component
 * 
 * Provides user authentication with multiple login methods:
 * - Email address login
 * - Username login  
 * - Phone number login
 * 
 * Features:
 * - Flexible login field (accepts email, username, or phone)
 * - Password visibility toggle
 * - Smart error handling with suggestions
 * - Login attempt tracking (3 attempts before suggesting password reset)
 * - Automatic redirection to home page on successful login
 * - Links to registration and password reset pages
 */
const SignInPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  
  // Form state management with persistence
  const [formData, setFormData] = useState(() => {
    const savedData = localStorage.getItem('signinFormData');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        // Don't restore password for security reasons
        return {
          loginField: parsed.loginField || '',
          password: ''
        };
      } catch (error) {
        console.error('Error parsing saved signin data:', error);
      }
    }
    return {
      loginField: '', // Accepts email, username, or phone number
      password: ''
    };
  });
  
  // UI state management
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [suggestion, setSuggestion] = useState('');

  // Save form data to localStorage (except password for security)
  useEffect(() => {
    if (formData.loginField.trim() !== '') {
      localStorage.setItem('signinFormData', JSON.stringify({
        loginField: formData.loginField
      }));
    }
  }, [formData.loginField]);

  /**
   * Handle input field changes and clear related errors
   * @param e - Input change event
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing to improve UX
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  /**
   * Validate email format (sync with registration page)
   * @param email - Email to validate
   * @returns boolean - true if valid email format
   */
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const allowedDomains = ['gmail.com', 'yahoo.com', 'protonmail.com', 'proton.me'];
    
    if (!emailRegex.test(email)) return false;
    
    const domain = email.split('@')[1]?.toLowerCase();
    return allowedDomains.includes(domain);
  };

  /**
   * Validate phone number format (sync with registration page)
   * @param phone - Phone number to validate
   * @returns boolean - true if valid phone format
   */
  const validatePhone = (phone: string): boolean => {
    const cleanPhone = phone.replace(/\D/g, '');
    return cleanPhone.length >= 10;
  };

  /**
   * Validate form inputs before submission (enhanced to sync with registration)
   * @returns boolean - true if form is valid, false otherwise
   */
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    const loginField = formData.loginField.trim();

    if (!loginField) {
      newErrors.loginField = 'Email, username, or phone number is required';
    } else {
      // Validate format based on input type
      if (loginField.includes('@')) {
        // Email validation
        if (!validateEmail(loginField)) {
          newErrors.loginField = 'Please use a valid Gmail, Yahoo, or Proton email';
        }
      } else if (/^\d/.test(loginField)) {
        // Phone validation
        if (!validatePhone(loginField)) {
          newErrors.loginField = 'Phone number must be at least 10 digits';
        }
      } else {
        // Username validation
        if (loginField.length < 3) {
          newErrors.loginField = 'Username must be at least 3 characters';
        }
      }
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    }
    // Note: No minimum length requirement for sign-in
    // Password strength validation only applies during registration and password changes

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handle form submission for user authentication
   * Supports multiple login methods and provides smart error handling
   * @param e - Form submit event
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setSuggestion('');

    try {
      // Use the proper authentication service
      const result = await login(formData.loginField, formData.password);
      
      if (result.success) {
        // Clear saved form data on successful login
        localStorage.removeItem('signinFormData');
        setLoginAttempts(0);
        navigate('/home');
        return;
      }

      // Handle different types of authentication failures
      if (result.error === 'Account not found') {
        setSuggestion('No account found with these credentials. Please create a new account or try different login details.');
        setErrors({ general: 'Account not found' });
      } else if (result.error === 'Incorrect password') {
        setLoginAttempts(prev => prev + 1);
        setSuggestion(result.message || 'Wrong password. Please try again.');
        setErrors({ general: 'Incorrect password' });
      } else if (result.error === 'Too many failed attempts') {
        setSuggestion('You have exceeded the maximum login attempts. Please reset your password using the "Forgot Password" option.');
        setErrors({ general: 'Too many failed attempts' });
      } else {
        setSuggestion(result.message || 'Sign in failed. Please try again.');
        setErrors({ general: result.error || 'Sign in failed' });
      }
    } catch (error) {
      setSuggestion('An unexpected error occurred. Please try again.');
      setErrors({ general: 'Sign in failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Clear all form fields and reset form state
   */
  const handleClearForm = () => {
    // Clear all form data
    setFormData({
      loginField: '',
      password: ''
    });
    
    // Clear all errors and suggestions
    setErrors({});
    setSuggestion('');
    
    // Reset login attempts
    setLoginAttempts(0);
    
    // Clear saved form data from localStorage
    localStorage.removeItem('signinFormData');
    
    // Show confirmation
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold">Welcome Back</h1>
            <p className="text-muted-foreground mt-2">
              Sign in to your Thika Mains Hostels account
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-center">Sign In</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {errors.general && (
                <Alert variant="destructive">
                  <AlertDescription>{errors.general}</AlertDescription>
                </Alert>
              )}

              {suggestion && (
                <Alert className={errors.general === 'Account not found. Please create an account.' ? 'border-blue-200 bg-blue-50 dark:bg-blue-900/20' : ''}>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {suggestion}
                    {errors.general === 'Account not found. Please create an account.' && (
                      <div className="mt-3">
                        <Link 
                          to="/register" 
                          className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-blue-700 bg-blue-100 hover:bg-blue-200 dark:text-blue-200 dark:bg-blue-800 dark:hover:bg-blue-700 rounded-md transition-colors"
                        >
                          Create Account Now
                        </Link>
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="loginField">Email, Username, or Phone</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="loginField"
                    name="loginField"
                    type="text"
                    placeholder="your@email.com, username, or phone"
                    value={formData.loginField}
                    onChange={handleInputChange}
                    className={`pl-10 ${errors.loginField ? 'border-destructive' : ''}`}
                  />
                </div>
                {errors.loginField && (
                  <p className="text-sm text-destructive">{errors.loginField}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className={`pl-10 pr-10 ${errors.password ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 h-4 w-4 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-sm text-destructive">{errors.password}</p>
                )}
              </div>


              <div className="space-y-3">
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
                <Button 
                  type="button" 
                  variant="secondary" 
                  className="w-full" 
                  onClick={handleClearForm}
                  disabled={isLoading}
                >
                  Clear Form
                </Button>
              </div>
            </form>

            <div className="mt-6 space-y-3">
              <div className="text-center">
                <Link 
                  to="/forgot-password" 
                  className="text-sm text-primary hover:underline"
                >
                  Forgot Password?
                </Link>
              </div>
              
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  Don't have an account?{' '}
                  <Link to="/register" className="text-primary hover:underline">
                    Create one here
                  </Link>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SignInPage;
