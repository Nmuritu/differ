import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  BookOpen, 
  User, 
  Settings, 
  CreditCard, 
  Shield, 
  HelpCircle, 
  MessageSquare, 
  Bot,
  Eye,
  EyeOff,
  Smartphone,
  Mail,
  Lock,
  Home,
  Calendar,
  FileText,
  Users,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';

/**
 * User Manual Page Component
 * 
 * Provides comprehensive navigation guide for the Thika Mains Hostels application.
 * Features different content based on user authentication status:
 * - Public content: Basic app overview and general features
 * - Authenticated content: Full feature guide including account management
 * 
 * Sections:
 * - Getting Started
 * - Account Management (authenticated users only)
 * - Room Booking Process
 * - Payment & Subscription
 * - Settings & Preferences
 * - Troubleshooting
 * - Support Options
 */
const UserManualPage = () => {
  const { isAuthenticated, isPreview } = useAuth();

  /**
   * Manual sections configuration
   * Content is filtered based on user authentication status
   */
  const manualSections = [
    {
      id: 'getting-started',
      title: 'Getting Started',
      icon: <BookOpen className="h-6 w-6" />,
      description: 'Learn the basics of using our hostel booking system',
      content: [
        {
          title: 'Welcome to Thika Mains Hostels',
          description: 'Our online platform makes it easy to find, book, and manage your hostel accommodation.',
          steps: [
            'Browse available rooms and their features',
            'Create an account or use preview mode to explore',
            'Select your preferred room plan',
            'Complete your booking and payment',
            'Access your dashboard to manage your stay'
          ]
        },
        {
          title: 'Creating Your Account',
          description: 'Sign up to access full features and manage your bookings.',
          steps: [
            'Click "Sign Up" on the homepage',
            'Fill in your personal details (username, email, phone)',
            'Choose a secure password',
            'Verify your information and submit',
            'You can also use "Preview Account" to explore features'
          ]
        },
        {
          title: 'Navigation Overview',
          description: 'Understanding the main navigation and interface.',
          steps: [
            'Header: Contains main navigation and user controls',
            'Home: Overview of available rooms and quick actions',
            'Rooms: Detailed view of all available accommodations',
            'Settings: Manage your account and preferences',
            'Profile: View and edit your personal information'
          ]
        }
      ]
    },
    {
      id: 'account-management',
      title: 'Account Management',
      icon: <User className="h-6 w-6" />,
      description: 'Managing your profile and account settings',
      requiresAuth: true,
      content: [
        {
          title: 'Profile Management',
          description: 'Keep your personal information up to date.',
          steps: [
            'Navigate to Profile from the header menu',
            'Upload a profile picture (max 2MB, image files only)',
            'View your current room plan and payment method',
            'Update contact information as needed',
            'Download payment receipts for your records'
          ]
        },
        {
          title: 'Changing Your Password',
          description: 'Update your account password for security.',
          steps: [
            'Go to Settings from the header menu',
            'Find "Privacy & Security" section',
            'Click "Change Password"',
            'Enter your current password',
            'Enter your new password (minimum 4 characters)',
            'Confirm your new password and submit'
          ]
        },
        {
          title: 'Account Security',
          description: 'Keep your account secure with these tips.',
          steps: [
            'Use a strong, unique password',
            'Keep your contact information updated',
            'Log out when using shared devices',
            'Report any suspicious activity immediately',
            'Enable two-factor authentication when available'
          ]
        }
      ]
    },
    {
      id: 'room-booking',
      title: 'Room Booking Process',
      icon: <Home className="h-6 w-6" />,
      description: 'How to find and book your perfect room',
      content: [
        {
          title: 'Browsing Available Rooms',
          description: 'Explore our range of accommodation options.',
          steps: [
            'Click "View Rooms" on the homepage',
            'Browse different room types (Single, Double, Suite)',
            'Compare features and pricing',
            'Read detailed descriptions and amenities',
            'Check availability and pricing'
          ]
        },
        {
          title: 'Making a Booking',
          description: 'Complete your room reservation process.',
          steps: [
            'Select your preferred room type',
            'Choose your payment method',
            'Review your booking details',
            'Complete the payment process',
            'Receive confirmation and receipt'
          ]
        },
        {
          title: 'Managing Your Booking',
          description: 'Update or modify your existing bookings.',
          steps: [
            'Access your profile dashboard',
            'View current and past bookings',
            'Update booking details if needed',
            'Download receipts and documents',
            'Contact support for major changes'
          ]
        }
      ]
    },
    {
      id: 'payment-subscription',
      title: 'Payment & Subscription',
      icon: <CreditCard className="h-6 w-6" />,
      description: 'Understanding payment methods and subscription management',
      requiresAuth: true,
      content: [
        {
          title: 'Payment Methods',
          description: 'Choose from our supported payment options.',
          steps: [
            'M-Pesa: Quick and convenient mobile payments',
            'Credit/Debit Card: Secure card payments',
            'Bank Transfer: Direct bank account transfers',
            'Select your preferred method during booking',
            'Update payment preferences in your profile'
          ]
        },
        {
          title: 'Subscription Management',
          description: 'Manage your monthly subscription and renewals.',
          steps: [
            'View your current plan in Settings',
            'Check subscription status and renewal dates',
            'Update payment method if needed',
            'Download receipts for accounting',
            'Contact support for plan changes'
          ]
        },
        {
          title: 'Receipts and Invoices',
          description: 'Access your payment history and receipts.',
          steps: [
            'Go to your Profile page',
            'Navigate to Payment History section',
            'Click "Receipt" next to any payment',
            'Download the receipt as a text file',
            'Keep receipts for your records'
          ]
        }
      ]
    },
    {
      id: 'settings-preferences',
      title: 'Settings & Preferences',
      icon: <Settings className="h-6 w-6" />,
      description: 'Customizing your app experience',
      content: [
        {
          title: 'Appearance Settings',
          description: 'Customize the look and feel of the application.',
          steps: [
            'Go to Settings from the header menu',
            'Find "Appearance" section',
            'Toggle between Light and Dark mode',
            'Changes apply immediately',
            'Your preference is saved automatically'
          ]
        },
        {
          title: 'Notification Preferences',
          description: 'Control how you receive updates and alerts.',
          steps: [
            'Access Settings from the main menu',
            'Find "Notifications" section',
            'Configure email notifications',
            'Set up SMS alerts for important updates',
            'Customize notification frequency'
          ]
        },
        {
          title: 'Privacy Settings',
          description: 'Manage your privacy and data preferences.',
          steps: [
            'Navigate to Settings',
            'Review "Privacy & Security" options',
            'Update password regularly',
            'Enable two-factor authentication',
            'Review account deletion options if needed'
          ]
        }
      ]
    },
    {
      id: 'troubleshooting',
      title: 'Troubleshooting',
      icon: <HelpCircle className="h-6 w-6" />,
      description: 'Common issues and solutions',
      content: [
        {
          title: 'Login Issues',
          description: 'Having trouble signing in? Try these solutions.',
          steps: [
            'Verify your email, username, or phone number',
            'Check that your password is correct',
            'Try resetting your password if needed',
            'Clear your browser cache and cookies',
            'Contact support if problems persist'
          ]
        },
        {
          title: 'Payment Problems',
          description: 'Resolve payment and subscription issues.',
          steps: [
            'Verify your payment method details',
            'Check your account balance or card limits',
            'Try a different payment method',
            'Contact your bank if using card payments',
            'Reach out to our support team for assistance'
          ]
        },
        {
          title: 'Profile and Settings',
          description: 'Fix issues with your profile and preferences.',
          steps: [
            'Ensure you\'re logged in to your account',
            'Check your internet connection',
            'Try refreshing the page',
            'Clear browser cache if needed',
            'Contact support for technical issues'
          ]
        }
      ]
    },
    {
      id: 'support-options',
      title: 'Support Options',
      icon: <MessageSquare className="h-6 w-6" />,
      description: 'Get help when you need it',
      content: [
        {
          title: 'AI Assistant',
          description: 'Get instant help with common questions.',
          steps: [
            'Click "Ask AI" in the support section',
            'Type your question or problem',
            'Get instant answers based on our knowledge base',
            'Try different phrasings if needed',
            'Escalate to human support if AI can\'t help'
          ]
        },
        {
          title: 'Contact Admin',
          description: 'Reach out to our support team directly.',
          steps: [
            'Click "Ask Admin" for direct support',
            'Fill in your contact details',
            'Describe your issue in detail',
            'Submit your request',
            'You\'ll receive an SMS response from our team'
          ]
        },
        {
          title: 'User Manual',
          description: 'This comprehensive guide covers all features.',
          steps: [
            'Bookmark this page for quick reference',
            'Use the table of contents to find specific topics',
            'Search for keywords using Ctrl+F (Cmd+F on Mac)',
            'Check the troubleshooting section first',
            'Contact support if you can\'t find what you need'
          ]
        }
      ]
    }
  ];

  /**
   * Filter sections based on user authentication status
   */
  const getVisibleSections = () => {
    return manualSections.filter(section => {
      if (section.requiresAuth && !isAuthenticated) {
        return false;
      }
      return true;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Button asChild variant="outline" size="sm">
              <Link to="/home">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Link>
            </Button>
          </div>
          <div className="flex items-center gap-3">
            <BookOpen className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">User Manual</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Complete guide to using Thika Mains Hostels booking system
          </p>
          {!isAuthenticated && (
            <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="h-5 w-5 text-blue-600" />
                <h4 className="font-semibold text-blue-800 dark:text-blue-200">Limited Access</h4>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                Some features in this manual are only available to signed-in users. 
                <Link to="/register" className="text-blue-600 hover:underline ml-1">
                  Create an account
                </Link> to access all features.
              </p>
            </div>
          )}
        </div>

        {/* Table of Contents */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Table of Contents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getVisibleSections().map((section, index) => (
                <div key={section.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="text-primary">{section.icon}</div>
                  <div>
                    <h4 className="font-medium">{section.title}</h4>
                    <p className="text-sm text-muted-foreground">{section.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Manual Sections */}
        <div className="space-y-8">
          {getVisibleSections().map((section, sectionIndex) => (
            <Card key={section.id} className="hover:shadow-card-hover transition-all duration-300">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="text-primary">{section.icon}</div>
                  <div>
                    <CardTitle className="text-2xl">{section.title}</CardTitle>
                    <p className="text-muted-foreground mt-1">{section.description}</p>
                  </div>
                  {section.requiresAuth && (
                    <Badge variant="secondary" className="ml-auto">
                      <User className="h-3 w-3 mr-1" />
                      Signed In Required
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {section.content.map((item, itemIndex) => (
                  <div key={itemIndex} className="space-y-3">
                    <h4 className="text-lg font-semibold">{item.title}</h4>
                    <p className="text-muted-foreground">{item.description}</p>
                    <div className="space-y-2">
                      {item.steps.map((step, stepIndex) => (
                        <div key={stepIndex} className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 mt-0.5">
                            {stepIndex + 1}
                          </div>
                          <p className="text-sm">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Support Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Need More Help?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button asChild variant="outline" className="h-auto p-4">
                <Link to="/ask-ai" className="flex flex-col items-center gap-2">
                  <Bot className="h-6 w-6" />
                  <span className="font-medium">Ask AI</span>
                  <span className="text-xs text-muted-foreground">Get instant answers</span>
                </Link>
              </Button>
              {isAuthenticated && (
                <Button asChild variant="outline" className="h-auto p-4">
                  <Link to="/ask-admin" className="flex flex-col items-center gap-2">
                    <MessageSquare className="h-6 w-6" />
                    <span className="font-medium">Ask Admin</span>
                    <span className="text-xs text-muted-foreground">Direct support</span>
                  </Link>
                </Button>
              )}
              <Button asChild variant="outline" className="h-auto p-4">
                <Link to="/home" className="flex flex-col items-center gap-2">
                  <Home className="h-6 w-6" />
                  <span className="font-medium">Back to App</span>
                  <span className="text-xs text-muted-foreground">Continue using</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default UserManualPage;
