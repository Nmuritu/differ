import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { 
  MessageSquare, 
  Send, 
  CheckCircle, 
  AlertCircle,
  User,
  Mail,
  FileText,
  Clock,
  Bot
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { navigateToAdminForum } from '@/utils/navigation';

/**
 * Ask Admin Page Component
 * 
 * Provides a direct communication channel between users and administrators.
 * Users can submit issues, questions, or requests that will be sent to admins
 * via SMS for immediate response.
 * 
 * Features:
 * - Pre-filled user information from authentication context
 * - Categorized issue types for better organization
 * - Priority levels for urgent matters
 * - SMS integration simulation for admin notifications
 * - Response tracking and status updates
 */
const AskAdminPage = () => {
  const { user, isAuthenticated, isPreview, isAdmin } = useAuth();
  const location = useLocation();

  // Form state management
  const [formData, setFormData] = useState({
    name: user?.username || '',
    email: user?.email || '',
    phone: user?.phone || '',
    issueType: '',
    priority: 'medium',
    subject: '',
    description: '',
    additionalInfo: ''
  });
  
  // UI state management
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submissionId, setSubmissionId] = useState('');

  // Handle pre-filled questions from smart router
  useEffect(() => {
    const prefillQuestion = location.state?.prefillQuestion;
    if (prefillQuestion) {
      setFormData(prev => ({
        ...prev,
        subject: prefillQuestion,
        description: `Question from Smart Router: ${prefillQuestion}`
      }));
    }
  }, [location.state]);

  // If admin (makopolo) accesses this page, redirect to admin forum
  if (isAdmin && user?.username === 'makopolo') {
    navigateToAdminForum();
    return null;
  }

  // Redirect preview users to signup/signin
  if (isPreview || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card>
            <CardHeader>
              <div className="text-center">
                <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <MessageSquare className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-2xl">Admin Support</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-muted-foreground">
                Admin support is available exclusively for our registered clients.
              </p>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>Why sign up?</strong>
                </p>
                <ul className="text-xs text-blue-700 dark:text-blue-300 mt-2 space-y-1 text-left">
                  <li>• Direct SMS support from our admin team</li>
                  <li>• Priority response within 1-4 hours</li>
                  <li>• Personalized assistance with your account</li>
                  <li>• Access to all premium features</li>
                </ul>
              </div>

              <div className="space-y-2">
                <Button asChild className="w-full">
                  <Link to="/register">
                    <User className="h-4 w-4 mr-2" />
                    Create Account
                  </Link>
                </Button>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/signin">
                    <Mail className="h-4 w-4 mr-2" />
                    Sign In
                  </Link>
                </Button>
              </div>

              <div className="pt-4 border-t">
                <p className="text-xs text-muted-foreground mb-2">
                  Need help right now?
                </p>
                <Button asChild variant="ghost" size="sm" className="w-full">
                  <Link to="/ask-ai">
                    <Bot className="h-4 w-4 mr-2" />
                    Try AI Assistant (Free)
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  /**
   * Issue categories for better organization
   */
  const issueTypes = [
    {
      id: 'booking',
      label: 'Booking Issues',
      description: 'Problems with room reservations, availability, or booking process',
      icon: ''
    },
    {
      id: 'payment',
      label: 'Payment Problems',
      description: 'Issues with payments, billing, receipts, or subscription management',
      icon: '💳'
    },
    {
      id: 'account',
      label: 'Account Management',
      description: 'Profile updates, password issues, account settings, or access problems',
      icon: ''
    },
    {
      id: 'technical',
      label: 'Technical Issues',
      description: 'App bugs, performance problems, or technical difficulties',
      icon: ''
    },
    {
      id: 'billing',
      label: 'Billing & Refunds',
      description: 'Questions about charges, refunds, or billing disputes',
      icon: '💰'
    },
    {
      id: 'general',
      label: 'General Inquiry',
      description: 'General questions, feedback, or other concerns',
      icon: '❓'
    }
  ];

  /**
   * Priority levels for issue classification
   */
  const priorityLevels = [
    {
      id: 'low',
      label: 'Low Priority',
      description: 'General questions or minor issues',
      color: 'bg-green-100 text-green-800',
      responseTime: '24-48 hours'
    },
    {
      id: 'medium',
      label: 'Medium Priority',
      description: 'Important issues that need attention',
      color: 'bg-yellow-100 text-yellow-800',
      responseTime: '4-12 hours'
    },
    {
      id: 'high',
      label: 'High Priority',
      description: 'Urgent issues requiring immediate attention',
      color: 'bg-red-100 text-red-800',
      responseTime: '1-4 hours'
    }
  ];

  /**
   * Handle input changes and clear related errors
   * @param e - Input change event
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  /**
   * Handle select changes
   * @param name - Field name
   * @param value - Selected value
   */
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user makes selection
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  /**
   * Validate form inputs
   * @returns boolean - true if form is valid
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10,}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'Please enter a valid phone number (at least 10 digits)';
    }

    if (!formData.issueType) {
      newErrors.issueType = 'Please select an issue type';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Please describe your issue';
    } else if (formData.description.trim().length < 10) {
      newErrors.description = 'Please provide more details (at least 10 characters)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handle form submission
   * @param e - Form submit event
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Generate submission ID
      const id = `ADMIN-${Date.now()}`;
      setSubmissionId(id);

      // Simulate SMS notification to admin
      console.log(`New support request from ${formData.name} (${formData.phone}):
      
Issue: ${formData.subject}
Type: ${issueTypes.find(t => t.id === formData.issueType)?.label}
Priority: ${priorityLevels.find(p => p.id === formData.priority)?.label}
Description: ${formData.description}

Please respond within ${priorityLevels.find(p => p.id === formData.priority)?.responseTime}.`);

      
      // In a real app, you would:
      // 1. Send SMS to admin phone number
      // 2. Store the request in a database
      // 3. Send email notification
      // 4. Create a support ticket

      setIsSubmitted(true);
    } catch (error) {
      setErrors({ general: 'Failed to submit your request. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Clear all form fields and reset form state
   */
  const handleClearForm = () => {
    // Clear all form data
    setFormData({
      name: '',
      email: '',
      phone: '',
      issueType: '',
      priority: 'medium',
      subject: '',
      description: '',
      additionalInfo: ''
    });
    
    // Clear all errors
    setErrors({});
    
    // Show confirmation
  };

  // Show success page after submission
  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card>
            <CardHeader>
              <div className="text-center">
                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl">Request Submitted!</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-muted-foreground">
                Your support request has been sent to our admin team.
              </p>
              
              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm font-medium">Submission ID: {submissionId}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Keep this ID for reference
                </p>
              </div>

              <div className="space-y-2 text-sm">
                <p><strong>What happens next?</strong></p>
                <ul className="text-left space-y-1 text-muted-foreground">
                  <li>• Admin will receive SMS notification</li>
                  <li>• You'll get SMS response within {priorityLevels.find(p => p.id === formData.priority)?.responseTime}</li>
                  <li>• Check your phone for updates</li>
                  <li>• Contact us again if no response</li>
                </ul>
              </div>

              <div className="flex flex-col gap-2">
                <Button asChild className="w-full">
                  <Link to="/home">Back to Home</Link>
                </Button>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/ask-ai">Try AI Assistant</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <BackButton variant="both" size="sm" />
          </div>
          <div className="flex items-center gap-3">
            <MessageSquare className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Ask Admin</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Contact our admin team directly for personalized support
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Submit Support Request
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {errors.general && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{errors.general}</AlertDescription>
                    </Alert>
                  )}

                  {/* Contact Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Contact Information</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name *</Label>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className={errors.name ? 'border-destructive' : ''}
                          placeholder="Your full name"
                        />
                        {errors.name && (
                          <p className="text-sm text-destructive">{errors.name}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className={errors.email ? 'border-destructive' : ''}
                          placeholder="your@email.com"
                        />
                        {errors.email && (
                          <p className="text-sm text-destructive">{errors.email}</p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className={errors.phone ? 'border-destructive' : ''}
                        placeholder="0712345678"
                      />
                      <p className="text-xs text-muted-foreground">
                        Admin will respond via SMS to this number
                      </p>
                      {errors.phone && (
                        <p className="text-sm text-destructive">{errors.phone}</p>
                      )}
                    </div>
                  </div>

                  {/* Issue Details */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Issue Details</h3>
                    
                    <div className="space-y-2">
                      <Label>Issue Type *</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {issueTypes.map((type) => (
                          <div
                            key={type.id}
                            className={`p-3 border rounded-lg cursor-pointer transition-all ${
                              formData.issueType === type.id
                                ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                                : 'border-border hover:border-primary/50'
                            }`}
                            onClick={() => handleSelectChange('issueType', type.id)}
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{type.icon}</span>
                              <div className="flex-1">
                                <p className="font-medium">{type.label}</p>
                                <p className="text-xs text-muted-foreground">{type.description}</p>
                              </div>
                              {formData.issueType === type.id && (
                                <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                  <CheckCircle className="h-3 w-3 text-primary-foreground" />
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                      {errors.issueType && (
                        <p className="text-sm text-destructive">{errors.issueType}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label>Priority Level</Label>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {priorityLevels.map((priority) => (
                          <div
                            key={priority.id}
                            className={`p-3 border rounded-lg cursor-pointer transition-all ${
                              formData.priority === priority.id
                                ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                                : 'border-border hover:border-primary/50'
                            }`}
                            onClick={() => handleSelectChange('priority', priority.id)}
                          >
                            <div className="text-center">
                              <div className="flex items-center justify-center gap-2 mb-2">
                                <Badge className={priority.color}>
                                  {priority.label}
                                </Badge>
                                {formData.priority === priority.id && (
                                  <CheckCircle className="h-4 w-4 text-primary" />
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground mb-1">
                                {priority.description}
                              </p>
                              <p className="text-xs font-medium text-primary">
                                Response: {priority.responseTime}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject">Subject *</Label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        className={errors.subject ? 'border-destructive' : ''}
                        placeholder="Brief description of your issue"
                      />
                      {errors.subject && (
                        <p className="text-sm text-destructive">{errors.subject}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description *</Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        className={errors.description ? 'border-destructive' : ''}
                        placeholder="Please provide detailed information about your issue..."
                        rows={4}
                      />
                      <p className="text-xs text-muted-foreground">
                        Minimum 10 characters. Be as specific as possible.
                      </p>
                      {errors.description && (
                        <p className="text-sm text-destructive">{errors.description}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="additionalInfo">Additional Information</Label>
                      <Textarea
                        id="additionalInfo"
                        name="additionalInfo"
                        value={formData.additionalInfo}
                        onChange={handleInputChange}
                        placeholder="Any additional details, screenshots descriptions, or context..."
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Clock className="h-4 w-4 mr-2 animate-spin" />
                          Submitting Request...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Submit Request
                        </>
                      )}
                    </Button>
                    <Button 
                      type="button" 
                      variant="secondary" 
                      className="w-full" 
                      onClick={handleClearForm}
                      disabled={isSubmitting}
                    >
                      Clear Form
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Information Sidebar */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Before You Submit
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium">Try These First:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Check the User Manual</li>
                    <li>• Try the AI Assistant</li>
                    <li>• Look for similar issues in FAQ</li>
                    <li>• Restart the app or refresh the page</li>
                  </ul>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium">What to Include:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Clear description of the problem</li>
                    <li>• Steps to reproduce the issue</li>
                    <li>• Screenshots if applicable</li>
                    <li>• Your account details if relevant</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Response Times
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {priorityLevels.map((priority) => (
                  <div key={priority.id} className="flex items-center justify-between">
                    <Badge className={priority.color}>
                      {priority.label}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {priority.responseTime}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="h-5 w-5" />
                  Quick Help
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  For common questions, try our AI assistant first.
                </p>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/ask-ai">
                    <Bot className="h-4 w-4 mr-2" />
                    Try AI Assistant
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AskAdminPage;
