import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  HelpCircle, 
  Bot, 
  MessageSquare, 
  BookOpen,
  Users,
  Lightbulb,
  Clock,
  Shield
} from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import { SmartHelpRouter } from '@/components/ui/smart-help-router';
import NewAuthService from '@/services/NewAuthService';
import { useState, useEffect } from 'react';

/**
 * Help Page Component
 * 
 * Central hub for all support options with smart routing capabilities.
 * Provides different access levels based on user authentication status.
 * 
 * Features:
 * - Smart Help Router for intelligent question routing
 * - Quick access to all support channels
 * - Authentication-based feature availability
 * - Emergency support options
 */
const HelpPage = () => {
  const { isAuthenticated, user, isPreview, isAdmin } = useAuth();
  const [adminUsers, setAdminUsers] = useState<Array<{username: string, email: string, phone: string}>>([]);
  const authService = NewAuthService.getInstance();

  // Load admin users on component mount
  useEffect(() => {
    loadAdminUsers();
    
    // Set up real-time updates every 3 seconds for admin contact info
    const interval = setInterval(() => {
      loadAdminUsers();
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  /**
   * Load all admin users for contact information
   */
  const loadAdminUsers = async () => {
    try {
      // Read directly from localStorage for real-time updates
      const usersData = localStorage.getItem('thika_users');
      const allUsers = usersData ? JSON.parse(usersData) : [];
      
      const admins = allUsers
        .filter(u => u.isAdmin && u.username !== 'soni-q') // Exclude soni-q from contact list
        .map(u => ({
          username: u.username,
          email: u.email,
          phone: u.phone
        }));
      setAdminUsers(admins);
    } catch (error) {
      console.error('Error loading admin users:', error);
    }
  };

  /**
   * Support options configuration
   * Admin users get different options than regular users
   */
  const supportOptions = isAdmin ? [
    {
      id: 'admin-chat-forum',
      title: 'Admin Chat Forum',
      description: 'Real-time chat with clients and handle support issues',
      icon: <MessageSquare className="h-6 w-6" />,
      requiresAuth: true,
      href: '/admin-chat',
      color: 'text-blue-600'
    },
    {
      id: 'user-manual',
      title: 'User Manual',
      description: 'Comprehensive guide to using all features of the platform',
      icon: <BookOpen className="h-6 w-6" />,
      requiresAuth: false,
      href: '/user-manual',
      color: 'text-purple-600'
    },
    {
      id: 'community-forum',
      title: 'Community Q&A',
      description: 'Monitor and moderate community discussions',
      icon: <Users className="h-6 w-6" />,
      requiresAuth: true,
      href: '/qa-forum',
      color: 'text-indigo-600'
    }
  ] : [
    {
      id: 'smart-router',
      title: 'Smart Help Router',
      description: 'Describe your issue and get intelligent routing to the best support option',
      icon: <Lightbulb className="h-6 w-6" />,
      requiresAuth: true,
      href: null, // Component-based, not a route
      color: 'text-blue-600'
    },
    {
      id: 'ai-assistant',
      title: 'AI Assistant',
      description: 'Get instant answers to common questions with our intelligent AI',
      icon: <Bot className="h-6 w-6" />,
      requiresAuth: true,
      href: '/ask-ai',
      color: 'text-green-600'
    },
    {
      id: 'chat-forum',
      title: 'Chat Forum',
      description: 'Real-time chat with our support team for immediate assistance',
      icon: <MessageSquare className="h-6 w-6" />,
      requiresAuth: true,
      href: '/chat-forum',
      color: 'text-orange-600'
    },
    {
      id: 'user-manual',
      title: 'User Manual',
      description: 'Comprehensive guide to using all features of the platform',
      icon: <BookOpen className="h-6 w-6" />,
      requiresAuth: false,
      href: '/user-manual',
      color: 'text-purple-600'
    },
    {
      id: 'community-forum',
      title: 'Community Q&A',
      description: 'Ask questions and get help from other users in the community',
      icon: <Users className="h-6 w-6" />,
      requiresAuth: true,
      href: '/qa-forum',
      color: 'text-indigo-600'
    },
    {
      id: 'admin-chat',
      title: 'Chat with Admin',
      description: 'Real-time chat with admin support team',
      icon: <MessageSquare className="h-6 w-6" />,
      requiresAuth: true,
      href: '/client-chat',
      color: 'text-blue-600'
    }
  ];

  /**
   * Emergency support options
   */
  const emergencyOptions = [
    {
      title: 'Account Security Issues',
      description: 'Suspected unauthorized access or security concerns',
      urgency: 'high',
      action: 'Contact Admin Immediately'
    },
    {
      title: 'Payment Problems',
      description: 'Failed payments, unauthorized charges, or billing disputes',
      urgency: 'high',
      action: 'Use Admin Support'
    },
    {
      title: 'App Not Working',
      description: 'Critical functionality not working or app crashes',
      urgency: 'medium',
      action: 'Try AI Assistant first, then Admin'
    }
  ];

  /**
   * Get filtered support options based on authentication status
   */
  const getAvailableOptions = () => {
    return supportOptions.filter(option => {
      // Allow all users to access non-auth required options
      if (!option.requiresAuth) return true;
      
      // For auth-required options, check if user is authenticated and not in preview mode
      // Exception: AI Assistant is available to preview users with limits
      if (option.id === 'ai-assistant') {
        return true; // AI Assistant handles preview limits internally
      }
      
      // Community forum is restricted for preview users
      if (option.id === 'community-forum' && isPreview) {
        return false; // Preview users cannot access community forum
      }
      
      // Admin support and other premium features require full authentication
      return isAuthenticated && !isPreview;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <BackButton variant="both" size="sm" />
          </div>
          <div className="flex items-center gap-3">
            <HelpCircle className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Help & Support</h1>
          </div>
          <p className="text-muted-foreground mt-2">
            Get the help you need, when you need it
          </p>
          {user && (
            <p className="text-sm text-muted-foreground mt-1">
              Welcome back, {user.username}! How can we assist you today?
            </p>
          )}
        </div>

        {/* Authentication Status Banner */}
        {!isAuthenticated && (
          <Card className="mb-6 border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-yellow-600" />
                <div>
                  <h3 className="font-semibold text-yellow-800 dark:text-yellow-200">
                    Limited Access
                  </h3>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">
                    Some support features are only available to signed-in users. 
                    <Link to="/signin" className="text-yellow-600 hover:underline ml-1">
                      Sign in
                    </Link> to access AI Assistant, Admin Support, and Community Forum.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Smart Help Router - Only for authenticated users */}
        {isAuthenticated && (
            <div className="mb-8">
              <SmartHelpRouter />
            </div>
        )}

        {/* Support Options Grid */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6">Support Options</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {getAvailableOptions().map((option) => (
              <Card 
                key={option.id} 
                className="hover:shadow-lg transition-all duration-300 cursor-pointer group"
                onClick={() => option.href && (window.location.href = option.href)}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`${option.color}`}>
                      {option.icon}
                    </div>
                    <CardTitle className="text-lg">{option.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{option.description}</p>
                  {option.href ? (
                    <Button asChild className="w-full group-hover:bg-primary/90">
                      <Link to={option.href}>
                        {option.id === 'smart-router' ? 'Use Smart Router' : 'Access Now'}
                      </Link>
                  </Button>
                  ) : option.id === 'admin-contact' ? (
                    <div className="space-y-3">
                      {adminUsers.length > 0 ? (
                        <div className="space-y-3">
                          {adminUsers.map((admin, index) => (
                            <div key={index} className="text-sm space-y-2 p-3 bg-muted/50 rounded-lg">
                              <div className="font-medium text-primary">{admin.username}</div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">📧 Email:</span>
                                <span className="text-primary">{admin.email}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">📱 Phone:</span>
                                <span className="text-primary">{admin.phone}</span>
                              </div>
                            </div>
                          ))}
                          <div className="text-xs text-muted-foreground">
                            Contact any admin directly for urgent issues
                          </div>
                        </div>
                      ) : (
                        <div className="text-sm space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">📧 Email:</span>
                            <span className="text-primary">makopolo@gmail.com</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">📱 Phone:</span>
                            <span className="text-primary">0712345678</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">👤 Username:</span>
                            <span className="text-primary">makopolo</span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Contact admin directly for urgent issues
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-2">
                      <span className="text-sm text-muted-foreground">
                        Available in Smart Router above
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Emergency Support */}
        {isAuthenticated && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-6">Emergency Support</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {emergencyOptions.map((option, index) => (
                <Card key={index} className="border-red-200 bg-red-50 dark:bg-red-900/20">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-red-100 dark:bg-red-900/40 rounded-full flex items-center justify-center flex-shrink-0">
                        <Clock className="h-4 w-4 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-red-800 dark:text-red-200 mb-1">
                          {option.title}
                        </h3>
                        <p className="text-sm text-red-700 dark:text-red-300 mb-3">
                          {option.description}
                        </p>
                        <Badge 
                          variant={option.urgency === 'high' ? 'destructive' : 'secondary'}
                          className="text-xs"
                        >
                          {option.urgency === 'high' ? 'High Priority' : 'Medium Priority'}
                        </Badge>
                        <p className="text-xs text-red-600 dark:text-red-400 mt-2 font-medium">
                          {option.action}
                        </p>
                      </div>
                    </div>
                </CardContent>
              </Card>
              ))}
            </div>
          </div>
        )}

        {/* Quick Tips */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quick Tips for Getting Help</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">For Best Results:</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Be specific about your issue or question</li>
                  <li>• Include error messages or screenshots if applicable</li>
                  <li>• Try the User Manual first for basic questions</li>
                  <li>• Use the Smart Router for intelligent routing</li>
                  <li>• Check Community Q&A for similar issues</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Response Times:</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• AI Assistant: Instant responses</li>
                  <li>• Admin Support: 1-4 hours via SMS</li>
                  <li>• Community Forum: Varies by community activity</li>
                  <li>• User Manual: Available 24/7</li>
                  <li>• Emergency Issues: Prioritized handling</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle>Still Need Help?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <p className="text-muted-foreground mb-4">
                If none of the above options helped, please contact us directly.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                {isAuthenticated ? (
                  <>
                    <Button asChild variant="outline">
                      <Link to="/ask-admin">Contact Admin</Link>
                    </Button>
                    <Button asChild variant="outline">
                      <Link to="/qa-forum">Post in Community</Link>
                    </Button>
                  </>
                ) : (
                  <Button asChild>
                    <Link to="/signin">Sign In for Full Support</Link>
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default HelpPage;