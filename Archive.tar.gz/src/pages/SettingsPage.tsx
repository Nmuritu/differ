import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/back-button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { ArrowLeft, Settings, Palette, Bell, Shield, User, LogOut, Trash2, CreditCard } from 'lucide-react';
import { useAuth } from '@/contexts/NewAuthContext';
import TwoFactorAuth from '@/components/TwoFactorAuth';
import { SubscriptionReminder } from '@/components/ui/subscription-reminder';
import { AccountDeletionModal } from '@/components/ui/account-deletion-modal';
import { useState } from 'react';

/**
 * Settings Page Component
 * 
 * A comprehensive settings page that provides different functionality based on user authentication status:
 * - For authenticated users: Full access to profile, security, subscription, and account management
 * - For non-authenticated users: Sign up and sign in options
 * - For preview users: Limited functionality with upgrade prompts
 * 
 * Features:
 * - Theme customization
 * - Notification preferences
 * - Security settings (password change, 2FA)
 * - Account management
 * - Subscription status and management
 * - Account deletion with security questions
 */
const SettingsPage = () => {
  // Get authentication state and functions from context
  const { user, logout, isAuthenticated, isPreview, isImpersonating, deleteUserAccount } = useAuth();
  
  // State for managing account deletion modal
  const [showDeletionModal, setShowDeletionModal] = useState(false);

  /**
   * Handle user logout
   * Clears user session and redirects to appropriate page
   */
  const handleLogout = () => {
    logout();
  };

  // Get current subscription status for display
  // Simplified subscription status
  const subscriptionStatus = { isActive: true, daysRemaining: 30, isExpired: false };

  /**
   * Configuration for settings sections
   * Each section contains items that are conditionally rendered based on user authentication status
   */
  const settingsSections = [
    // Appearance settings - limited for preview users
    {
      icon: <Palette className="h-5 w-5" />,
      title: "Appearance",
      description: isPreview 
        ? "Basic appearance settings (limited in preview mode)"
        : "Customize the look and feel of the application",
      items: [
        {
          label: "Theme",
          description: isPreview 
            ? "Theme switching available after creating an account"
            : "Switch between light and dark mode",
          action: isPreview 
            ? <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm" disabled>Sign In Required</Button>
            : <ThemeToggle />
        }
      ]
    },
    // Notification settings - limited for preview users
    {
      icon: <Bell className="h-5 w-5" />,
      title: "Notifications",
      description: isPreview 
        ? "Notification preferences (available after sign-in)"
        : "Manage your notification preferences",
      items: [
        {
          label: "Email Notifications",
          description: isPreview 
            ? "Create an account to manage email notifications"
            : "Receive booking confirmations via email",
          action: isPreview 
            ? <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm" disabled>Sign In Required</Button>
            : <Button 
                variant="outline" 
                size="sm" 
                className="w-full sm:w-auto text-xs sm:text-sm"
                onClick={() => {
                  // Toggle email notifications
                  const currentSettings = user?.settings || { notifications: true };
                  const newSettings = { ...currentSettings, notifications: !currentSettings.notifications };
                  // Update user settings (you can implement this in your auth service)
                }}
              >
                {user?.settings?.notifications ? 'Disable' : 'Enable'}
              </Button>
        },
        {
          label: "SMS Alerts",
          description: isPreview 
            ? "Create an account to manage SMS alerts"
            : "Get important updates via SMS",
          action: isPreview 
            ? <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm" disabled>Sign In Required</Button>
            : <Button 
                variant="outline" 
                size="sm" 
                className="w-full sm:w-auto text-xs sm:text-sm"
                onClick={() => {
                  // Toggle SMS alerts
                }}
              >
                Configure
              </Button>
        }
      ]
    },
    // Security settings - password change hidden for preview users
    {
      icon: <Shield className="h-5 w-5" />,
      title: "Privacy & Security",
      description: "Manage your account security and privacy settings",
      items: [
        // Only show password change for non-preview users and not for soni-q
        ...(isPreview || (user?.isPermanent && user?.username === 'soni-q') || user?.username === 'soni-q' || user?.email === 'soni-q@gmail.com' ? [] : [
          {
            label: "Change Password",
            description: (user?.isPermanent && user?.username === 'soni-q') || user?.username === 'soni-q' || user?.email === 'soni-q@gmail.com'
              ? "Soni-q password is permanently set to 12345 and cannot be changed"
              : "Update your account password",
            action: (user?.isPermanent && user?.username === 'soni-q') || user?.username === 'soni-q' || user?.email === 'soni-q@gmail.com'
              ? <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm" disabled>Cannot Change</Button>
              : <Button asChild variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm"><Link to="/change-password">Change</Link></Button>
          }
        ]),
        {
          label: "Two-Factor Authentication",
          description: "Add an extra layer of security",
          action: <Button variant="outline" size="sm" disabled={isPreview}>
            {isPreview ? 'Preview Mode' : 'Enable'}
          </Button>
        }
      ]
    },
    // Account management - different options based on authentication status
    {
      icon: <User className="h-5 w-5" />,
      title: "Account",
      description: "Manage your personal information",
      items: [
        // Profile access - only for authenticated users
        ...(typeof isAuthenticated !== "undefined" && isAuthenticated ? [
          {
            label: "Profile Information",
            description: "Update your personal details",
            action: <Button asChild variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm"><Link to="/edit-profile">Edit</Link></Button>
          }
        ] : []),
        // Authentication actions - different for logged in vs logged out users
        ...(isAuthenticated ? [
          // Hide logout for admin users (makopolo)
          ...(user?.isAdmin ? [] : [
            {
              label: "Sign Out",
              description: "Sign out of your account",
              action: <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm" onClick={handleLogout}>Sign Out</Button>
            }
          ])
        ] : [
          {
            label: "Sign Up",
            description: "Create a new account to access all features",
            action: <Button asChild variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm"><Link to="/register">Sign Up</Link></Button>
          },
          {
            label: "Sign In",
            description: "Access your existing account",
            action: <Button asChild variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm"><Link to="/signin">Sign In</Link></Button>
          }
        ])
      ]
    },
    // Subscription management - shows current plan and status
    {
      icon: <CreditCard className="h-5 w-5" />,
      title: "Subscription",
      description: "Manage your subscription and payments",
      items: [
        {
          label: "Current Plan",
          description: user?.selectedPlan || "No active plan",
          action: <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              // You can implement plan details modal here
            }}
          >
            View Details
          </Button>
        },
        {
          label: "Subscription Status",
          description: subscriptionStatus.isExpired 
            ? "Expired" 
            : `${subscriptionStatus.daysRemaining} days remaining`,
          action: <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              if (subscriptionStatus.isExpired) {
                // Redirect to payment page or show renewal modal
              } else {
                // Show subscription details
              }
            }}
          >
            {subscriptionStatus.isExpired ? "Renew" : "Active"}
          </Button>
        }
      ]
    },
        // Danger zone - destructive actions like account deletion (hidden for admin and permanent users)
        ...(user?.isAdmin || user?.isPermanent ? [] : [
          {
            icon: <Trash2 className="h-5 w-5" />,
            title: "Danger Zone",
            description: "Irreversible and destructive actions",
            items: [
              {
                label: "Delete Account",
                description: (() => {
                    // Simplified financial balance
                    const financialBalance = { canDelete: true, outstandingDebt: 0, canCheckout: true, totalCredits: 0 };
                  if (!financialBalance.canCheckout) {
                    return `Cannot delete account. Outstanding debt of KSh ${financialBalance.outstandingDebt} must be settled first.`;
                  } else if (financialBalance.totalCredits > 0) {
                    return `Account deletion will process refund of KSh ${financialBalance.totalCredits} to your ${user?.paymentMethod || 'M-Pesa'} account.`;
                  } else {
                    return "Permanently delete your account and all data";
                  }
                })(),
                action: <Button 
                  variant="destructive" 
                  size="sm" 
                  className="w-full sm:w-auto text-xs sm:text-sm"
                  onClick={async () => {
                    if (!user?.id) return;
                    
                    const confirmed = window.confirm(
                      'Are you sure you want to delete your account? This action cannot be undone and will permanently remove all your data.'
                    );
                    
                    if (confirmed) {
                      try {
                        const success = await deleteUserAccount(user.id);
                        if (success) {
                          alert('Your account and all related data have been permanently deleted.');
                        } else {
                          alert('Failed to delete account. Please try again or contact support.');
                        }
                      } catch (error) {
                        console.error('Account deletion error:', error);
                        alert('An error occurred while deleting your account. Please try again.');
                      }
                    }
                  }}
                  disabled={isPreview}
                >
                  Delete Account
                </Button>
              }
            ]
          }
        ])
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8 max-w-4xl">
        {/* Subscription reminder banner - shows for authenticated users */}
        <SubscriptionReminder />
        
        {/* Page header with navigation and title */}
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center gap-2 sm:gap-4 mb-4">
            <BackButton variant="both" size="sm" className="flex-shrink-0" />
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Settings className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
            <h1 className="text-2xl sm:text-3xl font-bold">Settings</h1>
          </div>
          <p className="text-sm sm:text-base text-muted-foreground mt-2">
            Manage your application preferences and account settings
          </p>
        </div>

        {/* User information card - only shown for logged-in users */}
        {user && (
          <Card className="mb-4 sm:mb-6">
            <CardHeader className="pb-3 sm:pb-6">
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                  {user.profileImage ? (
                    <img
                      src={user.profileImage}
                      alt={`${user.username}'s profile`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <CardTitle className="text-lg sm:text-xl truncate">{user.username}</CardTitle>
                  <p className="text-xs sm:text-sm text-muted-foreground truncate">{user.email}</p>
                  <p className="text-xs sm:text-sm text-muted-foreground truncate">{user.phone}</p>
                </div>
              </div>
            </CardHeader>
                <CardContent>
                  {(!user?.isPermanent || user?.username === 'soni-q') && !isImpersonating && (
                    <Button onClick={handleLogout} variant="outline" className="w-full">
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  )}
                  {isImpersonating && (
                    <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200">
                      <Shield className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        Cannot sign out during impersonation. Use "Exit Impersonation" in the header.
                      </p>
                    </div>
                  )}
                  {user?.isPermanent && user?.username !== 'soni-q' && !isImpersonating && (
                    <div className="text-center p-4 bg-primary/10 rounded-lg">
                      <Shield className="h-6 w-6 text-primary mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">
                        {user?.isAdmin ? 'Admin users' : 'Permanent users'} cannot be signed out
                      </p>
                    </div>
                  )}
                </CardContent>
          </Card>
        )}

        {/* Admin/Permanent Account Notice */}
        {(user?.isAdmin || user?.isPermanent) && (
          <Card className="mb-6 border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-blue-600" />
                <div>
                  <h3 className="font-semibold text-blue-800 dark:text-blue-200">
                    {user?.isAdmin ? 'Admin Account Restrictions' : 'Permanent Account Restrictions'}
                  </h3>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                    {user?.isAdmin 
                      ? 'Admin accounts are permanent and cannot be checked out or deleted. This ensures continuous system operation and administrative access. Checkout and account deletion options are not available for admin users.'
                      : 'Permanent accounts cannot be checked out or deleted. This ensures continuous system access and data integrity. Checkout and account deletion options are not available for permanent users.'
                    }
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Dynamic settings sections based on user authentication status */}
        <div className="space-y-4 sm:space-y-6">
          {settingsSections.map((section, sectionIndex) => (
            <Card key={sectionIndex} className="hover:shadow-card-hover transition-all duration-300">
              <CardHeader className="pb-3 sm:pb-6">
                <div className="flex items-start gap-3 sm:gap-4">
                  <div className="text-primary flex-shrink-0 mt-1">
                    {section.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <CardTitle className="text-lg sm:text-xl">{section.title}</CardTitle>
                    <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                      {section.description}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {section.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-3 border-b border-border last:border-b-0 gap-3 sm:gap-4">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm sm:text-base">{item.label}</h4>
                        <p className="text-xs sm:text-sm text-muted-foreground mt-1 break-words">
                          {item.description}
                        </p>
                      </div>
                      <div className="flex-shrink-0 w-full sm:w-auto">
                        {item.action}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Two-Factor Authentication - only for authenticated users */}
        {user && !user.isPreview && (
          <div className="mt-6">
            <TwoFactorAuth />
          </div>
        )}

        {/* Help and support section */}
        <div className="mt-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Need Help?</h3>
                <p className="text-muted-foreground mb-4">
                  If you have any questions or need assistance with your settings, 
                  please don't hesitate to contact our support team.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button asChild variant="outline">
                    <Link to="/">Contact Support</Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link to="/">View Help Center</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Account deletion modal with financial settlement */}
      <AccountDeletionModal
        isOpen={showDeletionModal}
        onClose={() => setShowDeletionModal(false)}
      />
    </div>
  );
};

export default SettingsPage;
