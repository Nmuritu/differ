import { useState, useEffect } from 'react';
import FacilityService, { Facility, FacilityUpdate } from '@/services/FacilityService';

/**
 * Hook for using facilities throughout the application
 * Provides real-time updates when facilities are modified
 */
export const useFacilities = () => {
  const facilityService = FacilityService.getInstance();
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load initial facilities
    setFacilities(facilityService.getFacilities());
    setIsLoading(false);

    // Subscribe to facility updates
    const unsubscribe = facilityService.subscribe((_update: FacilityUpdate) => {
      setFacilities(facilityService.getFacilities());
    });

    // Listen for custom facility update events
    const handleFacilityUpdate = (_event: CustomEvent) => {
      setFacilities(facilityService.getFacilities());
    };

    window.addEventListener('facilityUpdate', handleFacilityUpdate as EventListener);

    return () => {
      unsubscribe();
      window.removeEventListener('facilityUpdate', handleFacilityUpdate as EventListener);
    };
  }, [facilityService]);

  return {
    facilities,
    activeFacilities: facilityService.getActiveFacilities(),
    facilitiesByCategory: (category: Facility['category']) => facilityService.getFacilitiesByCategory(category),
    isLoading,
    facilityService
  };
};

export default useFacilities;
