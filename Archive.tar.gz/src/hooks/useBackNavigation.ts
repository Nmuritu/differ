import { useNavigate, useLocation } from 'react-router-dom';
import { useCallback } from 'react';

/**
 * Custom hook for smart back navigation
 * 
 * Provides intelligent navigation that goes to the previous page
 * or falls back to a default route if no history exists.
 */
export const useBackNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  /**
   * Navigate back to the previous page
   * Falls back to home if no history exists
   */
  const goBack = useCallback(() => {
    // Check if we have history to go back to
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      // Fallback to home page if no history
      navigate('/home');
    }
  }, [navigate]);

  /**
   * Navigate to a specific fallback route
   * @param fallbackRoute - Route to navigate to if no history
   */
  const goBackOrTo = useCallback((fallbackRoute: string) => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(fallbackRoute);
    }
  }, [navigate]);

  /**
   * Navigate to home page
   */
  const goHome = useCallback(() => {
    navigate('/home');
  }, [navigate]);

  /**
   * Get the current page name for display
   */
  const getCurrentPageName = useCallback(() => {
    const path = location.pathname;
    const pageNames: Record<string, string> = {
      '/': 'Sign In',
      '/home': 'Home',
      '/rooms': 'Rooms',
      '/booking': 'Booking',
      '/payment': 'Payment',
      '/settings': 'Settings',
      '/register': 'Registration',
      '/signin': 'Sign In',
      '/change-password': 'Change Password',
      '/forgot-password': 'Forgot Password',
      '/profile': 'Profile',
      '/edit-profile': 'Edit Profile',
      '/help': 'Help',
      '/user-manual': 'User Manual',
      '/ask-ai': 'AI Assistant',
      '/ask-admin': 'Ask Admin',
      '/qa-forum': 'Q&A Forum',
      '/admin': 'Admin Panel',
      '/admin-forum': 'Admin Forum'
    };
    
    return pageNames[path] || 'Page';
  }, [location.pathname]);

  return {
    goBack,
    goBackOrTo,
    goHome,
    getCurrentPageName,
    currentPath: location.pathname
  };
};

export default useBackNavigation;