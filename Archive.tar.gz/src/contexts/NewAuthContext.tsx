/**
 * New Authentication Context - Bulletproof & Reliable
 * 
 * This completely replaces the old AuthContext with a more robust implementation
 * that uses IndexedDB and proper error handling. It's designed to be bulletproof
 * and handle all the authentication issues we've been experiencing.
 * 
 * Key Features:
 * - Uses IndexedDB for persistent storage
 * - Proper initialization sequence
 * - Comprehensive error handling
 * - Built-in retry mechanisms
 * - Clean state management
 * - Full TypeScript support
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import NewAuthService, { AppUser, AuthResult, RegistrationData } from '@/services/NewAuthService';
import DataMigrationService from '@/services/DataMigrationService';
import { autoRecovery } from '@/utils/stabilityUtils';

// Context interface - defines what the context provides
interface AuthContextType {
  // User state
  user: AppUser | null;
  isLoading: boolean;
  isInitialized: boolean;
  
  // Authentication methods
  login: (loginField: string, password: string) => Promise<AuthResult>;
  register: (userData: RegistrationData) => Promise<AuthResult>;
  logout: () => Promise<void>;
  loginAsPreview: (userData: Partial<AppUser>) => void;
  resetPassword: (loginField: string, newPassword: string) => Promise<AuthResult>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<AuthResult>;
  
  // User checks
  isAuthenticated: boolean;
  isAdmin: boolean;
  isPreview: boolean;
  
  // Admin methods
  getAllUsers: () => Promise<AppUser[]>;
  getAuthStats: () => Promise<{ totalUsers: number; activeUsers: number; adminUsers: number; previewUsers: number }>;
  resetAllData: () => Promise<void>;
  deleteUserAccount: (userId: string) => Promise<boolean>;
  deleteUserByUsername: (username: string) => Promise<boolean>;
  deleteUserByEmail: (email: string) => Promise<boolean>;
  deleteUserByPhone: (phone: string) => Promise<boolean>;
  promoteUserToAdmin: (userId: string) => Promise<boolean>;
  demoteAdminToUser: (userId: string) => Promise<boolean>;
  clearNonPermanentUsers: () => Promise<boolean>;
  
  // Utility methods
  refreshUser: () => Promise<void>;
  
  // Impersonation methods
  impersonateUser: (username: string) => Promise<boolean>;
  exitImpersonation: () => void;
  isImpersonating: boolean;
  originalAdminUser: AppUser | null;
  
  // Simplified methods for compatibility (to be fully implemented later)
  updateProfile?: (data: Record<string, unknown>) => Promise<boolean>;
  updateProfilePhoto?: (file: File) => Promise<boolean>;
  getSystemErrors?: () => Array<{ id: string; type: string; message: string; timestamp: Date }>;
  resolveSystemError?: (id: string) => Promise<boolean>;
  logSystemError?: (type: string, message: string) => Promise<void>;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Props for the AuthProvider component
interface AuthProviderProps {
  children: ReactNode;
}

/**
 * Authentication Provider Component
 * 
 * Wraps the entire application and provides authentication state and methods
 * to all child components. Handles initialization, state management, and
 * provides a clean API for authentication operations.
 */
export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // State management
  const [user, setUser] = useState<AppUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isImpersonating, setIsImpersonating] = useState(false);
  const [originalAdminUser, setOriginalAdminUser] = useState<AppUser | null>(null);
  
  // Get the authentication service instance
  const authService = NewAuthService.getInstance();

  /**
   * Initialize the authentication system
   * This runs once when the app starts and sets up everything
   */
  useEffect(() => {
    const initializeAuth = async () => {
      setIsLoading(true);
      try {
        autoRecovery();
        
        // Run data migrations first
        const migrationService = DataMigrationService.getInstance();
        migrationService.runMigrations();
        
        await authService.initialize();
        
        const currentUser = authService.getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
        } else {
          // If no user found, create preview session
          authService.loginAsPreview({
            username: 'Preview User',
            email: 'preview@example.com',
            phone: '0000000000'
          });
          const previewUser = authService.getCurrentUser();
          if (previewUser) {
            setUser(previewUser);
          }
        }
        setIsInitialized(true);
      } catch (error) {
        console.error('Auth init failed:', error);
        
        // Try to restore from backup
        const migrationService = DataMigrationService.getInstance();
        const restored = migrationService.restoreUserData();
        
        if (restored) {
          await authService.initialize();
          const currentUser = authService.getCurrentUser();
          if (currentUser) {
            setUser(currentUser);
            setIsInitialized(true);
            setIsLoading(false);
            return;
          }
        }
        
        localStorage.removeItem('currentUser');
        await authService.initialize();
        // Create preview session on error
        authService.loginAsPreview({
          username: 'Preview User',
          email: 'preview@example.com',
          phone: '0000000000'
        });
        const previewUser = authService.getCurrentUser();
        if (previewUser) {
          setUser(previewUser);
        }
        setIsInitialized(true);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  /**
   * Login function
   * Authenticates a user with username/email/phone and password
   */
  const login = async (loginField: string, password: string): Promise<AuthResult> => {
    try {
      
      const result = await authService.login(loginField, password);
      
      if (result.success && result.user) {
        setUser(result.user);
      } else {
      }
      
      return result;
    } catch (error) {
      console.error(' Login error:', error);
      return {
        success: false,
        error: 'Login failed. Please try again.'
      };
    }
  };

  /**
   * Register function
   * Creates a new user account
   */
  const register = async (userData: RegistrationData): Promise<AuthResult> => {
    try {
      
      const result = await authService.register(userData);
      
      if (result.success && result.user) {
        // Don't automatically log in after registration
        // User should sign in manually for security
      } else {
      }
      
      return result;
    } catch (error) {
      console.error(' Registration error:', error);
      return {
        success: false,
        error: 'Registration failed. Please try again.'
      };
    }
  };

  /**
   * Logout function
   * Logs out the current user and clears session
   */
  const logout = async (): Promise<void> => {
    try {
      // Prevent logout during impersonation
      if (isImpersonating) {
        return;
      }
      
      // Special case: soni-q can logout even though they're permanent
      if (user?.isPermanent && user.username !== 'soni-q') {
        return;
      }

      // Admins cannot logout (except soni-q)
      if (user?.isAdmin && user.username !== 'soni-q') {
        return;
      }
      
      await authService.logout();
      
      // Clear all state
      setUser(null);
      setIsImpersonating(false);
      setOriginalAdminUser(null);
      
      // Use React Router navigation instead of window.location.href
      // This prevents 404 errors with SPA routing
      if (typeof window !== 'undefined') {
        // Use replace to prevent back button issues
        window.history.replaceState(null, '', '/signin');
        // Trigger a popstate event to update the router
        window.dispatchEvent(new PopStateEvent('popstate'));
      }
      
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  /**
   * Preview login function
   * Creates a temporary preview session for demo purposes
   */
  const loginAsPreview = (userData: Partial<AppUser>): void => {
    try {
      authService.loginAsPreview(userData);
      const previewUser = authService.getCurrentUser();
      if (previewUser) {
        setUser(previewUser);
      }
    } catch (error) {
      console.error(' Preview login error:', error);
    }
  };

  /**
   * Reset password function (forgot password)
   * Resets password for a user using login field
   */
  const resetPassword = async (loginField: string, newPassword: string): Promise<AuthResult> => {
    try {
      return await authService.resetPassword(loginField, newPassword);
    } catch (error) {
      console.error(' Reset password error:', error);
      return {
        success: false,
        error: 'Password reset failed. Please try again.'
      };
    }
  };

  /**
   * Change password function
   * Changes password for the current logged-in user
   */
  const changePassword = async (currentPassword: string, newPassword: string): Promise<AuthResult> => {
    try {
      return await authService.changePassword(currentPassword, newPassword);
    } catch (error) {
      console.error(' Change password error:', error);
      return {
        success: false,
        error: 'Password change failed. Please try again.'
      };
    }
  };

  /**
   * Get all users (admin only)
   * Returns list of all registered users
   */
  const getAllUsers = async (): Promise<AppUser[]> => {
    try {
      return await authService.getAllUsers();
    } catch (error) {
      console.error(' Error getting all users:', error);
      return [];
    }
  };

  /**
   * Get authentication statistics (admin only)
   * Returns useful stats about the authentication system
   */
  const getAuthStats = async (): Promise<{ totalUsers: number; activeUsers: number; adminUsers: number; previewUsers: number }> => {
    try {
      return await authService.getAuthStats();
    } catch (error) {
      console.error(' Error getting auth stats:', error);
      return { totalUsers: 0, activeUsers: 0, adminUsers: 0, previewUsers: 0 };
    }
  };

  /**
   * Reset all data (admin only)
   * USE WITH CAUTION - This deletes everything!
   */
  const resetAllData = async (): Promise<void> => {
    try {
      await authService.resetAllData();
      setUser(null);
    } catch (error) {
      console.error(' Error resetting data:', error);
      throw error;
    }
  };

  /**
   * Delete a user account and all related data
   * @param userId - The ID of the user to delete
   * @returns Promise<boolean> - Success status
   */
  const deleteUserAccount = async (userId: string): Promise<boolean> => {
    try {
      const success = await authService.deleteUserAccount(userId);
      if (success) {
      }
      return success;
    } catch (error) {
      console.error('Error deleting user account:', error);
      return false;
    }
  };

  /**
   * Promote a user to admin (admin only)
   * @param userId - ID of user to promote
   * @returns Promise<boolean> - Success status
   */
  const promoteUserToAdmin = async (userId: string): Promise<boolean> => {
    try {
      const success = await authService.promoteUserToAdmin(userId);
      if (success) {
      }
      return success;
    } catch (error) {
      console.error('Error promoting user to admin:', error);
      return false;
    }
  };

  /**
   * Demote an admin to regular user (admin only)
   * @param userId - ID of admin to demote
   * @returns Promise<boolean> - Success status
   */
  const demoteAdminToUser = async (userId: string): Promise<boolean> => {
    try {
      const success = await authService.demoteAdminToUser(userId);
      if (success) {
      }
      return success;
    } catch (error) {
      console.error('Error demoting admin to user:', error);
      return false;
    }
  };

  /**
   * Clear all non-permanent users (admin only)
   * @returns Promise<boolean> - Success status
   */
  const clearNonPermanentUsers = async (): Promise<boolean> => {
    try {
      const success = await authService.clearNonPermanentUsers();
      if (success) {
      }
      return success;
    } catch (error) {
      console.error('Error clearing non-permanent users:', error);
      return false;
    }
  };

  /**
   * Refresh user data
   * Updates the current user with latest data from database
   */
  const refreshUser = async (): Promise<void> => {
    try {
      if (user && !user.isPreview) {
        // For non-preview users, refresh from database
        // TODO: Implement proper user refresh method in AuthService
      }
    } catch (error) {
      console.error(' Error refreshing user:', error);
    }
  };

  /**
   * Simplified compatibility methods
   * These provide basic functionality for components that haven't been fully migrated
   */
  const updateProfile = async (_data: Record<string, unknown>): Promise<boolean> => {
    try {
      // TODO: Implement proper profile update
      return true;
    } catch (error) {
      console.error(' Error updating profile:', error);
      return false;
    }
  };

  const updateProfilePhoto = async (_file: File): Promise<boolean> => {
    try {
      // TODO: Implement proper photo update
      return true;
    } catch (error) {
      console.error(' Error updating profile photo:', error);
      return false; 
    }
  };

  const getSystemErrors = (): Array<{ id: string; type: string; message: string; timestamp: Date }> => {
    // TODO: Implement proper system error retrieval
    return [];
  };

  const resolveSystemError = async (_id: string): Promise<boolean> => {
    try {
      // TODO: Implement proper error resolution
      return true;
    } catch (error) {
      console.error(' Error resolving system error:', error);
      return false;
    }
  };

  const logSystemError = async (_type: string, _message: string): Promise<void> => {
    try {
      // TODO: Implement proper error logging
    } catch (error) {
      console.error(' Error logging system error:', error);
    }
  };

  /**
   * Impersonate another user (admin only)
   * Allows admin to temporarily sign in as another user
   */
  const impersonateUser = async (username: string): Promise<boolean> => {
    try {
      // Only allow admin users to impersonate
      if (!user?.isAdmin) {
        return false;
      }

      // Only allow impersonation of soni-q
      if (username !== 'soni-q') {
        return false;
      }

      // Get the target user
      const allUsers = await authService.getAllUsers();
      const targetUser = allUsers.find(u => u.username === username);
      
      if (!targetUser) {
        return false;
      }

      // Store original admin user
      setOriginalAdminUser(user);
      setIsImpersonating(true);
      setUser(targetUser);
      
      return true;
    } catch (error) {
      console.error('Impersonation error:', error);
      return false;
    }
  };

  /**
   * Exit impersonation and return to original admin user
   */
  const exitImpersonation = (): void => {
    if (isImpersonating && originalAdminUser) {
      setUser(originalAdminUser);
      setIsImpersonating(false);
      setOriginalAdminUser(null);
    }
  };

  // Computed values
  const isAuthenticated = authService.isAuthenticated();
  const isAdmin = authService.isAdmin();
  const isPreview = authService.isPreview();

  // Context value
  const contextValue: AuthContextType = {
    // State
    user,
    isLoading,
    isInitialized,
    
    // Methods
    login,
    register,
    logout,
    loginAsPreview,
    resetPassword,
    changePassword,
    
    // Computed values
    isAuthenticated,
    isAdmin,
    isPreview,
    
    // Admin methods
    getAllUsers,
    getAuthStats,
    resetAllData,
    deleteUserAccount,
    deleteUserByUsername: async (username: string) => {
      try {
        if (!user?.isAdmin) {
          return false;
        }
        return await authService.deleteUserByUsername(username);
      } catch (error) {
        console.error('Error deleting user by username:', error);
        return false;
      }
    },
    deleteUserByEmail: async (email: string) => {
      try {
        if (!user?.isAdmin) {
          return false;
        }
        return await authService.deleteUserByEmail(email);
      } catch (error) {
        console.error('Error deleting user by email:', error);
        return false;
      }
    },
    deleteUserByPhone: async (phone: string) => {
      try {
        if (!user?.isAdmin) {
          return false;
        }
        return await authService.deleteUserByPhone(phone);
      } catch (error) {
        console.error('Error deleting user by phone:', error);
        return false;
      }
    },
    promoteUserToAdmin,
    demoteAdminToUser,
    clearNonPermanentUsers,
    
    // Utility methods
    refreshUser,
    
    // Impersonation methods
    impersonateUser,
    exitImpersonation,
    isImpersonating,
    originalAdminUser,
    
    // Compatibility methods
    updateProfile,
    updateProfilePhoto,
    getSystemErrors,
    resolveSystemError,
    logSystemError
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Custom hook to use the authentication context
 * 
 * This hook provides easy access to authentication state and methods
 * from any component in the application.
 * 
 * @returns AuthContextType - The authentication context
 * @throws Error if used outside of AuthProvider
 */
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};

/**
 * Higher-order component for protecting routes
 * 
 * Wraps components that require authentication and redirects
 * unauthenticated users to the sign-in page.
 */
export const withAuth = <P extends object>(Component: React.ComponentType<P>) => {
  return (props: P) => {
    const { isAuthenticated, isLoading } = useAuth();
    
    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      );
    }
    
    if (!isAuthenticated) {
      // In a real app, you'd redirect to sign-in page here
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Authentication Required</h2>
            <p className="text-muted-foreground">Please sign in to access this page.</p>
          </div>
        </div>
      );
    }
    
    return <Component {...props} />;
  };
};

/**
 * Higher-order component for admin-only routes
 * 
 * Wraps components that require admin access and shows
 * an error message for non-admin users.
 */
export const withAdminAuth = <P extends object>(Component: React.ComponentType<P>) => {
  return (props: P) => {
    const { isAuthenticated, isAdmin, isLoading } = useAuth();
    
    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      );
    }
    
    if (!isAuthenticated) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Authentication Required</h2>
            <p className="text-muted-foreground">Please sign in to access this page.</p>
          </div>
        </div>
      );
    }
    
    if (!isAdmin) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Admin Access Required</h2>
            <p className="text-muted-foreground">You don't have permission to access this page.</p>
          </div>
        </div>
      );
    }
    
    return <Component {...props} />;
  };
};

export default AuthContext;
