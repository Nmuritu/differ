import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { rooms as initialRooms } from '@/data/rooms';
import ImageService from '@/services/ImageService';

/**
 * Room management interface for admin operations
 */
interface RoomManagement {
  name: string;
  price: number;
  available: number;
  occupied: number;
  underMaintenance: number;
  maxRooms: number;
  image: string;
  description: string;
}

/**
 * Room context type definition
 */
interface RoomContextType {
  // Room data from the main rooms array
  rooms: typeof initialRooms;
  // Selected room state
  selectedRoom: string | null;
  // Admin room management data
  roomManagement: {
    single: RoomManagement;
    double: RoomManagement;
    suite: RoomManagement;
  };
  // Functions to update room data
  updateRoomPrice: (roomType: 'single' | 'double' | 'suite', price: number) => void;
  updateRoomAvailability: (roomType: 'single' | 'double' | 'suite', available: number) => void;
  updateRoomOccupied: (roomType: 'single' | 'double' | 'suite', occupied: number) => void;
  updateRoomUnderMaintenance: (roomType: 'single' | 'double' | 'suite', underMaintenance: number) => void;
  updateRoomMaxRooms: (roomType: 'single' | 'double' | 'suite', maxRooms: number) => void;
  updateRoomImage: (roomType: 'single' | 'double' | 'suite', image: string) => void;
  updateRoomDescription: (roomType: 'single' | 'double' | 'suite', description: string) => void;
  resetRoomToDefault: (roomType: 'single' | 'double' | 'suite') => { success: boolean; message: string; alreadyDefault?: boolean };
  // Room selection functions
  setSelectedRoom: (roomId: string | null) => void;
  getSelectedRoom: () => typeof initialRooms[0] | null;
  // Function to sync room availability with bookings
  syncRoomAvailability: () => void;
  // Function to get room statistics
  getRoomStats: () => {
    totalRooms: number;
    availableRooms: number;
    occupiedRooms: number;
    byType: {
      single: { total: number; available: number; occupied: number };
      double: { total: number; available: number; occupied: number };
      suite: { total: number; available: number; occupied: number };
    };
  };
}

// Create the room context
const RoomContext = createContext<RoomContextType | undefined>(undefined);

/**
 * Room provider component
 * Manages room data synchronization between main rooms array and admin management
 */
export const RoomProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Main rooms array (from data/rooms.ts)
  const [rooms, setRooms] = useState(initialRooms);
  
  // Selected room state
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);
  
  // Admin room management data - Updated for 250 rooms total (all prices above minimum of 500)
  const [roomManagement, setRoomManagement] = useState({
    single: {
      name: 'Single Room',
      price: 5500, // Above minimum of 500
      available: 55,
      occupied: 55,
      underMaintenance: 0,
      maxRooms: 110,
      image: ImageService.getInstance().getRoomImage('single'),
      description: 'Perfect for individual students who value privacy'
    },
    double: {
      name: 'Double Room',
      price: 8500, // Above minimum of 500
      available: 57,
      occupied: 23,
      underMaintenance: 0,
      maxRooms: 80,
      image: ImageService.getInstance().getRoomImage('double'),
      description: 'Share with a friend and save on costs'
    },
    suite: {
      name: 'Suite',
      price: 12500, // Above minimum of 500
      available: 45,
      occupied: 15,
      underMaintenance: 0,
      maxRooms: 60,
      image: ImageService.getInstance().getRoomImage('suite'),
      description: 'Luxurious accommodation with extra amenities'
    }
  });

  /**
   * Load room management data from localStorage on mount
   */
  useEffect(() => {
    try {
      const savedRoomManagement = localStorage.getItem('roomManagement');
      if (savedRoomManagement) {
        const parsed = JSON.parse(savedRoomManagement);
        setRoomManagement(parsed);
      }
    } catch (error) {
      console.error('Error loading room management data:', error);
    }

  }, []);

  /**
   * Save room management data to localStorage whenever it changes
   */
  useEffect(() => {
    try {
      localStorage.setItem('roomManagement', JSON.stringify(roomManagement));
    } catch (error) {
      console.error('Error saving room management data:', error);
    }
  }, [roomManagement]);

  /**
   * Sync rooms array with room management data
   * This ensures the main rooms array reflects admin changes
   */
  useEffect(() => {
    const updatedRooms = initialRooms.map(room => {
      const roomType = room.type as 'single' | 'double' | 'suite';
      const management = roomManagement[roomType];
      
      if (management) {
        // Calculate room number from ID (e.g., "single-01" -> 1)
        const roomNumber = parseInt(room.id.split('-')[1]);
        
        return {
          ...room,
          price: management.price,
          image: management.image,
          // Keep original availability logic from rooms.ts
          isAvailable: roomNumber <= management.available
        };
      }
      return room;
    });
    
    setRooms(updatedRooms);
  }, [roomManagement]);

  /**
   * Update room price with validation
   */
  const updateRoomPrice = (roomType: 'single' | 'double' | 'suite', price: number) => {
    // Validate minimum price
    if (price < 4500) {
      console.error('Invalid price: Minimum room price is KSh 4,500');
      return;
    }
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        price
      }
    }));
    
    // Update the actual rooms array
    setRooms(prevRooms => 
      prevRooms.map(room => {
        if (room.type === roomType) {
          return {
            ...room,
            price
          };
        }
        return room;
      })
    );
  };

  /**
   * Update room availability
   */
  const updateRoomAvailability = (roomType: 'single' | 'double' | 'suite', available: number) => {
    const clampedAvailable = Math.max(0, Math.min(available, roomManagement[roomType].maxRooms));
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        available: clampedAvailable
      }
    }));
    
    // Update the actual rooms array
    setRooms(prevRooms => 
      prevRooms.map(room => {
        if (room.type === roomType) {
          const roomNumber = parseInt(room.id.split('-')[1]);
          return {
            ...room,
            isAvailable: roomNumber <= clampedAvailable
          };
        }
        return room;
      })
    );
  };

  /**
   * Update room image
   */
  const updateRoomImage = (roomType: 'single' | 'double' | 'suite', image: string) => {
    // Update through ImageService to trigger global updates
    ImageService.getInstance().updateRoomImage(roomType, image);
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        image
      }
    }));
    
    // Update the actual rooms array
    setRooms(prevRooms => 
      prevRooms.map(room => {
        if (room.type === roomType) {
          return {
            ...room,
            image
          };
        }
        return room;
      })
    );
  };

  /**
   * Update room description
   */
  const updateRoomDescription = (roomType: 'single' | 'double' | 'suite', description: string) => {
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        description
      }
    }));
  };

  /**
   * Update occupied rooms count
   */
  const updateRoomOccupied = (roomType: 'single' | 'double' | 'suite', occupied: number) => {
    const maxRooms = roomManagement[roomType].maxRooms;
    const underMaintenance = roomManagement[roomType].underMaintenance;
    
    // Ensure occupied doesn't exceed total rooms minus maintenance
    const clampedOccupied = Math.max(0, Math.min(occupied, maxRooms - underMaintenance));
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        occupied: clampedOccupied,
        // Recalculate available rooms
        available: maxRooms - clampedOccupied - underMaintenance
      }
    }));
  };

  /**
   * Update under maintenance rooms count
   */
  const updateRoomUnderMaintenance = (roomType: 'single' | 'double' | 'suite', underMaintenance: number) => {
    const maxRooms = roomManagement[roomType].maxRooms;
    const occupied = roomManagement[roomType].occupied;
    
    // Ensure under maintenance doesn't exceed total rooms minus occupied
    const clampedUnderMaintenance = Math.max(0, Math.min(underMaintenance, maxRooms - occupied));
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        underMaintenance: clampedUnderMaintenance,
        // Recalculate available rooms
        available: maxRooms - occupied - clampedUnderMaintenance
      }
    }));
  };

  /**
   * Update maximum rooms count
   */
  const updateRoomMaxRooms = (roomType: 'single' | 'double' | 'suite', maxRooms: number) => {
    const currentOccupied = roomManagement[roomType].occupied;
    const currentUnderMaintenance = roomManagement[roomType].underMaintenance;
    
    // Ensure maxRooms is at least the sum of occupied and under maintenance
    const clampedMaxRooms = Math.max(maxRooms, currentOccupied + currentUnderMaintenance);
    
    setRoomManagement(prev => ({
      ...prev,
      [roomType]: {
        ...prev[roomType],
        maxRooms: clampedMaxRooms,
        // Recalculate available rooms
        available: clampedMaxRooms - currentOccupied - currentUnderMaintenance
      }
    }));
  };

  /**
   * Reset room to default distribution (preserves price)
   * Returns status information for popup messages
   */
  const resetRoomToDefault = (roomType: 'single' | 'double' | 'suite') => {
    const currentPrice = roomManagement[roomType].price;
    const currentImage = roomManagement[roomType].image;
    const currentDescription = roomManagement[roomType].description;
    
    // Default room distributions
    const defaultDistributions = {
      single: {
        maxRooms: 110,
        available: 55,
        occupied: 55,
        underMaintenance: 0
      },
      double: {
        maxRooms: 80,
        available: 57,
        occupied: 23,
        underMaintenance: 0
      },
      suite: {
        maxRooms: 60,
        available: 45,
        occupied: 15,
        underMaintenance: 0
      }
    };

    const defaults = defaultDistributions[roomType];
    const currentRoom = roomManagement[roomType];
    
    // Check if already at default settings
    const isAlreadyDefault = 
      currentRoom.maxRooms === defaults.maxRooms &&
      currentRoom.available === defaults.available &&
      currentRoom.occupied === defaults.occupied &&
      currentRoom.underMaintenance === defaults.underMaintenance;
    
    if (isAlreadyDefault) {
      return {
        success: false,
        message: `${roomManagement[roomType].name} is already at default settings`,
        alreadyDefault: true
      };
    }
    
    try {
      setRoomManagement(prev => ({
        ...prev,
        [roomType]: {
          ...prev[roomType],
          maxRooms: defaults.maxRooms,
          available: defaults.available,
          occupied: defaults.occupied,
          underMaintenance: defaults.underMaintenance,
          // Preserve price, image, and description
          price: currentPrice,
          image: currentImage,
          description: currentDescription
        }
      }));
      
      return {
        success: true,
        message: `${roomManagement[roomType].name} successfully reset to default settings`
      };
    } catch (error) {
      console.error('Error resetting room to default:', error);
      return {
        success: false,
        message: `Failed to reset ${roomManagement[roomType].name} to default settings`
      };
    }
  };

  /**
   * Sync room availability with actual bookings
   * This function should be called when bookings are made or cancelled
   */
  const syncRoomAvailability = () => {
    try {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      
      // Count occupied rooms by type
      const occupiedCounts = {
        single: 0,
        double: 0,
        suite: 0
      };

      // Count active bookings by room type
      bookings.forEach((booking: { status: string; roomId: string }) => {
        if (booking.status === 'confirmed' || booking.status === 'pending') {
          const room = rooms.find(r => r.id === booking.roomId);
          if (room) {
            occupiedCounts[room.type as keyof typeof occupiedCounts]++;
          }
        }
      });

      // Update availability based on actual bookings
      setRoomManagement(prev => ({
        single: {
          ...prev.single,
          available: prev.single.maxRooms - occupiedCounts.single
        },
        double: {
          ...prev.double,
          available: prev.double.maxRooms - occupiedCounts.double
        },
        suite: {
          ...prev.suite,
          available: prev.suite.maxRooms - occupiedCounts.suite
        }
      }));
    } catch (error) {
      console.error('Error syncing room availability:', error);
    }
  };

  /**
   * Get comprehensive room statistics
   */
  const getRoomStats = () => {
    const stats = {
      totalRooms: 0,
      availableRooms: 0,
      occupiedRooms: 0,
      byType: {
        single: { total: 0, available: 0, occupied: 0 },
        double: { total: 0, available: 0, occupied: 0 },
        suite: { total: 0, available: 0, occupied: 0 }
      }
    };

    Object.entries(roomManagement).forEach(([type, data]) => {
      const roomType = type as 'single' | 'double' | 'suite';
      const occupied = data.maxRooms - data.available;
      
      stats.totalRooms += data.maxRooms;
      stats.availableRooms += data.available;
      stats.occupiedRooms += occupied;
      
      stats.byType[roomType] = {
        total: data.maxRooms,
        available: data.available,
        occupied
      };
    });

    return stats;
  };

  /**
   * Set selected room
   */
  const handleSetSelectedRoom = (roomId: string | null) => {
    setSelectedRoom(roomId);
    // Also save to localStorage for persistence
    if (roomId) {
      localStorage.setItem('selectedRoom', roomId);
    } else {
      localStorage.removeItem('selectedRoom');
    }
  };

  /**
   * Get selected room object
   */
  const getSelectedRoom = () => {
    if (!selectedRoom) return null;
    return rooms.find(room => room.id === selectedRoom) || null;
  };

  /**
   * Load selected room from localStorage on mount
   */
  useEffect(() => {
    const savedSelectedRoom = localStorage.getItem('selectedRoom');
    if (savedSelectedRoom) {
      setSelectedRoom(savedSelectedRoom);
    }
  }, []);

  /**
   * Load room management data from localStorage on mount
   */
  useEffect(() => {
    const savedRoomManagement = localStorage.getItem('roomManagement');
    if (savedRoomManagement) {
      try {
        const parsedData = JSON.parse(savedRoomManagement);
        setRoomManagement(parsedData);
      } catch (error) {
        console.error('Error loading room management data:', error);
      }
    }
  }, []);

  /**
   * Save room management data to localStorage whenever it changes
   */
  useEffect(() => {
    localStorage.setItem('roomManagement', JSON.stringify(roomManagement));
  }, [roomManagement]);

  const value: RoomContextType = {
    rooms,
    selectedRoom,
    roomManagement,
    updateRoomPrice,
    updateRoomAvailability,
    updateRoomOccupied,
    updateRoomUnderMaintenance,
    updateRoomMaxRooms,
    updateRoomImage,
    updateRoomDescription,
    resetRoomToDefault,
    setSelectedRoom: handleSetSelectedRoom,
    getSelectedRoom,
    syncRoomAvailability,
    getRoomStats
  };

  return (
    <RoomContext.Provider value={value}>
      {children}
    </RoomContext.Provider>
  );
};

/**
 * Custom hook to access room context
 * Must be used within a RoomProvider component
 */
export const useRooms = () => {
  const context = useContext(RoomContext);
  if (context === undefined) {
    throw new Error('useRooms must be used within a RoomProvider');
  }
  return context;
};
