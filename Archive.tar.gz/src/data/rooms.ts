import { Room } from '@/types/booking';

// Room images - will be updated dynamically by ImageService
const singleRoomImage = '/images/single-room.jpg';
const doubleRoomImage = '/images/double-room.jpg';
const suiteRoomImage = '/images/suite.jpg';

// Generate rooms with new distribution: 110 single, 80 double, 60 suite (250 total, 95 occupied)
const generateRooms = (): Room[] => {
  const rooms: Room[] = [];
  
  // Generate 110 single rooms (55 available, 55 occupied)
  for (let i = 1; i <= 110; i++) {
      rooms.push({
        id: `single-${i.toString().padStart(3, '0')}`,
        type: 'single',
        price: 5500, // Above minimum of 4500
        isAvailable: i <= 55, // First 55 are available
        features: ['Single bed', 'Study desk', 'Wardrobe', 'Wi-Fi', '24/7 Security', 'Shared bathroom', 'Laundry access'],
        image: singleRoomImage,
        maxOccupancy: 1,
      });
  }
  
  // Generate 80 double rooms (57 available, 23 occupied)
  for (let i = 1; i <= 80; i++) {
      rooms.push({
        id: `double-${i.toString().padStart(3, '0')}`,
        type: 'double',
        price: 8500, // Above minimum of 4500
        isAvailable: i <= 57, // First 57 are available
        features: ['2 Single beds', 'Study desks', 'Large wardrobe', 'Wi-Fi', 'Balcony', '24/7 Security', 'Private bathroom', 'Mini-fridge', 'Laundry access', 'Cleaning service'],
        image: doubleRoomImage,
        maxOccupancy: 2,
      });
  }
  
  // Generate 60 suite rooms (45 available, 15 occupied)
  for (let i = 1; i <= 60; i++) {
      rooms.push({
        id: `suite-${i.toString().padStart(3, '0')}`,
        type: 'suite',
        price: 12500, // Above minimum of 4500
        isAvailable: i <= 45, // First 45 are available
        features: ['Queen bed', 'Living area', 'Kitchenette', 'Private bathroom', 'Wi-Fi', 'AC', '24/7 Security', 'Smart TV', 'Premium furniture', 'Daily cleaning', 'Room service', 'Concierge', 'Premium amenities'],
        image: suiteRoomImage,
        maxOccupancy: 2,
      });
  }
  
  return rooms;
};

export const rooms: Room[] = generateRooms();