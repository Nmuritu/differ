#!/usr/bin/env node

/**
 * Production Testing Script
 * 
 * Comprehensive testing of all functionality, buttons, and forms
 * across the entire application for production readiness.
 */

const fs = require('fs');
const path = require('path');

// Test configuration
const TEST_CONFIG = {
  baseUrl: 'http://localhost:5173',
  timeout: 10000,
  retries: 3,
  verbose: true
};

// Test results storage
const testResults = {
  passed: 0,
  failed: 0,
  skipped: 0,
  total: 0,
  details: []
};

// Utility functions
const log = (message, type = 'info') => {
  const timestamp = new Date().toISOString();
  const prefix = type === 'error' ? '❌' : type === 'success' ? '✅' : type === 'warning' ? '⚠️' : 'ℹ️';
  console.log(`${prefix} [${timestamp}] ${message}`);
};

const addTestResult = (testName, status, details = '') => {
  testResults.total++;
  testResults[status]++;
  testResults.details.push({
    name: testName,
    status,
    details,
    timestamp: new Date().toISOString()
  });
  
  const statusIcon = status === 'passed' ? '✅' : status === 'failed' ? '❌' : '⏭️';
  log(`${statusIcon} ${testName}: ${status.toUpperCase()}`, status === 'passed' ? 'success' : status === 'failed' ? 'error' : 'warning');
  if (details) log(`   Details: ${details}`, 'info');
};

// Test functions
const testFileExists = (filePath, description) => {
  try {
    const fullPath = path.resolve(filePath);
    if (fs.existsSync(fullPath)) {
      addTestResult(description, 'passed', `File exists: ${filePath}`);
      return true;
    } else {
      addTestResult(description, 'failed', `File not found: ${filePath}`);
      return false;
    }
  } catch (error) {
    addTestResult(description, 'failed', `Error checking file: ${error.message}`);
    return false;
  }
};

const testFileContent = (filePath, requiredContent, description) => {
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      addTestResult(description, 'failed', `File not found: ${filePath}`);
      return false;
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    const hasContent = requiredContent.some(req => content.includes(req));
    
    if (hasContent) {
      addTestResult(description, 'passed', `Required content found in ${filePath}`);
      return true;
    } else {
      addTestResult(description, 'failed', `Required content not found in ${filePath}`);
      return false;
    }
  } catch (error) {
    addTestResult(description, 'failed', `Error reading file: ${error.message}`);
    return false;
  }
};

const testPackageJson = () => {
  log('Testing package.json configuration...', 'info');
  
  try {
    const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    
    // Test required scripts
    const requiredScripts = ['dev', 'build', 'preview', 'lint'];
    requiredScripts.forEach(script => {
      if (packageJson.scripts && packageJson.scripts[script]) {
        addTestResult(`Package script: ${script}`, 'passed', `Script defined: ${packageJson.scripts[script]}`);
      } else {
        addTestResult(`Package script: ${script}`, 'failed', 'Script not defined');
      }
    });
    
    // Test required dependencies
    const requiredDeps = ['react', 'react-dom', 'react-router-dom', 'lucide-react'];
    requiredDeps.forEach(dep => {
      if (packageJson.dependencies && packageJson.dependencies[dep]) {
        addTestResult(`Package dependency: ${dep}`, 'passed', `Version: ${packageJson.dependencies[dep]}`);
      } else {
        addTestResult(`Package dependency: ${dep}`, 'failed', 'Dependency not found');
      }
    });
    
    return true;
  } catch (error) {
    addTestResult('Package.json validation', 'failed', `Error: ${error.message}`);
    return false;
  }
};

const testViteConfig = () => {
  log('Testing Vite configuration...', 'info');
  
  const viteConfigPath = 'vite.config.ts';
  const requiredConfigs = [
    'build',
    'rollupOptions',
    'manualChunks',
    'chunkSizeWarningLimit'
  ];
  
  requiredConfigs.forEach(config => {
    testFileContent(viteConfigPath, [config], `Vite config: ${config}`);
  });
  
  return true;
};

const testReactComponents = () => {
  log('Testing React components...', 'info');
  
  const components = [
    'src/App.tsx',
    'src/pages/HomePage.tsx',
    'src/pages/AIAssistantPage.tsx',
    'src/pages/AdminPage.tsx',
    'src/pages/ClientChatForum.tsx',
    'src/pages/AdminChatForum.tsx',
    'src/components/ChatForum.tsx',
    'src/components/RouteGuard.tsx',
    'src/contexts/NewAuthContext.tsx',
    'src/services/ChatService.ts',
    'src/services/AILearningService.ts'
  ];
  
  components.forEach(component => {
    testFileExists(component, `Component exists: ${component}`);
  });
  
  return true;
};

const testServices = () => {
  log('Testing services...', 'info');
  
  const services = [
    'src/services/NewAuthService.ts',
    'src/services/ChatService.ts',
    'src/services/AILearningService.ts',
    'src/services/ImageService.ts',
    'src/services/DataMigrationService.ts'
  ];
  
  services.forEach(service => {
    testFileExists(service, `Service exists: ${service}`);
  });
  
  return true;
};

const testUIComponents = () => {
  log('Testing UI components...', 'info');
  
  const uiComponents = [
    'src/components/ui/button.tsx',
    'src/components/ui/card.tsx',
    'src/components/ui/input.tsx',
    'src/components/ui/badge.tsx',
    'src/components/ui/scroll-area.tsx'
  ];
  
  uiComponents.forEach(component => {
    testFileExists(component, `UI component exists: ${component}`);
  });
  
  return true;
};

const testPublicAssets = () => {
  log('Testing public assets...', 'info');
  
  const publicAssets = [
    'public/index.html',
    'public/images/single-room.jpg',
    'public/images/double-room.jpg',
    'public/images/suite.jpg',
    'public/images/default-profile.svg'
  ];
  
  publicAssets.forEach(asset => {
    testFileExists(asset, `Public asset exists: ${asset}`);
  });
  
  return true;
};

const testTypeScriptConfig = () => {
  log('Testing TypeScript configuration...', 'info');
  
  const tsConfigPath = 'tsconfig.json';
  testFileExists(tsConfigPath, 'TypeScript config exists');
  
  if (fs.existsSync(tsConfigPath)) {
    const requiredConfigs = ['compilerOptions', 'include', 'exclude'];
    requiredConfigs.forEach(config => {
      testFileContent(tsConfigPath, [config], `TSConfig: ${config}`);
    });
  }
  
  return true;
};

const testTailwindConfig = () => {
  log('Testing Tailwind configuration...', 'info');
  
  const tailwindConfigPath = 'tailwind.config.ts';
  testFileExists(tailwindConfigPath, 'Tailwind config exists');
  
  if (fs.existsSync(tailwindConfigPath)) {
    const requiredConfigs = ['content', 'theme', 'plugins'];
    requiredConfigs.forEach(config => {
      testFileContent(tailwindConfigPath, [config], `Tailwind config: ${config}`);
    });
  }
  
  return true;
};

const testBuildScripts = () => {
  log('Testing build scripts...', 'info');
  
  const buildScripts = [
    'apache-local.sh',
    'cloudflare-tunnel.sh',
    'vercel-deploy.sh',
    'netlify-deploy.sh',
    'railway-deploy.sh'
  ];
  
  buildScripts.forEach(script => {
    testFileExists(script, `Build script exists: ${script}`);
    if (fs.existsSync(script)) {
      // Check if script is executable
      const stats = fs.statSync(script);
      const isExecutable = !!(stats.mode & parseInt('111', 8));
      if (isExecutable) {
        addTestResult(`Build script executable: ${script}`, 'passed', 'Script is executable');
      } else {
        addTestResult(`Build script executable: ${script}`, 'failed', 'Script is not executable');
      }
    }
  });
  
  return true;
};

const testDocumentation = () => {
  log('Testing documentation...', 'info');
  
  const docs = [
    'README.md',
    'FIXES_SUMMARY.md',
    'PROMPT_LIMIT_SUMMARY.md',
    'DEPLOYMENT_GUIDE.md',
    'GLOBAL_HOSTING.md',
    'APACHE_HOSTING.md'
  ];
  
  docs.forEach(doc => {
    testFileExists(doc, `Documentation exists: ${doc}`);
  });
  
  return true;
};

const testCodeQuality = () => {
  log('Testing code quality...', 'info');
  
  // Check for common issues
  const commonIssues = [
    { file: 'src/App.tsx', issue: 'console.log', description: 'Console.log statements' },
    { file: 'src/pages/AIAssistantPage.tsx', issue: 'TODO', description: 'TODO comments' },
    { file: 'src/services/ChatService.ts', issue: 'FIXME', description: 'FIXME comments' }
  ];
  
  commonIssues.forEach(({ file, issue, description }) => {
    if (fs.existsSync(file)) {
      const content = fs.readFileSync(file, 'utf8');
      if (content.includes(issue)) {
        addTestResult(`Code quality: ${description} in ${file}`, 'warning', `Found ${issue} in ${file}`);
      } else {
        addTestResult(`Code quality: ${description} in ${file}`, 'passed', `No ${issue} found`);
      }
    }
  });
  
  return true;
};

const testSecurity = () => {
  log('Testing security...', 'info');
  
  // Check for sensitive information
  const sensitivePatterns = [
    { pattern: 'password.*=.*["\']', description: 'Hardcoded passwords' },
    { pattern: 'api.*key.*=.*["\']', description: 'Hardcoded API keys' },
    { pattern: 'secret.*=.*["\']', description: 'Hardcoded secrets' }
  ];
  
  const filesToCheck = [
    'src/services/NewAuthService.ts',
    'src/services/ChatService.ts',
    'src/contexts/NewAuthContext.tsx'
  ];
  
  filesToCheck.forEach(file => {
    if (fs.existsSync(file)) {
      const content = fs.readFileSync(file, 'utf8');
      sensitivePatterns.forEach(({ pattern, description }) => {
        const regex = new RegExp(pattern, 'i');
        if (regex.test(content)) {
          addTestResult(`Security: ${description} in ${file}`, 'warning', `Found potential ${description}`);
        } else {
          addTestResult(`Security: ${description} in ${file}`, 'passed', `No ${description} found`);
        }
      });
    }
  });
  
  return true;
};

const generateReport = () => {
  log('Generating test report...', 'info');
  
  const report = {
    summary: {
      total: testResults.total,
      passed: testResults.passed,
      failed: testResults.failed,
      skipped: testResults.skipped,
      successRate: ((testResults.passed / testResults.total) * 100).toFixed(2) + '%'
    },
    details: testResults.details,
    timestamp: new Date().toISOString(),
    environment: {
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch
    }
  };
  
  // Save report to file
  const reportPath = 'production-test-report.json';
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  
  // Display summary
  console.log('\n' + '='.repeat(60));
  console.log('PRODUCTION TEST SUMMARY');
  console.log('='.repeat(60));
  console.log(`Total Tests: ${testResults.total}`);
  console.log(`✅ Passed: ${testResults.passed}`);
  console.log(`❌ Failed: ${testResults.failed}`);
  console.log(`⏭️ Skipped: ${testResults.skipped}`);
  console.log(`Success Rate: ${report.summary.successRate}`);
  console.log('='.repeat(60));
  
  if (testResults.failed > 0) {
    console.log('\n❌ FAILED TESTS:');
    testResults.details
      .filter(test => test.status === 'failed')
      .forEach(test => {
        console.log(`  - ${test.name}: ${test.details}`);
      });
  }
  
  if (testResults.skipped > 0) {
    console.log('\n⏭️ SKIPPED TESTS:');
    testResults.details
      .filter(test => test.status === 'skipped')
      .forEach(test => {
        console.log(`  - ${test.name}: ${test.details}`);
      });
  }
  
  console.log(`\n📊 Detailed report saved to: ${reportPath}`);
  
  return testResults.failed === 0;
};

// Main test execution
const runTests = async () => {
  log('Starting production tests...', 'info');
  console.log('='.repeat(60));
  
  try {
    // Run all tests
    testPackageJson();
    testViteConfig();
    testReactComponents();
    testServices();
    testUIComponents();
    testPublicAssets();
    testTypeScriptConfig();
    testTailwindConfig();
    testBuildScripts();
    testDocumentation();
    testCodeQuality();
    testSecurity();
    
    // Generate report
    const success = generateReport();
    
    if (success) {
      log('All tests passed! Application is production ready. 🚀', 'success');
      process.exit(0);
    } else {
      log('Some tests failed. Please fix the issues before deploying. ⚠️', 'error');
      process.exit(1);
    }
    
  } catch (error) {
    log(`Test execution failed: ${error.message}`, 'error');
    process.exit(1);
  }
};

// Run tests if this script is executed directly
if (require.main === module) {
  runTests();
}

module.exports = {
  runTests,
  testFileExists,
  testFileContent,
  addTestResult,
  testResults
};
